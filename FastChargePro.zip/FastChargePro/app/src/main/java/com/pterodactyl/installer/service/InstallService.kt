package com.pterodactyl.installer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.pterodactyl.installer.MainActivity
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.InstallManager
import com.pterodactyl.installer.data.InstallParams
import com.pterodactyl.installer.data.ServiceBus
import com.pterodactyl.installer.data.Stage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class InstallService : Service() {

    companion object {
        const val CHANNEL_ID = "ptero_install"
        const val NOTIF_ID = 1001

        fun startIntent(ctx: Context, p: InstallParams): Intent =
            Intent(ctx, InstallService::class.java).apply {
                putExtra("ip", p.ipVps)
                putExtra("pw", p.pwVps)
                putExtra("dpanel", p.domainPanel)
                putExtra("dnode", p.domainNode)
                putExtra("user", p.usernamePanel)
                putExtra("pass", p.passwordPanel)
                putExtra("email", p.gmailPanel)
            }

        fun stop(ctx: Context) {
            ctx.startService(
                Intent(ctx, InstallService::class.java).setAction("STOP_INSTALL"))
        }
    }

    private var manager: InstallManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_INSTALL") {
            manager?.stop()
            finishService("⛔ Dibatalkan")
            return START_NOT_STICKY
        }

        val p = InstallParams(
            ipVps = intent?.getStringExtra("ip").orEmpty(),
            pwVps = intent?.getStringExtra("pw").orEmpty(),
            domainPanel = intent?.getStringExtra("dpanel").orEmpty(),
            domainNode = intent?.getStringExtra("dnode").orEmpty(),
            usernamePanel = intent?.getStringExtra("user").orEmpty(),
            passwordPanel = intent?.getStringExtra("pass").orEmpty(),
            gmailPanel = intent?.getStringExtra("email").orEmpty()
        )

        startForeground(NOTIF_ID, buildNotif("Memulai instalasi…"))
        acquireWakeLock()
        ServiceBus.installRunning = true

        manager = InstallManager(
            params = p,
            onLog = { type, msg ->
                ServiceBus.emitLog(type, msg)
                if (type == "success" || type == "error") {
                    updateNotif(msg.take(60))
                }
            },
            onStage = { st ->
                ServiceBus.emitStage(st.name)
                val text = when (st) {
                    Stage.PANEL -> "Tahap 1/3: Panel"
                    Stage.WINGS -> "Tahap 2/3: Wings"
                    Stage.NODE -> "Tahap 3/3: Node"
                    Stage.DONE -> "Selesai"
                    Stage.ERROR -> "Error"
                    else -> "Memproses…"
                }
                updateNotif(text)
            },
            onComplete = { ok, msg, data ->
                ServiceBus.emitDone(ok, msg, data)
                finishService(if (ok) "✅ Instalasi selesai" else "❌ $msg")
            }
        )
        manager?.start()

        // Listener command queue dari UI
        scope.launch {
            ServiceBus.installCommand.collect { cmd ->
                manager?.sendCommand(cmd)
            }
        }

        return START_NOT_STICKY
    }

    private fun finishService(finalMsg: String) {
        manager = null
        ServiceBus.installRunning = false
        releaseWakeLock()
        updateNotif(finalMsg, final = true)
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Instalasi Panel",
                        NotificationManager.IMPORTANCE_LOW).apply {
                        description = "Progres instalasi Pterodactyl"
                        setShowBadge(false)
                    })
            }
        }
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, InstallService::class.java).setAction("STOP_INSTALL"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_install)
            .setContentTitle("Pterodactyl Installer")
            .setContentText(text)
            .setContentIntent(pi)
            .addAction(0, "Stop", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()
    }

    private fun updateNotif(text: String, final: Boolean = false) {
        val nm = getSystemService(NotificationManager::class.java)
        if (final) {
            val p = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_install)
                .setContentTitle("Pterodactyl Installer")
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID + 1, p)
        } else {
            nm.notify(NOTIF_ID, buildNotif(text))
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "ptero:install"
            ).apply { acquire(60 * 60 * 1000L) }
        } catch (_: Exception) { }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    override fun onDestroy() {
        manager?.stop()
        releaseWakeLock()
        ServiceBus.installRunning = false
        super.onDestroy()
    }
}