package com.pterodactyl.installer.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.InstallParams
import com.pterodactyl.installer.data.ServiceBus
import com.pterodactyl.installer.service.InstallService
import kotlinx.coroutines.launch

class InstallFragment : Fragment() {

    private lateinit var etIp: EditText
    private lateinit var etPw: EditText
    private lateinit var etDomainPanel: EditText
    private lateinit var etDomainNode: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etEmail: EditText
    private lateinit var btnInstall: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var statusDot: View
    private lateinit var svLog: ScrollView
    private lateinit var llLog: LinearLayout
    private lateinit var tvLogCount: TextView
    private lateinit var etCommand: EditText
    private lateinit var btnSend: Button

    private var logLines = 0
    private var running = false

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_install, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etIp = view.findViewById(R.id.etIpVps)
        etPw = view.findViewById(R.id.etPwVps)
        etDomainPanel = view.findViewById(R.id.etDomainPanel)
        etDomainNode = view.findViewById(R.id.etDomainNode)
        etUser = view.findViewById(R.id.etUsername)
        etPass = view.findViewById(R.id.etPassword)
        etEmail = view.findViewById(R.id.etEmail)
        btnInstall = view.findViewById(R.id.btnInstall)
        btnStop = view.findViewById(R.id.btnStop)
        tvStatus = view.findViewById(R.id.tvStatus)
        statusDot = view.findViewById(R.id.statusDot)
        svLog = view.findViewById(R.id.svLog)
        llLog = view.findViewById(R.id.llLogContainer)
        tvLogCount = view.findViewById(R.id.tvLogCount)
        etCommand = view.findViewById(R.id.etCommand)
        btnSend = view.findViewById(R.id.btnSend)

        btnInstall.setOnClickListener { startInstall() }
        btnStop.setOnClickListener { stopInstall() }
        btnSend.setOnClickListener { sendCommand() }
        etCommand.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendCommand(); true } else false
        }

        askNotifPermission()
        observeService()
        syncState()
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun syncState() {
        if (ServiceBus.installRunning) {
            running = true
            btnInstall.isEnabled = false
            btnStop.visibility = View.VISIBLE
            etCommand.isEnabled = true
            btnSend.isEnabled = true
            setStatus("running", "⏳ Instalasi berjalan")
        } else {
            running = false
            btnInstall.isEnabled = true
            btnStop.visibility = View.GONE
            etCommand.isEnabled = false
            btnSend.isEnabled = false
            setStatus("idle", "Siap untuk instalasi")
        }
    }

    private fun observeService() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    ServiceBus.installLog.collect { addLog(it.type, it.message) }
                }
                launch {
                    ServiceBus.installStage.collect { st ->
                        when (st) {
                            "PANEL" -> setStatus("running", "📦 Tahap 1/3: Panel")
                            "WINGS" -> setStatus("running", "🪶 Tahap 2/3: Wings")
                            "NODE" -> setStatus("running", "📦 Tahap 3/3: Node")
                            "DONE" -> setStatus("done", "✅ Selesai")
                        }
                    }
                }
                launch {
                    ServiceBus.installDone.collect { ev ->
                        running = false
                        btnInstall.isEnabled = true
                        btnStop.visibility = View.GONE
                        etCommand.isEnabled = false
                        btnSend.isEnabled = false
                        if (ev.success) {
                            setStatus("done", "✅ ${ev.message}")
                            addLog("success", "═══════════════════")
                            addLog("success", "✅ Instalasi selesai!")
                            ev.data?.let {
                                addLog("success", "🌐 https://${it["domain_panel"]}")
                                addLog("success", "🌐 https://${it["domain_node"]}")
                                addLog("success", "👤 ${it["username"]} / ${it["password"]}")
                                addLog("success", "📧 ${it["email"]}")
                            }
                            addLog("success", "═══════════════════")
                        } else {
                            setStatus("error", "❌ ${ev.message}")
                        }
                    }
                }
            }
        }
    }

    private fun startInstall() {
        val p = InstallParams(
            ipVps = etIp.text.toString().trim(),
            pwVps = etPw.text.toString().trim(),
            domainPanel = etDomainPanel.text.toString().trim(),
            domainNode = etDomainNode.text.toString().trim(),
            usernamePanel = etUser.text.toString().trim(),
            passwordPanel = etPass.text.toString().trim(),
            gmailPanel = etEmail.text.toString().trim()
        )

        if (listOf(p.ipVps, p.pwVps, p.domainPanel, p.domainNode,
                p.usernamePanel, p.passwordPanel, p.gmailPanel).any { it.isBlank() }) {
            Toast.makeText(requireContext(), "Semua field wajib diisi!", Toast.LENGTH_SHORT).show()
            return
        }

        clearLogs()
        running = true
        btnInstall.isEnabled = false
        btnStop.visibility = View.VISIBLE
        etCommand.isEnabled = true
        btnSend.isEnabled = true
        setStatus("running", "⏳ Memulai…")

        ContextCompat.startForegroundService(
            requireContext(), InstallService.startIntent(requireContext(), p))
    }

    private fun stopInstall() {
        InstallService.stop(requireContext())
        running = false
        btnInstall.isEnabled = true
        btnStop.visibility = View.GONE
        etCommand.isEnabled = false
        btnSend.isEnabled = false
        setStatus("stopped", "⛔ Dihentikan")
    }

    private fun sendCommand() {
        val cmd = etCommand.text.toString().trim()
        if (cmd.isBlank() || !running) return
        addLog("info", "📤 $cmd")
        etCommand.setText("")
        ServiceBus.sendInstallCommand(cmd)
    }

    private fun setStatus(state: String, text: String) {
        if (!isAdded) return
        tvStatus.text = text
        val color = when (state) {
            "running" -> R.color.accent_yellow
            "done" -> R.color.accent_green
            "error" -> R.color.accent_red
            "stopped" -> R.color.text_muted
            else -> R.color.text_muted
        }
        statusDot.backgroundTintList = requireContext().getColorStateList(color)
    }

    private fun addLog(type: String, message: String) {
        if (!isAdded || view == null) return
        val tv = TextView(requireContext()).apply {
            text = message
            textSize = 11f
            setTextColor(when (type) {
                "success" -> Color.parseColor("#22c55e")
                "error" -> Color.parseColor("#ef4444")
                "warning" -> Color.parseColor("#facc15")
                "panel" -> Color.parseColor("#60a5fa")
                "wings" -> Color.parseColor("#a78bfa")
                "node" -> Color.parseColor("#34d399")
                else -> Color.parseColor("#8aa0c9")
            })
            setPadding(0, 2, 0, 2)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        llLog.addView(tv)
        logLines++
        tvLogCount.text = "$logLines baris"
        svLog.post { svLog.fullScroll(View.FOCUS_DOWN) }
    }

    private fun clearLogs() {
        llLog.removeAllViews()
        logLines = 0
        tvLogCount.text = "0 baris"
    }
}