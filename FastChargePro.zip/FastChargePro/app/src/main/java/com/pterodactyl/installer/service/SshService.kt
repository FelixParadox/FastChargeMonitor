package com.pterodactyl.installer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.pterodactyl.installer.MainActivity
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.ServiceBus
import com.pterodactyl.installer.data.SshClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SshService : Service() {

    companion object {
        const val CHANNEL_ID = "ptero_ssh"
        const val NOTIF_ID = 2001

        fun startIntent(ctx: Context, ip: String, pw: String): Intent =
            Intent(ctx, SshService::class.java).apply {
                putExtra("ip", ip); putExtra("pw", pw)
            }

        fun stop(ctx: Context) {
            ctx.startService(
                Intent(ctx, SshService::class.java).setAction("STOP_SSH"))
        }

        fun sendCommand(ctx: Context, cmd: String) {
            ctx.startService(Intent(ctx, SshService::class.java)
                .setAction("SEND_CMD").putExtra("cmd", cmd))
        }
    }

    private var client: SshClient? = null
    private var shell: SshClient.ShellHandle? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "STOP_SSH" -> { disconnect(); return START_NOT_STICKY }
            "SEND_CMD" -> {
                intent.getStringExtra("cmd")?.let { shell?.writeLine(it) }
                return START_STICKY
            }
        }

        val ip = intent?.getStringExtra("ip").orEmpty()
        val pw = intent?.getStringExtra("pw").orEmpty()

        startForeground(NOTIF_ID, buildNotif("Menghubungkan ke $ip…"))
        ServiceBus.sshRunning = true

        scope.launch {
            client = SshClient(ip, pw)
            val ok = client?.connect() == true
            if (!ok) {
                ServiceBus.emitSsh("error", "❌ SSH gagal ke $ip")
                ServiceBus.emitSshStatus("error")
                disconnect()
                return@launch
            }
            ServiceBus.emitSshStatus("connected")
            updateNotif("✅ Terhubung: $ip")

            shell = client?.openShell(
                onOutput = { chunk -> ServiceBus.emitSsh("output", chunk) },
                onError = { err -> ServiceBus.emitSsh("error", err) },
                onClose = {
                    ServiceBus.emitSshStatus("closed")
                    disconnect()
                }
            )
        }
        return START_STICKY
    }

    private fun disconnect() {
        try { shell?.close() } catch (_: Exception) { }
        shell = null
        try { client?.disconnect() } catch (_: Exception) { }
        client = null
        ServiceBus.sshRunning = false
        ServiceBus.emitSshStatus("disconnected")
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            if (mgr.getNotificationChannel(CHANNEL_ID) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "SSH Terminal",
                        NotificationManager.IMPORTANCE_LOW).apply {
                        setShowBadge(false)
                    })
            }
        }
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, SshService::class.java).setAction("STOP_SSH"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Pterodactyl SSH")
            .setContentText(text)
            .setContentIntent(pi)
            .addAction(0, "Disconnect", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotif(text))
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}