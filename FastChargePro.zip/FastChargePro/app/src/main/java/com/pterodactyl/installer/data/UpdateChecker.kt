package com.pterodactyl.installer.data

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class UpdateChecker(private val context: Context) {

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val changelog: String,
        val forceUpdate: Boolean
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .cache(null)             // matikan disk cache OkHttp
        .build()

    private val updateJsonUrl =
        "https://raw.githubusercontent.com/FelixParadox/spacex/refs/heads/main/updt/up.json"

    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            // Cache-buster: paksa CDN & OkHttp fetch fresh
            val bustUrl = "$updateJsonUrl?t=${System.currentTimeMillis()}"

            val req = Request.Builder()
                .url(bustUrl)
                .header("Cache-Control", "no-cache, no-store, must-revalidate")
                .header("Pragma", "no-cache")
                .header("Expires", "0")
                .header("User-Agent", "PterodactylInstaller/${getCurrentVersionCode()}")
                .cacheControl(CacheControl.FORCE_NETWORK)
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val body = resp.body?.string() ?: return@withContext null
                val json = JSONObject(body)

                val remote = json.optInt("versionCode", 0)
                val cur = getCurrentVersionCode()

                if (remote > cur) {
                    UpdateInfo(
                        versionCode = remote,
                        versionName = json.optString("versionName", "?"),
                        apkUrl = json.optString("apkUrl", ""),
                        changelog = json.optString("changelog", "-"),
                        forceUpdate = json.optBoolean("forceUpdate", false)
                    )
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /** longVersionCode hanya ada API 28+ — fallback ke versionCode lama */
    private fun getCurrentVersionCode(): Int = try {
        val pi = context.packageManager.getPackageInfo(context.packageName, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pi.longVersionCode.toInt()
        } else {
            @Suppress("DEPRECATION")
            pi.versionCode
        }
    } catch (e: Exception) {
        0
    }
}