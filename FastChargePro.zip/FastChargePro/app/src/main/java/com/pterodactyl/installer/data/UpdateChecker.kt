package com.pterodactyl.installer.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class UpdateChecker(private val context: Context) {
    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val changelog: String,
        val forceUpdate: Boolean
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS).build()

    private val updateJsonUrl =
        "https://raw.githubusercontent.com/FelixParadox/spacex/updt/main/up.json"

    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(updateJsonUrl)
                .header("Cache-Control", "no-cache").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val json = JSONObject(resp.body?.string() ?: return@withContext null)
                val remote = json.optInt("versionCode", 0)
                val cur = context.packageManager
                    .getPackageInfo(context.packageName, 0).longVersionCode.toInt()
                if (remote > cur) UpdateInfo(
                    remote,
                    json.optString("versionName", "?"),
                    json.optString("apkUrl", ""),
                    json.optString("changelog", "-"),
                    json.optBoolean("forceUpdate", false)
                ) else null
            }
        } catch (e: Exception) { null }
    }
}