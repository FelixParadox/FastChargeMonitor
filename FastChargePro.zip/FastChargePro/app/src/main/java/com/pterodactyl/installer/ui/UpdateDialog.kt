package com.pterodactyl.installer.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.UpdateChecker

class UpdateDialog(
    context: Context,
    private val info: UpdateChecker.UpdateInfo,
    private val onDownload: () -> Unit,
    private val onDismiss: () -> Unit
) : Dialog(context) {
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var btnUpdate: Button
    private lateinit var btnLater: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_update)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.9).toInt(),
            LinearLayout.LayoutParams.WRAP_CONTENT)
        setCancelable(!info.forceUpdate)

        val tvVersion = findViewById<TextView>(R.id.tvVersion)
        val tvChangelog = findViewById<TextView>(R.id.tvChangelog)
        progressBar = findViewById(R.id.progressBar)
        tvProgress = findViewById(R.id.tvProgress)
        btnUpdate = findViewById(R.id.btnUpdate)
        btnLater = findViewById(R.id.btnLater)

        tvVersion.text = "Versi ${info.versionName} tersedia!"
        tvChangelog.text = info.changelog

        if (info.forceUpdate) btnLater.visibility = LinearLayout.GONE
        else btnLater.setOnClickListener { dismiss(); onDismiss() }

        btnUpdate.setOnClickListener {
            btnUpdate.isEnabled = false
            btnUpdate.text = "Mengunduh..."
            progressBar.visibility = LinearLayout.VISIBLE
            tvProgress.visibility = LinearLayout.VISIBLE
            onDownload()
        }
    }

    fun updateProgress(pct: Int) {
        if (!isShowing) return
        progressBar.progress = pct
        tvProgress.text = "$pct%"
    }
}