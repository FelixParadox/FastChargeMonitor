package com.pterodactyl.installer.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.ServiceBus
import com.pterodactyl.installer.service.SshService
import kotlinx.coroutines.launch

class SshFragment : Fragment() {

    private lateinit var etIp: EditText
    private lateinit var etPw: EditText
    private lateinit var btnConnect: Button
    private lateinit var btnDisconnect: Button
    private lateinit var tvStatus: TextView
    private lateinit var statusDot: View
    private lateinit var svLog: ScrollView
    private lateinit var llLog: LinearLayout
    private lateinit var tvLogCount: TextView
    private lateinit var etCommand: EditText
    private lateinit var btnSend: Button

    private var logLines = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_ssh, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        etIp = view.findViewById(R.id.etSshIp)
        etPw = view.findViewById(R.id.etSshPw)
        btnConnect = view.findViewById(R.id.btnConnect)
        btnDisconnect = view.findViewById(R.id.btnDisconnect)
        tvStatus = view.findViewById(R.id.tvSshStatus)
        statusDot = view.findViewById(R.id.sshStatusDot)
        svLog = view.findViewById(R.id.svSshLog)
        llLog = view.findViewById(R.id.llSshLogContainer)
        tvLogCount = view.findViewById(R.id.tvSshLogCount)
        etCommand = view.findViewById(R.id.etSshCommand)
        btnSend = view.findViewById(R.id.btnSshSend)

        btnConnect.setOnClickListener { connect() }
        btnDisconnect.setOnClickListener { disconnect() }
        btnSend.setOnClickListener { sendCommand() }
        etCommand.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendCommand(); true } else false
        }

        observeService()
        syncState()
    }

    private fun syncState() {
        if (ServiceBus.sshRunning) {
            setStatus("connected", "✅ SSH aktif")
            btnConnect.isEnabled = false
            btnDisconnect.visibility = View.VISIBLE
            etCommand.isEnabled = true
            btnSend.isEnabled = true
        } else {
            setStatus("idle", "Belum terhubung")
            btnConnect.isEnabled = true
            btnDisconnect.visibility = View.GONE
            etCommand.isEnabled = false
            btnSend.isEnabled = false
        }
    }

    private fun observeService() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    ServiceBus.sshOutput.collect { ev ->
                        when (ev.type) {
                            "output" -> ev.message.lines().forEach { line ->
                                if (line.isNotEmpty()) addLog("output", line)
                            }
                            "error" -> addLog("error", ev.message)
                            else -> addLog("info", ev.message)
                        }
                    }
                }
                launch {
                    ServiceBus.sshStatus.collect { st ->
                        when (st) {
                            "connected" -> {
                                setStatus("connected", "✅ Terhubung")
                                btnConnect.isEnabled = false
                                btnDisconnect.visibility = View.VISIBLE
                                etCommand.isEnabled = true
                                btnSend.isEnabled = true
                            }
                            "error" -> setStatus("error", "❌ Gagal terhubung")
                            "closed", "disconnected" -> {
                                setStatus("idle", "Belum terhubung")
                                btnConnect.isEnabled = true
                                btnDisconnect.visibility = View.GONE
                                etCommand.isEnabled = false
                                btnSend.isEnabled = false
                            }
                        }
                    }
                }
            }
        }
    }

    private fun connect() {
        val ip = etIp.text.toString().trim()
        val pw = etPw.text.toString().trim()
        if (ip.isBlank() || pw.isBlank()) {
            Toast.makeText(requireContext(), "IP & Password wajib diisi", Toast.LENGTH_SHORT).show()
            return
        }

        setStatus("connecting", "⏳ Menghubungkan…")
        btnConnect.isEnabled = false
        addLog("info", "🔌 Menghubungkan ke $ip…")

        ContextCompat.startForegroundService(
            requireContext(), SshService.startIntent(requireContext(), ip, pw))
    }

    private fun disconnect() {
        SshService.stop(requireContext())
        setStatus("idle", "Belum terhubung")
        btnConnect.isEnabled = true
        btnDisconnect.visibility = View.GONE
        etCommand.isEnabled = false
        btnSend.isEnabled = false
        addLog("info", "🔚 Sesi ditutup")
    }

    private fun sendCommand() {
        val cmd = etCommand.text.toString()
        if (cmd.isBlank()) return
        SshService.sendCommand(requireContext(), cmd)
        etCommand.setText("")
    }

    private fun setStatus(state: String, text: String) {
        if (!isAdded) return
        tvStatus.text = text
        val color = when (state) {
            "connected" -> R.color.accent_green
            "connecting" -> R.color.accent_yellow
            "error" -> R.color.accent_red
            else -> R.color.text_muted
        }
        statusDot.backgroundTintList = requireContext().getColorStateList(color)
    }

    private fun addLog(type: String, message: String) {
        if (!isAdded || view == null) return
        val tv = TextView(requireContext()).apply {
            text = message
            textSize = 11f
            setTextColor(when (type) {
                "error" -> Color.parseColor("#ef4444")
                "info" -> Color.parseColor("#8aa0c9")
                else -> Color.parseColor("#e8edf5")
            })
            setPadding(0, 2, 0, 2)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        llLog.addView(tv)
        logLines++
        tvLogCount.text = "$logLines baris"
        svLog.post { svLog.fullScroll(View.FOCUS_DOWN) }
    }
}