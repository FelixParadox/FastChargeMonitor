package id.fastcharge.monitor.data

import android.content.Context
import android.content.pm.PackageInfo
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Pemeriksa update berbasis update.json.
 * Catatan: versi APK terpasang tidak dapat diubah dari internet; versi baru berlaku
 * setelah APK baru diunduh dan dipasang. APK hasil build membaca versi dari JSON lokal.
 */
class UpdateChecker(private val context: Context) {
    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val changelog: String,
        val forceUpdate: Boolean,
        val minSupportedVersionCode: Int = 0,
        val sha256: String? = null
    )

    data class CurrentVersion(val code: Long, val name: String)

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // Ganti URL ini jika file update.json berada di repository berbeda.
    private val updateJsonUrl =
        "https://raw.githubusercontent.com/FelixParadox/FastChargeMonitor/main/update.json"

    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            // Cache-buster + no-cache agar perubahan JSON terbaru segera terbaca.
            val url = updateJsonUrl + (if (updateJsonUrl.contains('?')) "&" else "?") + "_=" + System.currentTimeMillis()
            val request = Request.Builder()
                .url(url)
                .cacheControl(CacheControl.Builder().noCache().noStore().build())
                .header("Pragma", "no-cache")
                .header("User-Agent", "FastChargePro-UpdateChecker")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string()?.takeIf { it.isNotBlank() } ?: return@withContext null
                val json = JSONObject(body)

                val remoteName = json.optString("versionName", "").trim()
                val remoteCode = json.optInt("versionCode", 0)
                val apkUrl = json.optString("apkUrl", "").trim()
                if (remoteName.isBlank() || !isValidApkUrl(apkUrl)) return@withContext null

                val current = getCurrentVersion()
                // versionCode adalah sumber pembanding utama. versionName menjadi fallback
                // untuk JSON lama yang belum mempunyai versionCode atau ketika kode sama.
                val remoteIsNewer = if (remoteCode > 0) {
                    remoteCode.toLong() > current.code
                } else {
                    compareVersionNames(remoteName, current.name) > 0
                }
                if (!remoteIsNewer) return@withContext null

                UpdateInfo(
                    versionCode = if (remoteCode > 0) remoteCode else (current.code + 1).toInt(),
                    versionName = remoteName,
                    apkUrl = apkUrl,
                    changelog = json.optString("changelog", "Pembaruan tersedia."),
                    forceUpdate = json.optBoolean("forceUpdate", false),
                    minSupportedVersionCode = json.optInt("minSupportedVersionCode", 0),
                    sha256 = json.optString("sha256", "").takeIf { it.isNotBlank() }
                )
            }
        } catch (_: Exception) {
            // Kegagalan jaringan/JSON tidak membuat aplikasi crash.
            null
        }
    }

    fun getCurrentVersion(): CurrentVersion {
        return try {
            val pi: PackageInfo = if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getPackageInfo(context.packageName, android.content.pm.PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
            val code = if (Build.VERSION.SDK_INT >= 28) {
                pi.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pi.versionCode.toLong()
            }
            CurrentVersion(code, pi.versionName ?: "0.0")
        } catch (_: Exception) { CurrentVersion(0L, "0.0") }
    }

    private fun isValidApkUrl(url: String): Boolean {
        if (!url.startsWith("https://", ignoreCase = true)) return false
        return try {
            java.net.URI(url).path.orEmpty().endsWith(".apk", ignoreCase = true)
        } catch (_: Exception) { false }
    }

    private fun compareVersionNames(a: String, b: String): Int {
        val aa = Regex("\\d+").findAll(a).mapNotNull { it.value.toLongOrNull() }.toList()
        val bb = Regex("\\d+").findAll(b).mapNotNull { it.value.toLongOrNull() }.toList()
        if (aa.isEmpty() || bb.isEmpty()) return a.compareTo(b, ignoreCase = true)
        for (i in 0 until maxOf(aa.size, bb.size)) {
            val av = aa.getOrElse(i) { 0L }
            val bv = bb.getOrElse(i) { 0L }
            if (av != bv) return av.compareTo(bv)
        }
        return 0
    }
}
