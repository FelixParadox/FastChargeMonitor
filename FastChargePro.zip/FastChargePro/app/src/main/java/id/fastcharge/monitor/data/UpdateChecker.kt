package id.fastcharge.monitor.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class UpdateChecker(private val context: Context) {

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val changelog: String,
        val forceUpdate: Boolean
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val updateJsonUrl =
        "https://raw.githubusercontent.com/FelixParadox/FastChargeMonitor/main/update.json"

    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(updateJsonUrl)
                .header("Cache-Control", "no-cache")
                .header("User-Agent", "FastChargePro/${getCurrentVersion()}")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                val json = JSONObject(body)

                val remoteCode = json.optInt("versionCode", 0)
                val remoteName = json.optString("versionName", "?")
                val apkUrl = json.optString("apkUrl", "")
                val changelog = json.optString("changelog", "-")
                val force = json.optBoolean("forceUpdate", false)

                val currentCode = getCurrentVersion()

                if (remoteCode > currentCode && apkUrl.isNotBlank()) {
                    UpdateInfo(remoteCode, remoteName, apkUrl, changelog, force)
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun getCurrentVersion(): Int {
        return try {
            context.packageManager
                .getPackageInfo(context.packageName, 0)
                .longVersionCode.toInt()
        } catch (e: Exception) { 0 }
    }
}