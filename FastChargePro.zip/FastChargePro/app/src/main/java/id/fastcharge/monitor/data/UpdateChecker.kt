package id.fastcharge.monitor.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Cek versi terbaru dari server/GitHub.
 *
 * Format JSON yang diharapkan (update.json):
 * {
 *   "versionCode": 3,
 *   "versionName": "2.1",
 *   "apkUrl": "https://github.com/user/repo/releases/download/v2.1/app-release.apk",
 *   "changelog": "- Fix bug\n- UI baru",
 *   "forceUpdate": false
 * }
 */
class UpdateChecker(private val context: Context) {

    data class UpdateInfo(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val changelog: String,
        val forceUpdate: Boolean
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // 🔗 GANTI URL INI dengan URL JSON update Anda
    // Bisa dari GitHub raw, Firebase, Supabase, dsb.
    private val updateJsonUrl = "https://raw.githubusercontent.com/FelixParadox/FastChargeMonitor/main/update.json"

    /**
     * Cek apakah ada update baru. Return null jika tidak ada / gagal.
     */
    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(updateJsonUrl)
                .header("Cache-Control", "no-cache")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body?.string() ?: return@withContext null
                val json = JSONObject(body)

                val remoteCode = json.optInt("versionCode", 0)
                val remoteName = json.optString("versionName", "?")
                val apkUrl = json.optString("apkUrl", "")
                val changelog = json.optString("changelog", "-")
                val force = json.optBoolean("forceUpdate", false)

                val currentCode = context.packageManager
                    .getPackageInfo(context.packageName, 0).longVersionCode.toInt()

                if (remoteCode > currentCode && apkUrl.isNotBlank()) {
                    UpdateInfo(remoteCode, remoteName, apkUrl, changelog, force)
                } else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}