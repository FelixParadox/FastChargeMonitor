package id.fastcharge.monitor.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import id.fastcharge.monitor.data.SysfsReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DiagnosticsFragment : Fragment() {
    private lateinit var reader: BatteryReader
    private lateinit var tvSummary: TextView
    private lateinit var tvSources: TextView
    private lateinit var tvThermal: TextView
    private lateinit var tvErrors: TextView
    private lateinit var tvAdvice: TextView
    private var pollJob: Job? = null
    private var latestReport = "Belum ada laporan diagnostik."

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(R.layout.fragment_diagnostics, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        reader = BatteryReader(requireContext().applicationContext)
        tvSummary = view.findViewById(R.id.tvDiagSummary)
        tvSources = view.findViewById(R.id.tvDiagSources)
        tvThermal = view.findViewById(R.id.tvDiagThermal)
        tvErrors = view.findViewById(R.id.tvDiagErrors)
        tvAdvice = view.findViewById(R.id.tvDiagAdvice)
        view.findViewById<MaterialButton>(R.id.btnCopyReport).setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("FastCharge diagnostic report", latestReport))
            Toast.makeText(requireContext(), "Laporan disalin", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<MaterialButton>(R.id.btnRefreshDiag).setOnClickListener { refreshNow() }
        refreshNow()
        pollJob = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                delay(2500L)
                refreshNow()
            }
        }
    }

    private fun refreshNow() {
        viewLifecycleOwner.lifecycleScope.launch {
            val pair = withContext(Dispatchers.IO) {
                runCatching { reader.read() } to runCatching { SysfsReader.scan() }
            }
            val dataResult = pair.first
            val scanResult = pair.second
            if (dataResult.isFailure) {
                tvSummary.text = "Pembacaan gagal: ${dataResult.exceptionOrNull()?.javaClass?.simpleName ?: "error"}"
                tvErrors.text = dataResult.exceptionOrNull()?.message ?: "Tidak ada detail error."
                return@launch
            }
            val d = dataResult.getOrThrow()
            val scan = scanResult.getOrNull()
            val now = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            tvSummary.text = buildString {
                append("Pembaruan terakhir: ").append(now).append('\n')
                append("Baterai: ").append(if (d.percent in 0..100) "${d.percent}%" else "tidak diketahui").append('\n')
                append("Status: ").append(when { d.isFull -> "Penuh"; d.isCharging -> "Mengisi daya"; d.isPluggedIn -> "Terhubung"; else -> "Memakai baterai" }).append('\n')
                append("Arus: ").append(d.currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "tidak tersedia").append('\n')
                append("Daya: ").append(d.powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "tidak tersedia").append('\n')
                append("Tegangan: ").append(if (d.voltageMv > 0) "${d.voltageMv} mV" else "tidak tersedia").append('\n')
                append("Suhu: ").append(d.temperatureC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "tidak tersedia")
            }
            tvSources.text = buildString {
                append("Sumber arus: ").append(d.currentSource ?: "tidak ditemukan").append("\n\n")
                if (scan == null || scan.supplies.isEmpty()) append("Tidak ada power-supply sysfs yang dapat dibaca.")
                else scan.supplies.forEach { s ->
                    append("• ").append(s.name).append(" [").append(s.type).append("]")
                    s.online?.let { append(" · ").append(if (it) "online" else "offline") }
                    append('\n')
                    append("  current_now: ").append(s.currentUa?.let { "$it µA" } ?: "—").append('\n')
                    append("  voltage_now: ").append(s.voltageUv?.let { "$it µV" } ?: "—").append('\n')
                    append("  power_now: ").append(s.powerUw?.let { "$it µW" } ?: "—").append("\n\n")
                }
            }
            tvThermal.text = scan?.thermalSensors?.takeIf { it.isNotEmpty() }?.joinToString("\n") { (name, c) ->
                "$name  ·  ${String.format(Locale.US, "%.1f °C", c)}"
            } ?: "Sensor thermal tambahan tidak tersedia atau dibatasi sistem."
            val errors = buildList {
                d.errorInfo?.takeIf { it.isNotBlank() }?.let { add(it) }
                scan?.errors?.let { addAll(it) }
                scan?.supplies?.flatMap { it.errors }?.let { addAll(it) }
            }.distinct()
            tvErrors.text = errors.joinToString("\n").ifBlank { "Tidak ada error pembacaan yang dilaporkan. Catatan: sensor yang tidak diekspos kernel tetap tidak bisa dibaca oleh aplikasi biasa." }
            tvAdvice.text = when {
                d.temperatureC != null && d.temperatureC!!.toDouble() >= 45.0 -> "Suhu baterai tinggi. Hentikan beban berat, lepaskan charger jika aman, dan biarkan perangkat mendingin."
                d.isCharging && d.powerW != null && d.powerW!! < 2.0 -> "Daya terukur rendah. Periksa kabel, adaptor, port, suhu perangkat, dan apakah layar atau aplikasi sedang memakai daya tinggi."
                d.isCharging -> "Pantau tren daya selama beberapa menit. Angka daya baterai tidak selalu sama dengan daya output adaptor karena rugi konversi dan konsumsi perangkat."
                else -> "Sambungkan charger untuk mengamati perubahan arus dan daya. Hindari menyimpulkan protokol fast charging hanya dari status terhubung."
            }
            latestReport = "FastCharge Pro Diagnostic Report\nTime: $now\n\n${tvSummary.text}\n\nPower supplies:\n${tvSources.text}\n\nThermal sensors:\n${tvThermal.text}\n\nDiagnostics:\n${tvErrors.text}\n\nAdvice:\n${tvAdvice.text}"
        }
    }

    override fun onDestroyView() {
        pollJob?.cancel()
        pollJob = null
        super.onDestroyView()
    }
}
