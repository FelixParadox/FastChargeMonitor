package id.fastcharge.monitor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import id.fastcharge.monitor.data.BatteryRepository
import id.fastcharge.monitor.ui.GraphFragment
import id.fastcharge.monitor.ui.HomeFragment

class MainActivity : AppCompatActivity() {

    private var currentTag: String? = null
    private lateinit var repo: BatteryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        repo = BatteryRepository.get(this)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        if (savedInstanceState == null) {
            loadFragment(HomeFragment(), "home")
            bottomNav.selectedItemId = R.id.nav_home
        } else {
            currentTag = savedInstanceState.getString(KEY_TAG)
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { loadFragment(HomeFragment(), "home"); true }
                R.id.nav_graph -> { loadFragment(GraphFragment(), "graph"); true }
                else -> false
            }
        }
    }

    override fun onStart() { super.onStart(); repo.start() }
    override fun onStop() { super.onStop(); repo.stop() }

    private fun loadFragment(fragment: Fragment, tag: String) {
        if (currentTag == tag && supportFragmentManager.findFragmentByTag(tag) != null) return
        currentTag = tag
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment, tag)
            .commit()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        currentTag?.let { outState.putString(KEY_TAG, it) }
    }

    companion object { private const val KEY_TAG = "current_fragment_tag" }
}