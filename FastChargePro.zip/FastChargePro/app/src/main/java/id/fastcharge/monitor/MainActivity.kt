package id.fastcharge.monitor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import id.fastcharge.monitor.data.ApkDownloader
import id.fastcharge.monitor.data.ApkInstaller
import id.fastcharge.monitor.data.UpdateChecker
import id.fastcharge.monitor.data.UpdateWorker
import id.fastcharge.monitor.ui.GraphFragment
import id.fastcharge.monitor.ui.HomeFragment
import id.fastcharge.monitor.ui.SettingsActivity
import id.fastcharge.monitor.ui.UpdateDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val REQ_INSTALL_PERMISSION = 1001
    private var pendingApkPath: String? = null

    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: PlayerView
    private lateinit var bgOverlay: View
    private var exoPlayer: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        UpdateWorker.schedule(this)

        bgImage = findViewById(R.id.bgImage)
        bgVideo = findViewById(R.id.bgVideo)
        bgOverlay = findViewById(R.id.bgOverlay)

        findViewById<ImageView>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        if (savedInstanceState == null) loadFragment(HomeFragment())

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { loadFragment(HomeFragment()); true }
                R.id.nav_graph -> { loadFragment(GraphFragment()); true }
                else -> false
            }
        }
        checkForUpdates()
    }

    override fun onResume() {
        super.onResume()
        applyCustomBackground()
    }

    private fun applyCustomBackground() {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        val bgType = prefs.getString("bg_type", "default")
        val bgUriString = prefs.getString("bg_uri", null)

        bgImage.visibility = View.GONE
        bgVideo.visibility = View.GONE
        bgOverlay.visibility = View.GONE
        exoPlayer?.release()
        exoPlayer = null

        if (bgType == "default" || bgUriString == null) return

        val uri = Uri.parse(bgUriString)
        bgOverlay.visibility = View.VISIBLE

        if (bgType == "image") {
            bgImage.visibility = View.VISIBLE
            Glide.with(this).load(uri).into(bgImage)
        } else if (bgType == "video") {
            bgVideo.visibility = View.VISIBLE
            exoPlayer = ExoPlayer.Builder(this).build().also { player ->
                bgVideo.player = player
                player.setMediaItem(MediaItem.fromUri(uri))
                player.prepare()
                player.playWhenReady = true
                player.repeatMode = ExoPlayer.REPEAT_MODE_ALL
                player.volume = 0f
            }
        }
    }

    override fun onPause() {
        super.onPause()
        exoPlayer?.pause()
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private var pendingDialog: UpdateDialog? = null
    private fun checkForUpdates() {
        lifecycleScope.launch {
            val checker = UpdateChecker(this@MainActivity)
            val info = checker.checkForUpdate() ?: return@launch
            val dialog = UpdateDialog(this@MainActivity, info, { startDownload(info.apkUrl) }, {})
            pendingDialog = dialog
            dialog.show()
        }
    }

    private fun startDownload(apkUrl: String) {
        lifecycleScope.launch {
            if (!ApkInstaller.canInstall(this@MainActivity)) {
                pendingApkPath = apkUrl
                ApkInstaller.requestInstallPermission(this@MainActivity)
                return@launch
            }
            val apk = ApkDownloader(this@MainActivity).download(apkUrl) { pct ->
                runOnUiThread { pendingDialog?.updateProgress(pct) }
            }
            withContext(Dispatchers.Main) {
                if (apk != null) {
                    pendingDialog?.dismiss()
                    ApkInstaller.install(this@MainActivity, apk)
                } else Toast.makeText(this@MainActivity, "Download gagal", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_INSTALL_PERMISSION) {
            if (ApkInstaller.canInstall(this)) pendingApkPath?.let { startDownload(it) }
        }
    }
}