package id.fastcharge.monitor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import id.fastcharge.monitor.data.ApkDownloader
import id.fastcharge.monitor.data.ApkInstaller
import id.fastcharge.monitor.data.UpdateChecker
import id.fastcharge.monitor.data.UpdateWorker
import id.fastcharge.monitor.ui.GraphFragment
import id.fastcharge.monitor.ui.DiagnosticsFragment
import id.fastcharge.monitor.ui.HomeFragment
import id.fastcharge.monitor.ui.SettingsActivity
import id.fastcharge.monitor.ui.UpdateDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_INSTALL_PERMISSION = 1001
        private const val TAG = "MainActivity"
    }

    private var pendingApkUrl: String? = null

    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: PlayerView
    private lateinit var bgOverlay: View
    private var exoPlayer: ExoPlayer? = null
    private var pendingDialog: UpdateDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        UpdateWorker.schedule(this)

        bgImage = findViewById(R.id.bgImage)
        bgVideo = findViewById(R.id.bgVideo)
        bgOverlay = findViewById(R.id.bgOverlay)

        findViewById<ImageView>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
            bottomNav.selectedItemId = R.id.nav_home
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { loadFragment(HomeFragment()); true }
                R.id.nav_graph -> { loadFragment(GraphFragment()); true }
                R.id.nav_diagnostics -> { loadFragment(DiagnosticsFragment()); true }
                else -> false
            }
        }
        checkForUpdates()
    }

    override fun onResume() {
        super.onResume()
        applyCustomBackground()
        // Resume video if visible
        if (bgVideo.visibility == View.VISIBLE) exoPlayer?.play()
    }

    private fun applyCustomBackground() {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        val bgType = prefs.getString("bg_type", "default") ?: "default"
        val bgUriString = prefs.getString("bg_uri", null)

        bgImage.visibility = View.GONE
        bgVideo.visibility = View.GONE
        bgOverlay.visibility = View.GONE
        exoPlayer?.release()
        exoPlayer = null

        if (bgType == "default" || bgUriString.isNullOrEmpty()) return

        try {
            val uri = Uri.parse(bgUriString)
            bgOverlay.visibility = View.VISIBLE

            when (bgType) {
                "image" -> {
                    bgImage.visibility = View.VISIBLE
                    Glide.with(this).load(uri).into(bgImage)
                }
                "video" -> {
                    bgVideo.visibility = View.VISIBLE
                    exoPlayer = ExoPlayer.Builder(this).build().also { player ->
                        bgVideo.player = player
                        player.setMediaItem(MediaItem.fromUri(uri))
                        player.prepare()
                        player.playWhenReady = true
                        player.repeatMode = ExoPlayer.REPEAT_MODE_ALL
                        player.volume = 0f
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply background", e)
            bgImage.visibility = View.GONE
            bgVideo.visibility = View.GONE
            bgOverlay.visibility = View.GONE
        }
    }

    override fun onPause() {
        super.onPause()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayer?.release()
        exoPlayer = null
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun checkForUpdates() {
        lifecycleScope.launch {
            val checker = UpdateChecker(this@MainActivity)
            val info = checker.checkForUpdate() ?: return@launch
            if (isFinishing || isDestroyed) return@launch
            val dialog = UpdateDialog(
                this@MainActivity, info,
                onDownload = { startDownload(info.apkUrl) },
                onDismiss = { pendingDialog = null }
            )
            pendingDialog = dialog
            dialog.show()
        }
    }

    private fun startDownload(apkUrl: String) {
        lifecycleScope.launch {
            if (!ApkInstaller.canInstall(this@MainActivity)) {
                pendingApkUrl = apkUrl
                ApkInstaller.requestInstallPermission(this@MainActivity)
                return@launch
            }
            val apk = ApkDownloader(this@MainActivity).download(apkUrl) { pct ->
                runOnUiThread { pendingDialog?.updateProgress(pct) }
            }
            withContext(Dispatchers.Main) {
                if (apk != null) {
                    pendingDialog?.dismiss()
                    ApkInstaller.install(this@MainActivity, apk)
                } else {
                    Toast.makeText(this@MainActivity, "Download gagal", Toast.LENGTH_SHORT).show()
                    pendingDialog?.dismiss()
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_INSTALL_PERMISSION) {
            val url = pendingApkUrl
            pendingApkUrl = null
            if (ApkInstaller.canInstall(this) && url != null) {
                startDownload(url)
            }
        }
    }
}