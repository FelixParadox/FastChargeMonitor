package id.fastcharge.monitor

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import id.fastcharge.monitor.data.ApkDownloader
import id.fastcharge.monitor.data.ApkInstaller
import id.fastcharge.monitor.data.UpdateChecker
import id.fastcharge.monitor.data.UpdateWorker
import id.fastcharge.monitor.ui.GraphFragment
import id.fastcharge.monitor.ui.HomeFragment
import id.fastcharge.monitor.ui.UpdateDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val REQ_INSTALL_PERMISSION = 1001
    private var pendingApkPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        UpdateWorker.schedule(this)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> { loadFragment(HomeFragment()); true }
                R.id.nav_graph -> { loadFragment(GraphFragment()); true }
                else -> false
            }
        }

        // ✅ Cek update otomatis saat app dibuka
        checkForUpdates()
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private var pendingDialog: UpdateDialog? = null

private fun checkForUpdates() {
    lifecycleScope.launch {
        val checker = UpdateChecker(this@MainActivity)
        val info = checker.checkForUpdate() ?: return@launch

        val dialog = UpdateDialog(
            context = this@MainActivity,
            info = info,
            onDownload = { startDownload(info.apkUrl) },   // ✅ tanpa parameter dialog
            onDismiss = { /* user click nanti */ }
        )
        pendingDialog = dialog
        dialog.show()
    }
}

private fun startDownload(apkUrl: String) {
    lifecycleScope.launch {
        if (!ApkInstaller.canInstall(this@MainActivity)) {
            pendingApkPath = apkUrl
            ApkInstaller.requestInstallPermission(this@MainActivity)
            return@launch
        }

        val downloader = ApkDownloader(this@MainActivity)
        val apk = downloader.download(apkUrl) { pct ->
            runOnUiThread { pendingDialog?.updateProgress(pct) }
        }

        withContext(Dispatchers.Main) {
            if (apk != null) {
                pendingDialog?.dismiss()
                pendingDialog = null
                ApkInstaller.install(this@MainActivity, apk)
            } else {
                Toast.makeText(this@MainActivity, "Download gagal", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

override fun onRequestPermissionsResult(
    requestCode: Int, permissions: Array<out String>, grantResults: IntArray
) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    if (requestCode == REQ_INSTALL_PERMISSION) {
        if (ApkInstaller.canInstall(this)) {
            pendingApkPath?.let { startDownload(it) }   // ✅ langsung download
            pendingApkPath = null
        } else {
            Toast.makeText(this, "Izin install diperlukan", Toast.LENGTH_LONG).show()
        }
    }
}
}