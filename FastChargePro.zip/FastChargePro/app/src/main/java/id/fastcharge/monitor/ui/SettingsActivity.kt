package id.fastcharge.monitor.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import id.fastcharge.monitor.R

class SettingsActivity : AppCompatActivity() {

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                // Ambil izin permanen (jika memakai ACTION_OPEN_DOCUMENT)
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                saveBackground("image", uri.toString())
            }
        }
    }

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                saveBackground("video", uri.toString())
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        
        val rbDefault = findViewById<RadioButton>(R.id.rbDefault)
        val rbImage = findViewById<RadioButton>(R.id.rbImage)
        val rbVideo = findViewById<RadioButton>(R.id.rbVideo)
        val btnPickImage = findViewById<Button>(R.id.btnPickImage)
        val btnPickVideo = findViewById<Button>(R.id.btnPickVideo)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // Load state
        when(prefs.getString("bg_type", "default")) {
            "image" -> rbImage.isChecked = true
            "video" -> rbVideo.isChecked = true
            else -> rbDefault.isChecked = true
        }

        rbDefault.setOnClickListener { saveBackground("default", null) }
        
        btnPickImage.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
            }
            pickImageLauncher.launch(intent)
        }

        btnPickVideo.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
            }
            pickVideoLauncher.launch(intent)
        }

        btnBack.setOnClickListener { finish() }
    }

    private fun saveBackground(type: String, uri: String?) {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        prefs.edit().apply {
            putString("bg_type", type)
            if (uri != null) putString("bg_uri", uri)
            apply()
        }
        Toast.makeText(this, "Background diperbarui!", Toast.LENGTH_SHORT).show()
        // Restart MainActivity agar background langsung berubah
        finish()
    }
}