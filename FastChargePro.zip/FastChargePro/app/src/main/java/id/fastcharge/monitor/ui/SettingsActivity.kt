package id.fastcharge.monitor.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import id.fastcharge.monitor.R

class SettingsActivity : AppCompatActivity() {

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                takePersist(uri)
                saveBackground("image", uri.toString())
            }
        }
    }

    private val pickVideoLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                takePersist(uri)
                saveBackground("video", uri.toString())
            }
        }
    }

    private fun takePersist(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some providers don't support persistable permission
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        val rbDefault = findViewById<RadioButton>(R.id.rbDefault)
        val rbImage = findViewById<RadioButton>(R.id.rbImage)
        val rbVideo = findViewById<RadioButton>(R.id.rbVideo)
        val btnPickImage = findViewById<Button>(R.id.btnPickImage)
        val btnPickVideo = findViewById<Button>(R.id.btnPickVideo)
        val btnBack = findViewById<Button>(R.id.btnBack)

        when (prefs.getString("bg_type", "default")) {
            "image" -> rbImage.isChecked = true
            "video" -> rbVideo.isChecked = true
            else -> rbDefault.isChecked = true
        }

        rbDefault.setOnClickListener { saveBackground("default", null) }
        rbImage.setOnClickListener {
            if (prefs.getString("bg_uri", null) == null) pickImage()
        }
        rbVideo.setOnClickListener {
            if (prefs.getString("bg_uri", null) == null) pickVideo()
        }

        btnPickImage.setOnClickListener { pickImage() }
        btnPickVideo.setOnClickListener { pickVideo() }
        btnBack.setOnClickListener { finish() }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        pickImageLauncher.launch(intent)
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "video/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        pickVideoLauncher.launch(intent)
    }

    private fun saveBackground(type: String, uri: String?) {
        getSharedPreferences("app_settings", MODE_PRIVATE).edit().apply {
            putString("bg_type", type)
            if (uri != null) putString("bg_uri", uri) else remove("bg_uri")
            apply()
        }
        Toast.makeText(this, "Background diperbarui!", Toast.LENGTH_SHORT).show()
        finish()
    }
}