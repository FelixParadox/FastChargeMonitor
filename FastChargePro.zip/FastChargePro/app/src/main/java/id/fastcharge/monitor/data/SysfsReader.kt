package id.fastcharge.monitor.data

import java.io.File
import java.util.Locale
import kotlin.math.abs

/** Pembaca sysfs read-only. Nilai yang tidak tersedia tidak dibuat-buat. */
object SysfsReader {
    data class Supply(
        val name: String,
        val path: String,
        val type: String,
        val online: Boolean?,
        val currentUa: Long?,
        val voltageUv: Long?,
        val powerUw: Long?,
        val temperatureTenthsC: Long?,
        val chargeType: String?,
        val usbType: String?,
        val readableAttributes: Map<String, String>,
        val errors: List<String>
    )

    data class Scan(
        val supplies: List<Supply>,
        val thermalSensors: List<Pair<String, Double>>,
        val errors: List<String>
    )

    private val watchedAttributes = listOf(
        "type", "present", "online", "status", "health", "capacity", "capacity_level",
        "technology", "temp", "temp_now", "voltage_now", "voltage_avg", "voltage_max",
        "current_now", "current_avg", "current_max", "power_now", "power_avg",
        "charge_now", "charge_full", "charge_full_design", "charge_counter", "cycle_count",
        "charge_type", "usb_type", "input_current_limit", "input_voltage_limit",
        "constant_charge_current", "constant_charge_current_max", "constant_charge_voltage",
        "charge_control_limit", "charge_control_limit_max", "uevent"
    )

    fun readText(path: String): String? = readText(File(path))

    private fun readText(file: File): String? = try {
        if (file.isFile && file.canRead()) file.readText().trim().takeIf(String::isNotEmpty) else null
    } catch (_: Exception) {
        null
    }

    private fun readLong(dir: File, name: String): Long? =
        readText(File(dir, name))?.toLongOrNull()

    fun scan(): Scan {
        val errors = mutableListOf<String>()
        val root = File("/sys/class/power_supply")
        val dirs = try {
            if (root.isDirectory && root.canRead()) {
                root.listFiles()?.filter { it.isDirectory }.orEmpty()
            } else {
                errors += "SYSFS_POWER_SUPPLY_UNAVAILABLE: ${root.path} tidak dapat dibaca"
                emptyList()
            }
        } catch (e: Exception) {
            errors += "SYSFS_SCAN_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            emptyList()
        }

        val supplies = dirs.map { dir ->
            val localErrors = mutableListOf<String>()
            val values = linkedMapOf<String, String>()

            watchedAttributes.forEach { key ->
                val file = File(dir, key)
                if (file.exists()) {
                    val value = readText(file)
                    if (value != null) values[key] = value
                    else localErrors += "SYSFS_UNREADABLE: ${file.path} (izin atau pembacaan ditolak)"
                }
            }

            val kind = classify(dir.name, values["type"].orEmpty())
            Supply(
                name = dir.name,
                path = dir.absolutePath,
                type = kind,
                online = values["online"]?.toLongOrNull()?.let { it > 0L },
                currentUa = values["current_now"]?.toLongOrNull(),
                voltageUv = values["voltage_now"]?.toLongOrNull(),
                powerUw = values["power_now"]?.toLongOrNull(),
                temperatureTenthsC = values["temp"]?.toLongOrNull()
                    ?: values["temp_now"]?.toLongOrNull(),
                chargeType = values["charge_type"],
                usbType = values["usb_type"],
                readableAttributes = values,
                errors = localErrors
            )
        }

        return Scan(supplies, scanThermal(), errors)
    }

    private fun classify(name: String, rawType: String): String {
        val value = "$name $rawType".lowercase(Locale.ROOT)
        return when {
            value.contains("battery") || value.contains("bms") -> "battery"
            value.contains("wireless") || value.contains("qi") -> "wireless"
            value.contains("usb") || value.contains("typec") || value.contains("type-c") -> "usb"
            rawType.equals("Mains", ignoreCase = true) || value.contains("charger") ||
                value.contains("ac-adapter") || value.contains("mains") -> "ac"
            else -> "other"
        }
    }

    private fun scanThermal(): List<Pair<String, Double>> {
        val root = File("/sys/class/thermal")
        val result = mutableListOf<Pair<String, Double>>()
        try {
            root.listFiles().orEmpty()
                .filter { it.name.startsWith("thermal_zone") }
                .take(64)
                .forEach { zone ->
                    val raw = readLong(zone, "temp") ?: return@forEach
                    val label = readText(File(zone, "type")) ?: zone.name
                    // Kebanyakan kernel Linux melaporkan millidegree C; sebagian memakai 0.1 C.
                    val celsius = when {
                        abs(raw) >= 1000L -> raw / 1000.0
                        abs(raw) >= 100L -> raw / 10.0
                        else -> raw.toDouble()
                    }
                    if (celsius in -30.0..150.0) result += label to celsius
                }
        } catch (_: Exception) {
            // Sensor thermal bersifat opsional; kegagalannya tidak menghentikan pembacaan baterai.
        }
        return result
    }
}
