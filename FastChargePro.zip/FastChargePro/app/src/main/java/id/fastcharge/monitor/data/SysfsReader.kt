package id.fastcharge.monitor.data

import java.io.File
import java.util.Locale
import kotlin.math.abs

/** Read-only sysfs scanner. Missing/blocked attributes are reported, never fabricated. */
object SysfsReader {
    data class Supply(
        val name: String,
        val path: String,
        val type: String,
        val online: Boolean?,
        val currentUa: Long?,
        val voltageUv: Long?,
        val powerUw: Long?,
        val temperatureTenthsC: Long?,
        val chargeType: String?,
        val usbType: String?,
        val readableAttributes: Map<String, String>,
        val errors: List<String>
    )

    data class ClassDevice(
        val className: String,
        val deviceName: String,
        val path: String,
        val category: String,
        val readableAttributes: Map<String, String>,
        val supportedMetrics: List<String>,
        val errors: List<String>
    )

    data class Scan(
        val supplies: List<Supply>,
        val thermalSensors: List<Pair<String, Double>>,
        val classDevices: List<ClassDevice>,
        val errors: List<String>
    )

    private val watchedAttributes = listOf(
        "type", "present", "online", "status", "health", "capacity", "capacity_level",
        "technology", "temp", "temp_now", "voltage_now", "voltage_avg", "voltage_max",
        "current_now", "current_avg", "current_max", "power_now", "power_avg",
        "charge_now", "charge_full", "charge_full_design", "charge_counter", "cycle_count",
        "charge_type", "usb_type", "input_current_limit", "input_voltage_limit",
        "constant_charge_current", "constant_charge_current_max", "constant_charge_voltage",
        "charge_control_limit", "charge_control_limit_max", "uevent"
    )

    fun readText(path: String): String? = readText(File(path))

    private fun readText(file: File): String? = try {
        if (file.exists()) {
            file.bufferedReader().use { br ->
                val s = br.readLine()?.trim()
                s?.takeIf { it.isNotEmpty() }
            }
        } else null
    } catch (_: SecurityException) {
        null
    } catch (_: Exception) {
        null
    }

    private fun readLong(dir: File, name: String): Long? = readText(File(dir, name))?.toLongOrNull()

    fun scan(): Scan {
        val errors = mutableListOf<String>()
        val root = File("/sys/class/power_supply")
        val dirs = try {
            if (root.isDirectory && root.canRead()) root.listFiles()?.filter { it.isDirectory }.orEmpty()
            else {
                errors += "SYSFS_POWER_SUPPLY_UNAVAILABLE: ${root.path} tidak dapat dibaca"
                emptyList()
            }
        } catch (e: Exception) {
            errors += "SYSFS_SCAN_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            emptyList()
        }

        val supplies = dirs.map { dir ->
            val localErrors = mutableListOf<String>()
            val values = linkedMapOf<String, String>()
            watchedAttributes.forEach { key ->
                val f = File(dir, key)
                if (f.exists()) {
                    val value = readText(f)
                    if (value != null) values[key] = value
                    else localErrors += "SYSFS_UNREADABLE: ${f.path} (izin atau pembacaan ditolak)"
                }
            }
            val rawType = values["type"].orEmpty()
            val kind = classify(dir.name, rawType)
            val online = values["online"]?.toLongOrNull()?.let { it > 0L }
            Supply(
                name = dir.name,
                path = dir.absolutePath,
                type = kind,
                online = online,
                currentUa = values["current_now"]?.toLongOrNull(),
                voltageUv = values["voltage_now"]?.toLongOrNull(),
                powerUw = values["power_now"]?.toLongOrNull(),
                temperatureTenthsC = values["temp"]?.toLongOrNull() ?: values["temp_now"]?.toLongOrNull(),
                chargeType = values["charge_type"],
                usbType = values["usb_type"],
                readableAttributes = values,
                errors = localErrors
            )
        }
        return Scan(supplies, scanThermal(), scanRelevantClasses(errors), errors)
    }

    /**
     * Discovers battery-related devices exposed under /sys/class instead of assuming
     * one vendor-specific path. Read-only and bounded: only class entries and one
     * device-directory level are inspected, with a small allow-list of attributes.
     */
    private fun scanRelevantClasses(errors: MutableList<String>): List<ClassDevice> {
        val classRoot = File("/sys/class")
        val out = mutableListOf<ClassDevice>()
        val attrs = listOf(
            "type", "name", "label", "status", "health", "capacity", "temp", "temp_now",
            "temperature", "voltage_now", "voltage_avg", "current_now", "current_avg",
            "power_now", "charge_now", "charge_full", "charge_counter", "cycle_count",
            "present", "online", "uevent", "model_name", "manufacturer", "technology"
        )
        val interesting = Regex("(?i)(batt|power|charg|thermal|hwmon|fuel|usb|typec|type-c|charger|battery|wakeup)")
        try {
            val classes = classRoot.listFiles()?.filter { it.name.contains(interesting) }.orEmpty()
            classes.forEach { classDir ->
                val classDevices = mutableListOf<File>()
                classDevices += classDir
                try { classDir.listFiles()?.filter { it.isDirectory }?.take(48)?.let { classDevices.addAll(it) } } catch (_: Exception) { }
                classDevices.take(64).forEach { dir ->
                    val values = linkedMapOf<String, String>()
                    val localErrors = mutableListOf<String>()
                    attrs.forEach { key ->
                        val f = File(dir, key)
                        if (f.exists()) {
                            val value = readText(f)
                            if (value != null) values[key] = value
                            else localErrors += "SYSFS_UNREADABLE: ${f.path}"
                        }
                    }
                    val text = (classDir.name + " " + dir.name + " " + values.entries.joinToString(" ") { "${it.key}=${it.value}" }).lowercase(Locale.ROOT)
                    val category = when {
                        text.contains("thermal") || text.contains("temp") || values.keys.any { it == "temp" || it == "temp_now" || it == "temperature" } -> "temperature"
                        text.contains("battery") || text.contains("bms") || text.contains("fuelgauge") || values.containsKey("capacity") || values.containsKey("charge_now") -> "battery"
                        text.contains("charger") || text.contains("usb") || text.contains("typec") || text.contains("power_supply") -> "charging/power"
                        text.contains("hwmon") -> "hardware monitor"
                        else -> "related"
                    }
                    val metrics = buildList {
                        if (listOf("temp", "temp_now", "temperature").any { values.containsKey(it) }) add("suhu")
                        if (listOf("current_now", "current_avg").any { values.containsKey(it) }) add("arus")
                        if (listOf("voltage_now", "voltage_avg").any { values.containsKey(it) }) add("tegangan")
                        if (values.containsKey("power_now")) add("daya")
                        if (values.containsKey("capacity")) add("persentase")
                        if (values.containsKey("status")) add("status")
                        if (values.containsKey("health")) add("kesehatan")
                        if (values.containsKey("charge_now") || values.containsKey("charge_counter")) add("muatan")
                        if (values.containsKey("cycle_count")) add("siklus")
                    }
                    if (values.isNotEmpty() || category != "related") {
                        out += ClassDevice(classDir.name, dir.name, dir.absolutePath, category, values, metrics, localErrors)
                    }
                }
            }
        } catch (e: Exception) {
            errors += "SYSFS_CLASS_SCAN_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
        }
        return out.distinctBy { it.path }.take(160)
    }

    /** Picks a value only from a readable, relevant attribute; never invents a fallback. */
    fun selectCompatibleAttribute(scan: Scan, metric: String, attributeNames: List<String>): Pair<String, String>? {
        val candidates = scan.classDevices.mapNotNull { device ->
            val pair = attributeNames.firstNotNullOfOrNull { key -> device.readableAttributes[key]?.let { key to it } }
                ?: return@mapNotNull null
            val raw = pair.second.toLongOrNull() ?: return@mapNotNull null
            if (raw == 0L && metric == "temperature") return@mapNotNull null
            val score = (if (device.category == "battery") 4 else 0) +
                (if (device.className.contains("power_supply", true)) 3 else 0) +
                (if (device.deviceName.contains("battery", true) || device.deviceName.contains("bms", true)) 2 else 0)
            Triple(device, pair, score)
        }.sortedByDescending { it.third }
        val chosen = candidates.firstOrNull() ?: return null
        return "${chosen.first.path}/${chosen.second.first}" to chosen.second.second
    }

    private fun classify(name: String, rawType: String): String {
        val s = "$name $rawType".lowercase(Locale.ROOT)
        return when {
            s.contains("battery") || s.contains("bms") -> "battery"
            s.contains("wireless") || s.contains("qi") -> "wireless"
            s.contains("usb") || s.contains("typec") || s.contains("type-c") -> "usb"
            rawType.equals("Mains", true) || s.contains("charger") || s.contains("ac-adapter") || s.contains("mains") -> "ac"
            else -> "other"
        }
    }

    private fun scanThermal(): List<Pair<String, Double>> {
        val root = File("/sys/class/thermal")
        val out = mutableListOf<Pair<String, Double>>()
        try {
            root.listFiles().orEmpty().filter { it.name.startsWith("thermal_zone") }.take(64).forEach { zone ->
                val raw = readLong(zone, "temp") ?: return@forEach
                val label = readText(File(zone, "type")) ?: zone.name
                val magnitude = abs(raw)
                val c = when {
                    magnitude in 10000L..150000L -> raw / 1000.0 // millidegrees Celsius
                    magnitude in 100L..1500L -> raw / 10.0       // tenths of a degree
                    else -> raw.toDouble()                       // degrees Celsius
                }
                if (c in -30.0..150.0) out += label to c
            }
        } catch (_: Exception) { }
        return out
    }

    /** Linux power_supply ABI current_now is normally microamps; 0 is a real possible reading. */
    fun readDumpsysBattery(): Pair<Long?, String> {
        var process: Process? = null
        return try {
            process = Runtime.getRuntime().exec(arrayOf("/system/bin/dumpsys", "battery"))
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val exit = process.waitFor()
            if (exit != 0) return null to "DUMPSYS_EXIT_$exit: dumpsys battery gagal"
            val match = Regex("(?im)^\\s*current now\\s*:\\s*(-?\\d+)").find(output)
            val value = match?.groupValues?.getOrNull(1)?.toLongOrNull()
            if (value != null) value to "OK: dumpsys current now"
            else null to "DUMPSYS_CURRENT_UNAVAILABLE: output tidak memiliki 'current now'"
        } catch (e: Exception) {
            null to "DUMPSYS_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
        } finally {
            try { process?.destroy() } catch (_: Exception) { }
        }
    }
}