package id.fastcharge.monitor.data

import android.util.Log
import java.io.File

object SysfsReader {

    private const val TAG = "SysfsReader"

    /** Path kandidat untuk current_now */
    private val currentPaths = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/bms/current_now",
        "/sys/class/power_supply/mtk-battery/current_now",
        "/sys/class/power_supply/max170xx_battery/current_now",
        "/sys/class/power_supply/max17042-0/current_now",
        "/sys/class/power_supply/qcom-smb-battery/current_now"
    )

    /** Path kandidat untuk power_now (µW) */
    private val powerPaths = listOf(
        "/sys/class/power_supply/battery/power_now",
        "/sys/class/power_supply/bms/power_now"
    )

    /**
     * Baca current_now dan normalisasi ke **microamps (µA)**.
     *
     * Vendor berbeda:
     * - Kebanyakan: nilai µA
     * - Sebagian (mis. beberapa Samsung/MTK): nilai mA (10× lebih kecil)
     *
     * Heuristik: jika |nilai| < 50.000 → anggap mA lalu ×1000.
     * (50000 µA = 50 mA, nilai realistis minimum saat charging aktif)
     */
    fun readCurrentUa(): Long? {
        for (p in currentPaths) {
            val f = File(p)
            if (!f.exists() || !f.canRead()) continue
            val raw = try {
                f.readText().trim().toLongOrNull()
            } catch (e: Exception) {
                Log.w(TAG, "read $p failed: ${e.message}"); null
            } ?: continue

            if (raw == 0L) continue

            val normalized = normalizeToUa(raw)
            Log.d(TAG, "path=$p raw=$raw → $normalized µA")
            return normalized
        }
        return null
    }

    /** Baca power_now dan normalisasi ke **microwatts (µW)**. */
    fun readPowerUw(): Long? {
        for (p in powerPaths) {
            val f = File(p)
            if (!f.exists() || !f.canRead()) continue
            val raw = try {
                f.readText().trim().toLongOrNull()
            } catch (e: Exception) { null } ?: continue
            if (raw == 0L) continue
            return raw
        }
        return null
    }

    /**
     * Heuristik konversi nilai mentah ke µA.
     * - |raw| >= 50000 → asumsi sudah µA
     * - |raw| <  50000 → asumsi mA, ×1000
     */
    private fun normalizeToUa(raw: Long): Long {
        val absVal = kotlin.math.abs(raw)
        return if (absVal >= 50_000L) raw else raw * 1000L
    }
}