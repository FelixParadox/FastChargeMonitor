package id.fastcharge.monitor.data

import java.io.File

object SysfsReader {
    private val currentPaths = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/mtk-battery/current_now",
        "/sys/class/power_supply/bms/current_now"
    )

    // Mengembalikan Pair(Value, ErrorMessage)
    fun readCurrentUaWithError(): Pair<Long?, String> {
        var lastError = "File tidak ditemukan"
        for (p in currentPaths) {
            val f = File(p)
            if (!f.exists()) {
                lastError = "No such file ($p)"
                continue
            }
            if (!f.canRead()) {
                lastError = "Permission denied ($p)"
                continue
            }
            try {
                val text = f.readText().trim()
                val value = text.toLongOrNull()
                if (value == null) {
                    lastError = "Format salah: $text"
                } else {
                    return Pair(value, "OK")
                }
            } catch (e: Exception) {
                lastError = "${e.javaClass.simpleName} ($p)"
            }
        }
        return Pair(null, lastError)
    }

    // Jalur alternatif via dumpsys (biasanya tidak butuh root, tapi sering dibatasi)
    fun readDumpsysBattery(): Pair<Long?, String> {
        return try {
            val process = Runtime.getRuntime().exec("dumpsys battery")
            val reader = process.inputStream.bufferedReader()
            var currentUa: Long? = null
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val l = line!!.trim()
                if (l.startsWith("current now:", ignoreCase = true)) {
                    val parts = l.split(":")
                    if (parts.size > 1) {
                        val valStr = parts[1].trim().split(" ")[0]
                        currentUa = valStr.toLongOrNull()
                    }
                }
            }
            reader.close()
            if (currentUa != null && currentUa != 0L) {
                Pair(currentUa, "OK")
            } else {
                Pair(null, "Nilai kosong/0")
            }
        } catch (e: Exception) {
            Pair(null, "${e.javaClass.simpleName}: ${e.message}")
        }
    }
}