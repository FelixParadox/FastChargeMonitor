package id.fastcharge.monitor.data

import java.io.File

object SysfsReader {
    private val currentPaths = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/mtk-battery/current_now",
        "/sys/class/power_supply/bms/current_now"
    )

    fun readCurrentUa(): Long? {
        for (p in currentPaths) {
            val f = File(p)
            if (f.exists() && f.canRead()) {
                return try {
                    f.readText().trim().toLongOrNull()
                } catch (_: Exception) { null }
            }
        }
        return null
    }
}