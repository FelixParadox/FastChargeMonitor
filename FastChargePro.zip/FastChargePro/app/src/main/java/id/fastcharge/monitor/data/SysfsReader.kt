package id.fastcharge.monitor.data

import java.io.File
import java.util.Locale
import kotlin.math.abs

/** Read-only discovery for Android battery/power/thermal interfaces. Never writes sysfs. */
object SysfsReader {
    data class Supply(
        val name: String, val path: String, val type: String, val online: Boolean?,
        val currentUa: Long?, val voltageUv: Long?, val powerUw: Long?,
        val temperatureTenthsC: Long?, val chargeType: String?, val usbType: String?,
        val readableAttributes: Map<String, String>, val errors: List<String>
    )
    data class GenericSensor(val name: String, val path: String, val category: String, val raw: String, val interpreted: String)
    data class Scan(
        val supplies: List<Supply>, val thermalSensors: List<Pair<String, Double>>, val errors: List<String>,
        val genericSensors: List<GenericSensor> = emptyList()
    )

    private val watchedAttributes = listOf(
        "type", "present", "online", "status", "health", "capacity", "capacity_level", "technology",
        "temp", "temp_now", "voltage_now", "voltage_avg", "voltage_max", "current_now", "current_avg",
        "current_max", "power_now", "power_avg", "charge_now", "charge_full", "charge_full_design",
        "charge_counter", "cycle_count", "charge_type", "usb_type", "input_current_limit", "input_voltage_limit",
        "constant_charge_current", "constant_charge_current_max", "constant_charge_voltage", "charge_control_limit",
        "charge_control_limit_max", "uevent", "manufacturer", "model_name", "serial_number"
    )
    private fun readText(file: File): String? = try {
        if (!file.exists() || !file.isFile) null else file.bufferedReader().use { it.readLine()?.trim()?.takeIf(String::isNotEmpty) }
    } catch (_: Exception) { null }
    fun readText(path: String): String? = readText(File(path))
    private fun readLong(dir: File, name: String): Long? = readText(File(dir, name))?.toLongOrNull()

    fun scan(): Scan {
        val errors = mutableListOf<String>()
        val root = File("/sys/class/power_supply")
        val dirs = try {
            if (root.isDirectory && root.canRead()) root.listFiles()?.filter { it.isDirectory }.orEmpty()
            else { errors += "SYSFS_POWER_SUPPLY_UNAVAILABLE: ${root.path} tidak dapat dibaca"; emptyList() }
        } catch (e: Exception) { errors += "SYSFS_SCAN_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"; emptyList() }
        val supplies = dirs.map { dir ->
            val localErrors = mutableListOf<String>(); val values = linkedMapOf<String, String>()
            watchedAttributes.forEach { key ->
                val f = File(dir, key)
                if (f.exists()) { val value = readText(f); if (value != null) values[key] = value else localErrors += "SYSFS_UNREADABLE: ${f.path}" }
            }
            val kind = classify(dir.name, values["type"].orEmpty())
            Supply(dir.name, dir.absolutePath, kind, values["online"]?.toLongOrNull()?.let { it > 0 },
                values["current_now"]?.toLongOrNull(), values["voltage_now"]?.toLongOrNull(), values["power_now"]?.toLongOrNull(),
                values["temp"]?.toLongOrNull() ?: values["temp_now"]?.toLongOrNull(), values["charge_type"], values["usb_type"], values, localErrors)
        }
        val thermal = scanThermal()
        val generic = scanHwmon() + scanPowercap() + scanProcBattery()
        return Scan(supplies, thermal, errors, generic.distinctBy { it.path })
    }

    private fun classify(name: String, rawType: String): String {
        val s = "$name $rawType".lowercase(Locale.ROOT)
        return when {
            s.contains("battery") || s.contains("bms") -> "battery"
            s.contains("wireless") || s.contains("qi") -> "wireless"
            s.contains("usb") || s.contains("typec") || s.contains("type-c") -> "usb"
            rawType.equals("Mains", true) || s.contains("charger") || s.contains("ac-adapter") || s.contains("mains") -> "ac"
            else -> "other"
        }
    }

    private fun toCelsius(raw: Long): Double? {
        val magnitude = abs(raw)
        val c = when { magnitude in 10000L..200000L -> raw / 1000.0; magnitude in 100L..2000L -> raw / 10.0; else -> raw.toDouble() }
        return c.takeIf { it in -40.0..200.0 }
    }

    private fun scanThermal(): List<Pair<String, Double>> {
        val root = File("/sys/class/thermal"); val out = mutableListOf<Pair<String, Double>>()
        try { root.listFiles().orEmpty().filter { it.name.startsWith("thermal_zone") }.take(128).forEach { zone ->
            val raw = readLong(zone, "temp") ?: return@forEach
            val label = readText(File(zone, "type")) ?: zone.name
            toCelsius(raw)?.let { out += label to it }
        } } catch (_: Exception) { }
        return out
    }

    /** hwmon covers vendor temperature/current/voltage/power sensors not registered as power_supply. */
    private fun scanHwmon(): List<GenericSensor> {
        val out = mutableListOf<GenericSensor>(); val root = File("/sys/class/hwmon")
        try { root.listFiles().orEmpty().filter { it.isDirectory }.take(64).forEach { hw ->
            val chip = readText(File(hw, "name")) ?: hw.name
            val files = hw.listFiles().orEmpty().filter { it.isFile && Regex("(?:temp|curr|in|power)\\d+_(?:input|label)").matches(it.name) }.take(100)
            files.filter { it.name.endsWith("_input") }.forEach { f ->
                val raw = readText(f) ?: return@forEach
                val label = readText(File(hw, f.name.removeSuffix("_input") + "_label")) ?: f.name.removeSuffix("_input")
                val category = when { f.name.startsWith("temp") -> "temperature"; f.name.startsWith("curr") -> "current"; f.name.startsWith("in") -> "voltage"; else -> "power" }
                val value = raw.toLongOrNull(); val interpreted = when {
                    value == null -> raw
                    category == "temperature" -> toCelsius(value)?.let { String.format(Locale.US, "%.1f °C", it) } ?: raw
                    category == "voltage" -> if (abs(value) >= 1000) String.format(Locale.US, "%.3f V", value / 1000.0) else "$value (raw)"
                    category == "current" -> if (abs(value) >= 1000) String.format(Locale.US, "%.3f A", value / 1000.0) else "$value (raw)"
                    category == "power" -> if (abs(value) >= 1000) String.format(Locale.US, "%.3f W", value / 1_000_000.0) else "$value (raw)"
                    else -> raw
                }
                out += GenericSensor("$chip / $label", f.absolutePath, category, raw, interpreted)
            }
        } } catch (_: Exception) { }
        return out
    }

    private fun scanPowercap(): List<GenericSensor> {
        val out = mutableListOf<GenericSensor>(); val root = File("/sys/class/powercap")
        try { root.listFiles().orEmpty().filter { it.isDirectory }.take(32).forEach { zone ->
            listOf("name", "energy_uj", "max_energy_range_uj", "constraint_0_power_limit_uw").forEach { key ->
                val f = File(zone, key); val value = readText(f) ?: return@forEach
                out += GenericSensor(readText(File(zone, "name")) ?: zone.name, f.absolutePath, "powercap:$key", value,
                    if (key == "energy_uj") value.toLongOrNull()?.let { String.format(Locale.US, "%.3f J", it / 1_000_000.0) } ?: value else value)
            }
        } } catch (_: Exception) { }
        return out
    }

    private fun scanProcBattery(): List<GenericSensor> {
        val out = mutableListOf<GenericSensor>()
        listOf("/proc/driver/battery", "/proc/driver/charger", "/sys/kernel/debug/battery").forEach { path ->
            val value = readText(path) ?: return@forEach
            out += GenericSensor(File(path).name, path, "vendor-proc", value.take(1200), "Teks vendor tersedia")
        }
        return out
    }

    /** dumpsys is read-only and only a fallback: OEM output formats vary. */
    fun readDumpsysBattery(): Pair<Long?, String> {
        var process: Process? = null
        return try {
            process = Runtime.getRuntime().exec(arrayOf("/system/bin/dumpsys", "battery"))
            val output = process.inputStream.bufferedReader().use { it.readText() }; val exit = process.waitFor()
            if (exit != 0) return null to "DUMPSYS_EXIT_$exit: dumpsys battery gagal"
            val match = Regex("(?im)^\\s*current now\\s*:\\s*(-?\\d+)").find(output)
            val value = match?.groupValues?.getOrNull(1)?.toLongOrNull()
            if (value != null) value to "OK: dumpsys current now" else null to "DUMPSYS_CURRENT_UNAVAILABLE: output tidak memiliki 'current now'"
        } catch (e: Exception) { null to "DUMPSYS_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}" }
        finally { try { process?.destroy() } catch (_: Exception) { } }
    }
}
