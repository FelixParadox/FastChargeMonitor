package id.fastcharge.monitor.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ApkDownloader(private val context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(180, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun download(url: String, onProgress: (Int) -> Unit = {}): File? = withContext(Dispatchers.IO) {
        var tempFile: File? = null
        try {
            if (!url.startsWith("https://", ignoreCase = true)) return@withContext null
            val dir = File(context.cacheDir, "updates").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val apkFile = File(dir, "update.apk")
            tempFile = apkFile
            val request = Request.Builder().url(url).header("User-Agent", "FastChargePro-Updater").build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body ?: return@withContext null
                val contentType = response.header("Content-Type", "").orEmpty()
                if (contentType.contains("text/html", true)) return@withContext null
                val total = body.contentLength()
                var downloaded = 0L
                body.byteStream().use { input ->
                    FileOutputStream(apkFile).use { output ->
                        val buffer = ByteArray(16 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                            downloaded += count
                            if (total > 0) onProgress((downloaded * 100 / total).toInt().coerceIn(0, 100))
                        }
                        output.flush()
                    }
                }
            }
            // APK berformat ZIP; cek magic PK untuk menolak halaman HTML yang diunduh sebagai APK.
            if (!apkFile.isFile || apkFile.length() < 4) return@withContext null
            val magic = ByteArray(4)
            val magicCount = apkFile.inputStream().use { it.read(magic) }
            if (magicCount < 4 || magic[0] != 0x50.toByte() || magic[1] != 0x4B.toByte()) {
                apkFile.delete()
                return@withContext null
            }
            onProgress(100)
            apkFile
        } catch (_: Exception) {
            tempFile?.delete()
            null
        }
    }
}
