package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryRepository
import id.fastcharge.monitor.data.BatterySnapshot
import id.fastcharge.monitor.data.DiagnosisItem
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GraphFragment : Fragment(R.layout.fragment_graph) {

    private lateinit var repo: BatteryRepository
    private lateinit var chartPower: LineChart
    private lateinit var chartLevel: LineChart
    private lateinit var chartCurrent: LineChart
    private lateinit var chartTemp: LineChart
    private lateinit var diagContainer: LinearLayout
    private lateinit var tvSpeed: TextView
    private lateinit var tvHistoryCount: TextView

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val powerData = mutableListOf<Entry>()
    private val levelData = mutableListOf<Entry>()
    private val currentData = mutableListOf<Entry>()
    private val tempData = mutableListOf<Entry>()
    private val maxPoints = 60

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = BatteryRepository.get(requireContext())

        chartPower = view.findViewById(R.id.chartPower)
        chartLevel = view.findViewById(R.id.chartLevel)
        chartCurrent = view.findViewById(R.id.chartCurrent)
        chartTemp = view.findViewById(R.id.chartTemp)
        diagContainer = view.findViewById(R.id.diagContainer)
        tvSpeed = view.findViewById(R.id.tvSpeed)
        tvHistoryCount = view.findViewById(R.id.tvHistoryCount)

        setupChart(chartPower, "Daya (mW)", Color.parseColor("#00FF88"))
        setupChart(chartLevel, "Baterai (%)", Color.parseColor("#00D4FF"))
        setupChart(chartCurrent, "Arus (mA)", Color.parseColor("#8A2BE2"))
        setupChart(chartTemp, "Suhu (°C)", Color.parseColor("#FFB84D"))

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.snapshot.collect { s ->
                    appendPoint(powerData, s.powerMw.toFloat())
                    appendPoint(levelData, s.level.toFloat())
                    appendPoint(currentData, s.currentMa.toFloat())
                    appendPoint(tempData, s.temperatureC)

                    renderChart(chartPower, powerData)
                    renderChart(chartLevel, levelData)
                    renderChart(chartCurrent, currentData)
                    renderChart(chartTemp, tempData)

                    val speedText = if (s.isCharging) {
                        "⚡ %.2f %%/menit".format(s.chargeSpeedPctPerMin)
                    } else "—"
                    tvSpeed.text = "Kecepatan pengisian: $speedText"
                    tvHistoryCount.text = "Riwayat: ${repo.history.value.size} sampel"
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.diagnosis.collect { list ->
                    renderDiagnosis(list)
                }
            }
        }
    }

    private fun appendPoint(list: MutableList<Entry>, value: Float) {
        val x = if (list.isEmpty()) 0f else list.last().x + 1f
        list += Entry(x, value)
        while (list.size > maxPoints) list.removeAt(0)
        // re-index agar x tidak menumpuk
        list.forEachIndexed { i, e -> e.x = i.toFloat() }
    }

    private fun setupChart(chart: LineChart, label: String, color: Int) {
        chart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)
            axisRight.isEnabled = false
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.parseColor("#8B9BB4")
                gridColor = Color.parseColor("#1A2440")
                setDrawGridLines(true)
                setDrawAxisLine(false)
            }
            axisLeft.apply {
                textColor = Color.parseColor("#8B9BB4")
                gridColor = Color.parseColor("#1A2440")
                setDrawAxisLine(false)
            }
        }
    }

    private fun renderChart(chart: LineChart, data: List<Entry>) {
        if (data.isEmpty()) return
        val set = LineDataSet(data.toList(), "").apply {
            this.color = dataColorFor(chart)
            lineWidth = 2.2f
            setDrawCircles(false)
            setDrawValues(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillAlpha = 60
            fillColor = dataColorFor(chart)
        }
        chart.data = LineData(set)
        chart.notifyDataSetChanged()
        chart.invalidate()
    }

    private fun dataColorFor(chart: LineChart): Int = when (chart.id) {
        R.id.chartPower -> Color.parseColor("#00FF88")
        R.id.chartLevel -> Color.parseColor("#00D4FF")
        R.id.chartCurrent -> Color.parseColor("#8A2BE2")
        else -> Color.parseColor("#FFB84D")
    }

    private fun renderDiagnosis(items: List<DiagnosisItem>) {
        diagContainer.removeAllViews()
        items.forEach { d ->
            val card = createDiagCard(d)
            diagContainer.addView(card)
        }
    }

    private fun createDiagCard(d: DiagnosisItem): View {
        val ctx = requireContext()
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_card_glow)
        }
        val (colorHex, icon) = when (d.status) {
            DiagnosisItem.Status.NORMAL -> "#00FF88" to "✓"
            DiagnosisItem.Status.INFO -> "#00D4FF" to "ℹ"
            DiagnosisItem.Status.WARNING -> "#FFB84D" to "⚠"
            DiagnosisItem.Status.CRITICAL -> "#FF4D6D" to "✕"
            DiagnosisItem.Status.UNKNOWN -> "#8B9BB4" to "—"
        }
        val header = TextView(ctx).apply {
            text = "$icon  ${d.category}"
            setTextColor(Color.parseColor(colorHex))
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val title = TextView(ctx).apply {
            text = d.title
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            setPadding(0, 6, 0, 2)
        }
        val detail = TextView(ctx).apply {
            text = d.detail
            setTextColor(Color.parseColor("#8B9BB4"))
            textSize = 11f
        }
        card.addView(header)
        card.addView(title)
        card.addView(detail)
        if (d.recommendation.isNotBlank()) {
            val rec = TextView(ctx).apply {
                text = "→ ${d.recommendation}"
                setTextColor(Color.parseColor(colorHex))
                textSize = 11f
                setPadding(0, 6, 0, 0)
            }
            card.addView(rec)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 16 }
        card.layoutParams = lp
        return card
    }
}