package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale

class GraphFragment : Fragment() {

    private var chart: LineChart? = null
    private var tvCurrentWatt: TextView? = null
    private var tvMaxWatt: TextView? = null
    private lateinit var reader: BatteryReader

    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<Entry>()

    private var index = 0f
    private var maxWatt = 0f

    private val runnable = object : Runnable {
        override fun run() {
            val currentChart = chart ?: return

            try {
                val data = reader.read()
                val watt = data.powerW

                if (watt != null && watt.isFinite() && watt >= 0.0) {
                    val value = watt.toFloat()

                    entries.add(Entry(index++, value))

                    while (entries.size > 60) {
                        entries.removeAt(0)
                    }

                    if (value > maxWatt) {
                        maxWatt = value
                    }

                    updateChart()

                    tvCurrentWatt?.text =
                        String.format(Locale.US, "%.2f W", value)

                    tvMaxWatt?.text =
                        String.format(Locale.US, "Maks: %.2f W", maxWatt)
                } else {
                    tvCurrentWatt?.text = "-- W"

                    tvMaxWatt?.text = if (maxWatt > 0f) {
                        String.format(Locale.US, "Maks: %.2f W", maxWatt)
                    } else {
                        "Maks: -- W"
                    }

                    // Riwayat sebelumnya tetap disimpan.
                    currentChart.setNoDataText(
                        "Menunggu data daya yang valid..."
                    )
                    currentChart.invalidate()
                }
            } catch (e: Exception) {
                tvCurrentWatt?.text = "Error"
                tvMaxWatt?.text = "Gagal membaca data"

                android.util.Log.e(
                    "FastChargeGraph",
                    "Gagal memperbarui grafik",
                    e
                )
            } finally {
                if (chart != null && isAdded) {
                    handler.postDelayed(this, 1000)
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(
            R.layout.fragment_graph,
            container,
            false
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        chart = view.findViewById(R.id.chart)
        tvCurrentWatt = view.findViewById(R.id.tvCurrentWatt)
        tvMaxWatt = view.findViewById(R.id.tvMaxWatt)

        reader = BatteryReader(requireContext())

        setupChart()
        handler.removeCallbacks(runnable)
        handler.post(runnable)
    }

    private fun setupChart() {
        chart?.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(false)
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                isEnabled = false
            }

            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = Color.parseColor("#1A2440")
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                axisMinimum = 0f
            }

            axisRight.isEnabled = false
            setNoDataText("Menunggu data...")
            setNoDataTextColor(Color.parseColor("#8B9BB4"))
        }
    }

    private fun updateChart() {
        val currentChart = chart ?: return

        val dataSet = LineDataSet(entries.toList(), "Daya baterai").apply {
            color = Color.parseColor("#00FF88")
            lineWidth = 2.5f
            setDrawCircles(false)
            setDrawValues(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillColor = Color.parseColor("#00FF88")
            fillAlpha = 40
            highLightColor = Color.parseColor("#00D4FF")
        }

        currentChart.data = LineData(dataSet)
        currentChart.notifyDataSetChanged()
        currentChart.invalidate()
    }

    override fun onDestroyView() {
        handler.removeCallbacks(runnable)

        chart = null
        tvCurrentWatt = null
        tvMaxWatt = null

        super.onDestroyView()
    }
}