package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale

class GraphFragment : Fragment() {
    private var chart: LineChart? = null
    private var tvCurrentWatt: TextView? = null
    private var tvMaxWatt: TextView? = null
    private lateinit var reader: BatteryReader
    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<Entry>()
    private var index = 0f
    private var maxWatt = 0f

    private val runnable = object : Runnable {
        override fun run() {
            val chartView = chart
            val currentView = tvCurrentWatt
            val maxView = tvMaxWatt
            if (!isAdded || chartView == null || currentView == null || maxView == null) return
            try {
                val data = reader.read()
                val watts = data.powerW
                if (data.isRealData && watts != null && watts.isFinite() && watts > 0.0) {
                    val value = watts.toFloat()
                    entries.add(Entry(index++, value))
                    if (entries.size > MAX_POINTS) entries.removeAt(0)
                    maxWatt = maxOf(maxWatt, value)
                    updateChart()
                    currentView.text = String.format(Locale.US, "%.2f W", value)
                    maxView.text = String.format(Locale.US, "Maks: %.2f W", maxWatt)
                } else {
                    currentView.text = "-- W"
                    maxView.text = if (maxWatt > 0f) String.format(Locale.US, "Maks: %.2f W", maxWatt) else "Maks: -- W"
                    // Jangan hapus entries: riwayat tetap terlihat saat satu sampel gagal.
                    chartView.setNoDataText("Menunggu pembacaan daya yang valid…")
                    chartView.invalidate()
                }
            } catch (e: Exception) {
                currentView.text = "Sensor error"
                maxView.text = if (maxWatt > 0f) String.format(Locale.US, "Maks: %.2f W", maxWatt) else "Maks: -- W"
                chartView.setNoDataText("Gagal membaca sensor: ${e.javaClass.simpleName}")
                chartView.invalidate()
            } finally {
                if (isAdded && chart != null) handler.postDelayed(this, INTERVAL_MS)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_graph, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        chart = view.findViewById(R.id.chart)
        tvCurrentWatt = view.findViewById(R.id.tvCurrentWatt)
        tvMaxWatt = view.findViewById(R.id.tvMaxWatt)
        reader = BatteryReader(requireContext())
        setupChart()
        handler.removeCallbacks(runnable)
        handler.post(runnable)
    }

    private fun setupChart() {
        chart?.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(false)
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                isEnabled = false
            }
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = Color.parseColor("#1A2440")
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                axisMinimum = 0f
            }
            axisRight.isEnabled = false
            setNoDataText("Menunggu data…")
            setNoDataTextColor(Color.parseColor("#8B9BB4"))
        }
    }

    private fun updateChart() {
        val set = LineDataSet(entries.toMutableList(), "Daya baterai").apply {
            color = Color.parseColor("#00FF88")
            lineWidth = 2.5f
            setDrawCircles(false)
            setDrawValues(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillColor = Color.parseColor("#00FF88")
            fillAlpha = 40
            highLightColor = Color.parseColor("#00D4FF")
        }
        chart?.data = LineData(set)
        chart?.notifyDataSetChanged()
        chart?.invalidate()
    }

    override fun onDestroyView() {
        handler.removeCallbacks(runnable)
        chart = null
        tvCurrentWatt = null
        tvMaxWatt = null
        super.onDestroyView()
    }

    companion object {
        private const val MAX_POINTS = 30
        private const val INTERVAL_MS = 1_000L
    }
}
