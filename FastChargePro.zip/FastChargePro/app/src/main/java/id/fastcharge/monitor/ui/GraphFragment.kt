package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale

class GraphFragment : Fragment() {

    private var chart: LineChart? = null
    private var tvCurrentWatt: TextView? = null
    private var tvMaxWatt: TextView? = null
    private var reader: BatteryReader? = null

    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<Entry>()
    private var index = 0f
    private var maxWatt = 0f
    private var dataSet: LineDataSet? = null
    private var lineData: LineData? = null

    private val runnable = object : Runnable {
        override fun run() {
            val chartRef = chart ?: return
            val tvCurrentRef = tvCurrentWatt ?: return
            val tvMaxRef = tvMaxWatt ?: return
            val readerRef = reader ?: return

            val d = try {
                readerRef.read()
            } catch (e: Exception) {
                tvCurrentRef.text = "-- W"
                handler.postDelayed(this, 1000)
                return
            }

            if (d.isRealData && d.powerW != null && d.powerW > 0) {
                val watt = d.powerW.toFloat()
                entries.add(Entry(index++, watt))
                if (entries.size > 30) entries.removeAt(0)
                if (watt > maxWatt) maxWatt = watt

                updateChartData()
                tvCurrentRef.text = String.format(Locale.US, "%.2f W", watt)
                tvMaxRef.text = String.format(Locale.US, "Max: %.2f W", maxWatt)
            } else {
                tvCurrentRef.text = "-- W"
                tvMaxRef.text = if (maxWatt > 0f) {
                    String.format(Locale.US, "Max: %.2f W", maxWatt)
                } else {
                    "Max: -- W"
                }
                if (entries.isEmpty()) {
                    if (chartRef.noDataText != "Pembacaan daya tidak tersedia pada sampel ini") {
                        chartRef.setNoDataText("Pembacaan daya tidak tersedia pada sampel ini")
                    }
                }
                chartRef.invalidate()
            }

            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_graph, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        chart = view.findViewById(R.id.chart)
        tvCurrentWatt = view.findViewById(R.id.tvCurrentWatt)
        tvMaxWatt = view.findViewById(R.id.tvMaxWatt)
        reader = BatteryReader(requireContext())

        setupChart()
        handler.post(runnable)
    }

    private fun setupChart() {
        chart?.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(false)
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                isEnabled = false
            }
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = Color.parseColor("#1A2440")
                textColor = Color.parseColor("#8B9BB4")
                axisLineColor = Color.parseColor("#1E3A6E")
                textSize = 10f
                axisMinimum = 0f
            }
            axisRight.isEnabled = false
            setNoDataText("Menunggu data...")
            setNoDataTextColor(Color.parseColor("#8B9BB4"))
        }
    }

    private fun updateChartData() {
        val chartRef = chart ?: return

        if (dataSet == null) {
            dataSet = LineDataSet(entries, "Watt").apply {
                color = Color.parseColor("#00FF88")
                lineWidth = 2.5f
                setDrawCircles(false)
                setDrawValues(false)
                mode = LineDataSet.Mode.LINEAR
                setDrawFilled(true)
                fillColor = Color.parseColor("#00FF88")
                fillAlpha = 40
                highLightColor = Color.parseColor("#00D4FF")
            }
            lineData = LineData(dataSet)
            chartRef.data = lineData
        } else {
            dataSet?.notifyDataSetChanged()
        }
        chartRef.notifyDataSetChanged()
        chartRef.invalidate()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
        chart = null
        tvCurrentWatt = null
        tvMaxWatt = null
        reader = null
        dataSet = null
        lineData = null
    }
}