package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GraphFragment : Fragment() {
    private var chart: LineChart? = null
    private var currentWatt: TextView? = null
    private var maxWattView: TextView? = null
    private var graphStatus: TextView? = null
    private lateinit var reader: BatteryReader
    private var pollJob: Job? = null
    private val entries = mutableListOf<Entry>()
    private var index = 0f
    private var maxWatt = 0f
    private var hasPowerSample = false



    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(R.layout.fragment_graph, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        chart = view.findViewById(R.id.chart)
        currentWatt = view.findViewById(R.id.tvCurrentWatt)
        maxWattView = view.findViewById(R.id.tvMaxWatt)
        graphStatus = view.findViewById(R.id.tvGraphStatus)
        reader = BatteryReader(requireContext().applicationContext)
        setupChart()
        pollJob = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                val result = withContext(Dispatchers.IO) { runCatching { reader.read() } }
                result.onSuccess { renderData(it) }.onFailure { error ->
                    graphStatus?.text = "Sensor gagal dibaca: ${error.javaClass.simpleName}"
                }
                delay(1000L)
            }
        }
    }

    private fun setupChart() {
        chart?.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(false)
            setPinchZoom(false)
            setDrawGridBackground(false)
            setBackgroundColor(Color.TRANSPARENT)
            extraBottomOffset = 8f
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                textColor = Color.parseColor("#7185A4")
                axisLineColor = Color.parseColor("#223B5E")
                textSize = 10f
                isEnabled = false
            }
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = Color.parseColor("#20314B")
                textColor = Color.parseColor("#7185A4")
                axisLineColor = Color.TRANSPARENT
                textSize = 10f
                axisMinimum = 0f
            }
            axisRight.isEnabled = false
            setNoDataText("Menunggu data daya dari sensor...")
            setNoDataTextColor(Color.parseColor("#91A4C2"))
        }
    }

    private fun renderData(d: BatteryReader.Data) {
        // Daya tidak bergantung pada currentMa: power_now dapat valid meski arus tidak diekspos Android.
        val watt = d.powerW?.takeIf { it.isFinite() && it >= 0.0 && it < 100.0 }
        if (watt != null) {
            hasPowerSample = true
            entries.add(Entry(index++, watt.toFloat()))
            while (entries.size > 60) entries.removeAt(0)
            maxWatt = maxOf(maxWatt, watt.toFloat())
            updateChart()
            currentWatt?.text = String.format(Locale.US, "%.2f W", watt)
            maxWattView?.text = String.format(Locale.US, "%.2f W", maxWatt)
            graphStatus?.text = "Data sensor aktual · ${entries.size} sampel tersimpan"
        } else {
            currentWatt?.text = "-- W"
            maxWattView?.text = if (hasPowerSample) String.format(Locale.US, "%.2f W", maxWatt) else "-- W"
            graphStatus?.text = d.errorInfo?.lineSequence()?.firstOrNull { it.contains("POWER_UNAVAILABLE") || it.contains("CURRENT_UNAVAILABLE") }
                ?: "Perangkat belum menyediakan nilai daya yang dapat dibaca. Coba saat charger terhubung."
        }
    }

    private fun updateChart() {
        if (entries.isEmpty()) return
        val dataSet = LineDataSet(entries.toList(), "Daya baterai").apply {
            color = Color.parseColor("#00E5A8")
            lineWidth = 2.5f
            setDrawCircles(false)
            setDrawValues(false)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillColor = Color.parseColor("#00E5A8")
            fillAlpha = 32
            highLightColor = Color.parseColor("#28D9FF")
        }
        chart?.apply {
            data = LineData(dataSet)
            notifyDataSetChanged()
            setVisibleXRangeMaximum(30f)
            moveViewToX(index)
            invalidate()
        }
    }

    override fun onDestroyView() {
        pollJob?.cancel()
        pollJob = null
        chart?.clear()
        chart = null
        currentWatt = null
        maxWattView = null
        graphStatus = null
        super.onDestroyView()
    }
}
