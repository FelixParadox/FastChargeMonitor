package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader

class GraphFragment : Fragment() {
    private var chart: LineChart? = null
    private lateinit var reader: BatteryReader
    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<Entry>()
    private var index = 0f

    private val runnable = object : Runnable {
        override fun run() {
            val d = reader.read()
            // Hanya tambahkan ke grafik jika data Watt terbaca (tidak null)
            if (d.powerW != null && d.powerW > 0) {
                entries.add(Entry(index++, d.powerW.toFloat()))
                if (entries.size > 30) entries.removeAt(0) // Batasi 30 data terakhir
                
                val set = LineDataSet(entries, "Watt")
                set.color = Color.parseColor("#00FF88")
                set.setDrawCircles(false)
                set.lineWidth = 2f
                
                chart?.data = LineData(set)
                chart?.invalidate() // Refresh grafik
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_graph, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        chart = view.findViewById(R.id.chart)
        reader = BatteryReader(requireContext())
        
        // Setup Tampilan Grafik
        chart?.description?.isEnabled = false
        chart?.legend?.isEnabled = false
        
        handler.post(runnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}