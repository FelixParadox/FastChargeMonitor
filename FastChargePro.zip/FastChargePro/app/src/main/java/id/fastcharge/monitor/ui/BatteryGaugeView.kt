package id.fastcharge.monitor.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

class BatteryGaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var percent: Float = 0f
    private var animatedPercent: Float = 0f
    private var isCharging: Boolean = false
    private var statusText: String = "Memuat..."

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        color = Color.parseColor("#1A2440")
        strokeCap = Paint.Cap.ROUND
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 22f
        strokeCap = Paint.Cap.ROUND
    }

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#3A5A8E")
    }

    private val percentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B9BB4")
        textAlign = Paint.Align.CENTER
    }

    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF88")
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }

    private val arcRect = RectF()
    private val startAngle = 135f
    private val sweepAngle = 270f
    private var animator: ValueAnimator? = null

    fun setData(p: Int, charging: Boolean, status: String) {
        percent = p.coerceIn(0, 100).toFloat()
        isCharging = charging
        statusText = status

        animator?.cancel()
        animator = ValueAnimator.ofFloat(animatedPercent, percent).apply {
            duration = 800
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                animatedPercent = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 40f
        val radius = (minOf(w, h) - pad * 2) / 2
        val cx = w / 2
        val cy = h / 2

        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        // Background arc
        canvas.drawArc(arcRect, startAngle, sweepAngle, false, bgPaint)

        // Progress arc with gradient
        val progressSweep = sweepAngle * (animatedPercent / 100f)
        val colorStart = when {
            percent <= 20 -> Color.parseColor("#FF4D6D")
            percent <= 50 -> Color.parseColor("#FFB84D")
            else -> Color.parseColor("#00FF88")
        }
        val colorEnd = when {
            percent <= 20 -> Color.parseColor("#FFB84D")
            percent <= 50 -> Color.parseColor("#00FF88")
            else -> Color.parseColor("#00D4FF")
        }
        progressPaint.shader = LinearGradient(
            cx - radius, cy - radius, cx + radius, cy + radius,
            colorStart, colorEnd, Shader.TileMode.CLAMP
        )
        canvas.drawArc(arcRect, startAngle, progressSweep, false, progressPaint)

        // Tick marks (setiap 10%)
        for (i in 0..10) {
            val angle = Math.toRadians((startAngle + sweepAngle * i / 10f).toDouble())
            val innerR = radius - 32f
            val outerR = radius - 14f
            val x1 = cx + (innerR * cos(angle)).toFloat()
            val y1 = cy + (innerR * sin(angle)).toFloat()
            val x2 = cx + (outerR * cos(angle)).toFloat()
            val y2 = cy + (outerR * sin(angle)).toFloat()
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }

        // Big percent text
        percentPaint.textSize = radius * 0.55f
        val textY = cy + percentPaint.textSize / 3f
        canvas.drawText("${animatedPercent.toInt()}%", cx, textY, percentPaint)

        // Charging bolt
        if (isCharging) {
            boltPaint.textSize = radius * 0.22f
            canvas.drawText("⚡", cx, cy - radius * 0.30f, boltPaint)
        }

        // Status text
        statusPaint.textSize = radius * 0.14f
        canvas.drawText(statusText, cx, cy + radius * 0.55f, statusPaint)
    }
}