package id.fastcharge.monitor.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class BatteryGaugeView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var level = 0
    private var charging = false
    private var fast = false

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 26f; strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#1E3A6E")
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 26f; strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; color = Color.WHITE
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; color = Color.parseColor("#8B9BB4")
    }
    private val rect = RectF()

    fun setLevel(pct: Int, isCharging: Boolean, isFast: Boolean) {
        level = pct.coerceIn(0, 100); charging = isCharging; fast = isFast
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val r = (minOf(w, h) / 2) - 40f
        rect.set(cx - r, cy - r, cx + r, cy + r)

        val startAngle = 135f
        val sweepTotal = 270f

        canvas.drawArc(rect, startAngle, sweepTotal, false, bgPaint)

        val colorStart = if (fast) Color.parseColor("#00FF88") else Color.parseColor("#00D4FF")
        val colorEnd = if (fast) Color.parseColor("#00E5FF") else Color.parseColor("#8A2BE2")
        arcPaint.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r, colorStart, colorEnd, Shader.TileMode.CLAMP
        )
        canvas.drawArc(rect, startAngle, sweepTotal * level / 100f, false, arcPaint)

        // Level besar
        textPaint.textSize = r * 0.42f
        textPaint.color = if (fast) Color.parseColor("#00FF88") else Color.WHITE
        canvas.drawText("$level%", cx, cy + textPaint.textSize / 3, textPaint)

        // Status
        subPaint.textSize = r * 0.13f
        val status = when {
            fast -> "⚡ FAST"
            charging -> "CHARGING"
            else -> "BATTERY"
        }
        canvas.drawText(status, cx, cy + r * 0.45f, subPaint)

        // Ticks
        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8B9BB4"); strokeWidth = 3f
        }
        for (i in 0..10) {
            val angle = Math.toRadians((startAngle + sweepTotal * i / 10f).toDouble())
            val x1 = cx + (r + 20) * cos(angle).toFloat()
            val y1 = cy + (r + 20) * sin(angle).toFloat()
            val x2 = cx + (r + 30) * cos(angle).toFloat()
            val y2 = cy + (r + 30) * sin(angle).toFloat()
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }
    }
}