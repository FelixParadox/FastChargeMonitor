package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {

    private lateinit var reader: BatteryReader
    private lateinit var tvBigPercent: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvPower: TextView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvHealth: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvVoltage: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            if (isAdded && view != null) refreshData()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        reader = BatteryReader(requireContext().applicationContext)

        tvBigPercent = view.findViewById(R.id.tvBigPercent)
        tvEta = view.findViewById(R.id.tvEta)
        tvCurrent = view.findViewById(R.id.tvCurrent)
        tvPower = view.findViewById(R.id.tvPower)
        tvStatusBadge = view.findViewById(R.id.tvStatusBadge)
        tvMode = view.findViewById(R.id.tvMode)
        tvHealth = view.findViewById(R.id.tvHealth)
        tvTemp = view.findViewById(R.id.tvTemp)
        tvVoltage = view.findViewById(R.id.tvVoltage)

        refreshData()
        handler.postDelayed(runnable, 1000)
    }

    private fun refreshData() {
        val d = try {
            reader.read()
        } catch (e: Exception) {
            return
        }

        tvBigPercent.text = if (d.percent >= 0) d.percent.toString() else "--"

        // Badge
        val (statusText, statusColor) = when {
            d.isFull -> "✅ Penuh" to R.color.accent_green
            d.isCharging -> "⚡ Mengisi Daya" to R.color.accent_orange
            else -> "🔋 Menggunakan Baterai" to R.color.accent_blue
        }
        tvStatusBadge.text = statusText
        tvStatusBadge.setTextColor(ContextCompat.getColor(requireContext(), statusColor))

        // Mode
        tvMode.text = if (d.isCharging) "Pengisian" else "Normal"

        // Kesehatan
        tvHealth.text = healthString(d.health)

        // Suhu
        tvTemp.text = String.format(Locale.US, "%.1f °C", d.temperatureC)

        // Tegangan
        tvVoltage.text = if (d.voltageMv > 0) "${d.voltageMv} mV" else "-- mV"

        // Arus dan Daya
        if (d.isRealData) {
            val currentA = (d.currentMa ?: 0.0) / 1000.0
            tvCurrent.text = String.format(Locale.US, "%.2f A", currentA)
            tvPower.text = d.powerW?.let { String.format(Locale.US, "%.1f W", it) } ?: "-- W"
        } else {
            tvCurrent.text = "-- A"
            tvPower.text = "-- W"
        }

        updateEta(d)
    }

    private fun healthString(h: Int): String = when (h) {
        2 -> "Baik"
        3 -> "Terlalu Panas"
        4 -> "Rusak"
        5 -> "Over Voltage"
        6 -> "Tidak Diketahui"
        7 -> "Cold"
        else -> "Baik"
    }

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()

        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3_600_000.0
                if (hours > 0) {
                    val newRate = (d.percent - lastLevel) / hours
                    // Smooth: rata-rata dengan nilai lama
                    ratePerHour = if (ratePerHour == 0.0) newRate else (ratePerHour * 0.7 + newRate * 0.3)
                }
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        tvEta.text = when {
            d.isFull -> "Baterai Penuh ✅"
            !d.isCharging -> "Tidak sedang mengisi daya"
            ratePerHour > 0.1 -> {
                val mins = (((100 - d.percent) / ratePerHour) * 60).roundToInt().coerceAtLeast(1)
                val jam = mins / 60
                val sisaMenit = mins % 60
                "⚡ $jam jam $sisaMenit mnt hingga penuh"
            }
            else -> "Menghitung estimasi..."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}