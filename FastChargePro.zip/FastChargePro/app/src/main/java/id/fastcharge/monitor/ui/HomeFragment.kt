package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {

    private lateinit var reader: BatteryReader
    private lateinit var tvBigPercent: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvPower: TextView
    private lateinit var tvStatusBadge: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            if (isAdded && view != null) refreshData()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        reader = BatteryReader(requireContext().applicationContext)

        tvBigPercent = view.findViewById(R.id.tvBigPercent)
        tvEta = view.findViewById(R.id.tvEta)
        tvCurrent = view.findViewById(R.id.tvCurrent)
        tvPower = view.findViewById(R.id.tvPower)
        tvStatusBadge = view.findViewById(R.id.tvStatusBadge)

        refreshData()
        handler.postDelayed(runnable, 1000)
    }

    private fun refreshData() {
        val d = try { reader.read() } catch (e: Exception) { return }

       
        // Arus dan daya aktual
        val current = d.currentMa
        val power = d.powerW

        // Tampilkan setiap sensor secara independen. Daya dari power_now tetap
        // berguna walaupun perangkat tidak menyediakan arus melalui BatteryManager.
        tvCurrent.text = if (d.isRealData && current != null && current.isFinite()) {
            if (current >= 1000.0) {
                String.format(Locale.US, "%.2f A", current / 1000.0)
            } else {
                String.format(Locale.US, "%.0f mA", current)
            }
        } else "-- mA"

        tvPower.text = if (power != null && power.isFinite() && power >= 0.0) {
            when {
                power >= 1.0 -> String.format(Locale.US, "%.2f W", power)
                else -> String.format(Locale.US, "%.0f mW", power * 1000.0)
            }
        } else "-- W"

        updateEta(d)

    }

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()

        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3_600_000.0
                if (hours > 0) {
                    val newRate = (d.percent - lastLevel) / hours
                    ratePerHour =
                        if (ratePerHour == 0.0) newRate
                        else ratePerHour * 0.7 + newRate * 0.3
                }
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        tvEta.text = when {
            d.isFull -> "Baterai Penuh ✅"
            !d.isCharging -> "Tidak sedang mengisi daya"
            ratePerHour > 0.1 -> {
                val mins = (((100 - d.percent) / ratePerHour) * 60)
                    .roundToInt().coerceAtLeast(1)
                "⚡ ${mins / 60} jam ${mins % 60} mnt hingga penuh"
            }
            else -> "Menghitung estimasi..."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}