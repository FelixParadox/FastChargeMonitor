package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {
    private lateinit var reader: BatteryReader
    private lateinit var gauge: BatteryGaugeView
    private lateinit var tvEta: TextView
    private lateinit var tvVoltage: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvPower: TextView
    private lateinit var tvStatus: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            if (!isAdded || view == null) return
            try {
                refreshData()
            } catch (e: Exception) {
                tvStatus.text = "⚠️ Gagal membaca data: ${e.javaClass.simpleName}"
                tvCurrent.text = "N/A"
                tvPower.text = "N/A"
            } finally {
                if (isAdded && view != null) handler.postDelayed(this, INTERVAL_MS)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        reader = BatteryReader(requireContext())
        gauge = view.findViewById(R.id.gauge)
        tvEta = view.findViewById(R.id.tvEta)
        tvVoltage = view.findViewById(R.id.tvVoltage)
        tvCurrent = view.findViewById(R.id.tvCurrent)
        tvPower = view.findViewById(R.id.tvPower)
        tvStatus = view.findViewById(R.id.tvStatus)
        handler.removeCallbacks(runnable)
        handler.post(runnable)
    }

    private fun refreshData() {
        val data = reader.read()
        val gaugeStatus = when {
            data.isFull -> "Sudah Penuh"
            data.isCharging -> "Mengisi Daya"
            else -> "Menggunakan Baterai"
        }
        gauge.setData(data.percent.coerceAtLeast(0), data.isCharging, gaugeStatus)
        tvVoltage.text = if (data.voltageMv > 0) "${data.voltageMv} mV" else "N/A"
        tvCurrent.text = data.currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "N/A"
        tvPower.text = data.powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "N/A"
        tvCurrent.textSize = 16f
        tvPower.textSize = 16f

        tvStatus.text = when {
            !data.isRealData -> "⚠️ ${data.errorInfo?.lineSequence()?.firstOrNull() ?: "Data arus tidak tersedia"}"
            data.isFull -> "✅ Baterai penuh"
            data.isCharging -> "⚡ Sedang mengisi daya"
            else -> "🔋 Menggunakan baterai"
        }
        updateEta(data)
    }

    private fun updateEta(data: BatteryReader.Data) {
        val now = System.currentTimeMillis()
        if (data.percent in 0..100) {
            if (lastLevel >= 0 && data.percent != lastLevel && now > lastLevelTime) {
                val elapsedHours = (now - lastLevelTime) / 3_600_000.0
                if (elapsedHours > 0.0) ratePerHour = (data.percent - lastLevel) / elapsedHours
            }
            if (data.percent != lastLevel) {
                lastLevel = data.percent
                lastLevelTime = now
            }
        }
        tvEta.text = when {
            data.isFull -> "Sudah penuh ✅"
            !data.isCharging -> "Menunggu charger"
            ratePerHour > 0.1 -> {
                val minutes = (((100 - data.percent) / ratePerHour) * 60.0).roundToInt().coerceAtLeast(1)
                if (minutes >= 60) "${minutes / 60} jam ${minutes % 60} menit" else "$minutes menit"
            }
            else -> "Menghitung…"
        }
    }

    override fun onDestroyView() {
        handler.removeCallbacks(runnable)
        super.onDestroyView()
    }

    companion object { private const val INTERVAL_MS = 1_000L }
}
