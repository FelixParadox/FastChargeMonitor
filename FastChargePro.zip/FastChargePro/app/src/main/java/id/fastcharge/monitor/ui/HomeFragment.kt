package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {

    private lateinit var reader: BatteryReader
    private var gauge: BatteryGaugeView? = null
    private var tvEta: TextView? = null
    private var tvVoltage: TextView? = null
    private var tvCurrent: TextView? = null
    private var tvPower: TextView? = null
    private var tvStatus: TextView? = null

    private val handler = Handler(Looper.getMainLooper())

    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            if (!isAdded || view == null) return

            try {
                refreshData()
            } catch (e: Exception) {
                Log.e("FastChargeHome", "Gagal memperbarui data baterai", e)
                tvStatus?.text =
                    "⚠️ Gagal membaca data: ${e.javaClass.simpleName}"
            } finally {
                if (isAdded && view != null) {
                    handler.postDelayed(this, 1000)
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        reader = BatteryReader(requireContext())

        gauge = view.findViewById(R.id.gauge)
        tvEta = view.findViewById(R.id.tvEta)
        tvVoltage = view.findViewById(R.id.tvVoltage)
        tvCurrent = view.findViewById(R.id.tvCurrent)
        tvPower = view.findViewById(R.id.tvPower)
        tvStatus = view.findViewById(R.id.tvStatus)

        handler.removeCallbacks(runnable)
        handler.post(runnable)
    }

    private fun refreshData() {
        val d = reader.read()

        val statusText = when {
            d.isFull -> "Baterai penuh"
            d.isCharging -> "Sedang mengisi daya"
            d.currentSource != null -> "Menggunakan baterai"
            else -> "Status arus tidak tersedia"
        }

        gauge?.setData(
            d.percent.coerceIn(0, 100),
            d.isCharging,
            if (d.percent < 0) "Data baterai tidak tersedia" else statusText
        )

        tvVoltage?.text = if (d.voltageMv > 0) {
            String.format(Locale.US, "%.3f V", d.voltageMv / 1000.0)
        } else {
            "N/A"
        }

        tvCurrent?.text = d.currentMa?.let {
            String.format(Locale.US, "%.0f mA", it)
        } ?: "N/A"

        tvPower?.text = d.powerW?.let {
            String.format(Locale.US, "%.2f W", it)
        } ?: "N/A"

        val detailError = d.errorInfo
            ?.lineSequence()
            ?.firstOrNull { it.contains("UNAVAILABLE") || it.contains("ERROR") }

        tvStatus?.text = when {
            d.isFull -> "✅ Baterai penuh"
            d.isCharging && d.currentMa != null -> "⚡ Sedang mengisi daya"
            d.isCharging -> "⚡ Mengisi daya · Arus tidak tersedia"
            d.percent < 0 -> "⚠️ Data baterai tidak tersedia"
            d.currentMa == null -> "⚠️ Arus tidak tersedia"
            else -> "🔋 Menggunakan baterai"
        }

        // Detail error lengkap bisa dibaca melalui Logcat dengan tag FastChargeHome.
        if (!d.errorInfo.isNullOrBlank()) {
            Log.w("FastChargeHome", d.errorInfo)
        }

        tvStatus?.contentDescription = listOfNotNull(
            tvStatus?.text?.toString(),
            detailError
        ).joinToString(". ")

        updateEta(d)
    }

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()

        if (d.percent in 0..100) {
            if (
                lastLevel >= 0 &&
                d.percent != lastLevel &&
                lastLevelTime > 0L &&
                now > lastLevelTime
            ) {
                val hours = (now - lastLevelTime) / 3_600_000.0

                if (hours > 0.0) {
                    ratePerHour = (d.percent - lastLevel) / hours
                }
            }

            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        tvEta?.text = when {
            d.percent < 0 -> "Data persentase tidak tersedia"
            d.isFull -> "Sudah penuh ✅"
            !d.isCharging -> "Menunggu charger"
            ratePerHour > 0.1 -> {
                val minutes = (
                    ((100 - d.percent) / ratePerHour) * 60.0
                ).roundToInt().coerceAtLeast(1)

                if (minutes >= 60) {
                    "${minutes / 60} jam ${minutes % 60} menit"
                } else {
                    "$minutes menit"
                }
            }
            else -> "Menghitung estimasi..."
        }
    }

    override fun onDestroyView() {
        handler.removeCallbacks(runnable)

        gauge = null
        tvEta = null
        tvVoltage = null
        tvCurrent = null
        tvPower = null
        tvStatus = null

        super.onDestroyView()
    }
}