package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {

    private lateinit var reader: BatteryReader
    //private lateinit var gauge: BatteryGaugeView
    private lateinit var tvBigPercent: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvVoltage: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvPower: TextView
    private lateinit var tvStatus: TextView

    private val handler = Handler(Looper.getMainLooper())

    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            refreshData()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
    reader = BatteryReader(requireContext())

    // Inisialisasi ID baru
    tvBigPercent = view.findViewById(R.id.tvBigPercent)
    tvEta = view.findViewById(R.id.tvEta)
    tvVoltage = view.findViewById(R.id.tvVoltage)
    tvCurrent = view.findViewById(R.id.tvCurrent)
    tvPower = view.findViewById(R.id.tvPower)
    // tvStatus dihapus dari layout baru (opsional jika ingin ditambah)

    handler.post(runnable)
}


private fun refreshData() {
    val d = reader.read()

    // Gauge selalu ditampilkan (persentase dan status adalah data nyata)
    val status = when {
        d.isFull -> "Sudah Penuh"
        d.isCharging -> "Mengisi Daya"
        else -> "Menggunakan Baterai"
    }
    
    tvBigPercent.text = "${d.percent}"

    // Tegangan biasanya merupakan data nyata dan dapat ditampilkan

    // Data Real-time
    tvVoltage.text = if (d.voltageMv > 0) String.format(Locale.US, "%.1f V", d.voltageMv / 1000.0) else "-- V" 

    // Arus dan daya: jika bukan data nyata, tampilkan "Tidak Didukung"
    if (d.isRealData) {
    
        val currentA = (d.currentMa ?: 0.0) / 1000.0
        tvCurrent.text = String.format(Locale.US, "%.2f A", currentA)
        tvPower.text = d.powerW?.let { String.format(Locale.US, "%.1f W", it) } ?: "-- W"
    } else {
        tvCurrent.text = "-- A"
        tvPower.text = "-- W"
    }

    // Status badge
    tvStatus.text = when {
        d.isFull -> "✅ Baterai Penuh"
        d.isCharging -> "⚡ Sedang Mengisi Daya (Data Arus mungkin tidak tersedia)"
        else -> "🔋 Menggunakan Baterai"
    }

    // Logika ETA (tetap tidak berubah)
    updateEta(d)
}

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()

        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3_600_000.0
                if (hours > 0) {
                    ratePerHour = (d.percent - lastLevel) / hours
                }
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }
        
    tvEta.text = when {
        d.isFull -> "Baterai Penuh ✅"
        !d.isCharging -> "Tidak sedang mengisi daya"
        ratePerHour > 0.1 -> {
            val mins = (((100 - d.percent) / ratePerHour) * 60).roundToInt().coerceAtLeast(1)
            val jam = mins / 60
            val sisaMenit = mins % 60
            "⚡ $jam jam $sisaMenit mnt hingga penuh"
        }
        else -> "Menghitung estimasi..."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}