package id.fastcharge.monitor.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import kotlin.math.roundToInt

class HomeFragment : Fragment() {
    private lateinit var reader: BatteryReader
    private lateinit var percent: TextView
    private lateinit var eta: TextView
    private lateinit var current: TextView
    private lateinit var power: TextView
    private lateinit var badge: TextView
    private lateinit var progress: ProgressBar
    private lateinit var voltage: TextView
    private lateinit var temperature: TextView
    private lateinit var health: TextView
    private lateinit var chargeType: TextView
    private lateinit var source: TextView
    private lateinit var diagnostics: TextView
    private lateinit var currentDirection: TextView

    private var pollJob: Job? = null
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, state: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        reader = BatteryReader(requireContext().applicationContext)
        percent = view.findViewById(R.id.tvBigPercent)
        eta = view.findViewById(R.id.tvEta)
        current = view.findViewById(R.id.tvCurrent)
        power = view.findViewById(R.id.tvPower)
        badge = view.findViewById(R.id.tvStatusBadge)
        progress = view.findViewById(R.id.batteryProgress)
        voltage = view.findViewById(R.id.tvVoltage)
        temperature = view.findViewById(R.id.tvTemperature)
        health = view.findViewById(R.id.tvHealth)
        chargeType = view.findViewById(R.id.tvChargeType)
        source = view.findViewById(R.id.tvSource)
        diagnostics = view.findViewById(R.id.tvDiagnostics)
        currentDirection = view.findViewById(R.id.tvCurrentDirection)
        pollJob = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                val result = withContext(Dispatchers.IO) { runCatching { reader.read() } }
                result.onSuccess { renderData(it) }.onFailure { error ->
                    badge.text = "●  Sensor tidak tersedia"
                    diagnostics.text = "Pembacaan sensor gagal: ${error.javaClass.simpleName}"
                }
                delay(1000L)
            }
        }
    }

    private fun renderData(d: BatteryReader.Data) {
        percent.text = if (d.percent in 0..100) d.percent.toString() else "--"
        progress.progress = d.percent.coerceIn(0, 100)
        badge.text = when {
            d.isFull -> "●  Baterai penuh"
            d.isCharging -> "●  Sedang mengisi daya"
            d.isPluggedIn -> "●  Terhubung · tidak mengisi"
            else -> "●  Menggunakan baterai"
        }
        badge.setTextColor(if (d.isCharging) 0xFF00E5A8.toInt() else 0xFF91A4C2.toInt())

        current.text = d.currentMa?.takeIf { it.isFinite() }?.let {
            if (it >= 1000.0) String.format(Locale.US, "%.2f A", it / 1000.0)
            else String.format(Locale.US, "%.0f mA", it)
        } ?: "-- mA"
        currentDirection.text = when {
            d.currentSignedMa == null -> "Arus sensor tidak tersedia"
            d.currentSignedMa < 0 -> "Arah: pelepasan daya"
            d.isCharging -> "Arah: masuk ke baterai"
            else -> "Arus baterai terukur"
        }
        power.text = d.powerW?.takeIf { it.isFinite() && it >= 0.0 }?.let {
            if (it >= 1.0) String.format(Locale.US, "%.2f W", it)
            else String.format(Locale.US, "%.0f mW", it * 1000.0)
        } ?: "-- W"
        voltage.text = if (d.voltageMv in 2500..5000) "${d.voltageMv} mV" else "-- mV"
        temperature.text = d.temperatureC?.let { String.format(Locale.US, "%.1f °C", it) } ?: "-- °C"
        health.text = BatteryReader.healthLabel(d.health)
        chargeType.text = d.chargeType?.takeIf { it.isNotBlank() } ?: if (d.isPluggedIn) "Charger terdeteksi" else "Tidak terhubung"
        source.text = d.currentSource ?: "Tidak tersedia"
        diagnostics.text = when {
            d.currentMa != null && d.powerW != null -> "Sensor aktif · data diperbarui setiap detik"
            d.errorInfo != null -> d.errorInfo!!.lineSequence().filter { it.contains("UNAVAILABLE") || it.contains("ERROR") }.take(3).joinToString(" · ").ifBlank { "Sebagian sensor tidak diekspos perangkat" }
            else -> "Sebagian sensor tidak diekspos perangkat"
        }
        updateEta(d)
    }

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()
        if (d.percent in 0..100) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3_600_000.0
                if (hours > 0.0) {
                    val observed = (d.percent - lastLevel) / hours
                    if (observed > 0.0 && observed < 100.0) ratePerHour = if (ratePerHour == 0.0) observed else ratePerHour * 0.65 + observed * 0.35
                }
            }
            if (d.percent != lastLevel) { lastLevel = d.percent; lastLevelTime = now }
        }
        eta.text = when {
            d.isFull -> "Baterai mencapai 100%"
            !d.isCharging -> "Hubungkan charger untuk estimasi pengisian"
            ratePerHour > 0.1 && d.percent in 0..99 -> {
                val mins = (((100 - d.percent) / ratePerHour) * 60).roundToInt().coerceAtLeast(1)
                "Estimasi penuh · ${mins / 60} jam ${mins % 60} menit"
            }
            else -> "Mengumpulkan pola pengisian..."
        }
    }

    override fun onDestroyView() {
        pollJob?.cancel()
        pollJob = null
        super.onDestroyView()
    }
}
