package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {
    private lateinit var reader: BatteryReader
    private val handler = Handler(Looper.getMainLooper())
    
    // Variabel ETA (Estimasi Waktu)
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            refreshData()
            handler.postDelayed(this, 1000) // Update tiap 1 detik
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        reader = BatteryReader(requireContext())
        handler.post(runnable)
    }

    private fun refreshData() {
        val d = reader.read()
        val view = view ?: return
        
        val tvPercent = view.findViewById<TextView>(R.id.tvPercent)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvEta = view.findViewById<TextView>(R.id.tvEta)
        val tvVoltage = view.findViewById<TextView>(R.id.tvVoltage)
        val tvCurrent = view.findViewById<TextView>(R.id.tvCurrent)
        val tvPower = view.findViewById<TextView>(R.id.tvPower)
        
        // Update UI Dasar
        tvPercent.text = "${d.percent}%"
        tvStatus.text = if(d.isCharging) "Mengisi Daya" else "Menggunakan Baterai"
        tvVoltage.text = "${d.voltageMv} mV"
        tvCurrent.text = d.currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "--"
        tvPower.text = d.powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "--"

        // Logika ETA
        val now = System.currentTimeMillis()
        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3600000.0
                if (hours > 0) ratePerHour = (d.percent - lastLevel) / hours
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        tvEta.text = when {
            d.isFull -> "Sudah Penuh"
            !d.isCharging -> "Menunggu Charger"
            ratePerHour > 0.1 -> {
                val mins = (((100 - d.percent) / ratePerHour) * 60).roundToInt()
                "${mins / 60} Jam ${mins % 60} Menit"
            }
            else -> "Menghitung..."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}