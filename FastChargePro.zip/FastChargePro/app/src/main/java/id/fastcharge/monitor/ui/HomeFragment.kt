package id.fastcharge.monitor.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryReader
import java.util.Locale
import kotlin.math.roundToInt

class HomeFragment : Fragment() {

    private lateinit var reader: BatteryReader
    private lateinit var gauge: BatteryGaugeView
    private lateinit var tvEta: TextView
    private lateinit var tvVoltage: TextView
    private lateinit var tvCurrent: TextView
    private lateinit var tvPower: TextView
    private lateinit var tvStatus: TextView

    private val handler = Handler(Looper.getMainLooper())

    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private val runnable = object : Runnable {
        override fun run() {
            refreshData()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        reader = BatteryReader(requireContext())

        gauge = view.findViewById(R.id.gauge)
        tvEta = view.findViewById(R.id.tvEta)
        tvVoltage = view.findViewById(R.id.tvVoltage)
        tvCurrent = view.findViewById(R.id.tvCurrent)
        tvPower = view.findViewById(R.id.tvPower)
        tvStatus = view.findViewById(R.id.tvStatus)

        handler.post(runnable)
    }

private fun refreshData() {
    val d = reader.read()

    val status = when {
        d.isFull -> "Sudah Penuh"
        d.isCharging -> "Mengisi Daya"
        else -> "Menggunakan Baterai"
    }
    gauge.setData(d.percent, d.isCharging, status)

    tvVoltage.text = if (d.voltageMv > 0) "${d.voltageMv} mV" else "--"

    if (d.isRealData) {
        tvCurrent.text = d.currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "--"
        tvPower.text = d.powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "--"
        tvStatus.text = if (d.isCharging) "⚡ Sedang Mengisi Daya" else "🔋 Menggunakan Baterai"
    } else {
        // TAMPILKAN ERROR ASLI DARI SISTEM
        tvCurrent.text = "ERR: ${d.errorInfo ?: "Unknown"}"
        tvPower.text = "ERR: Data tidak tersedia"
        
        // Perkecil text size jika error panjang agar tidak terpotong
        tvCurrent.textSize = 10f 
        tvPower.textSize = 10f
        
        tvStatus.text = "⚠️ Gagal Membaca Data"
    }

    updateEta(d)
}

    private fun updateEta(d: BatteryReader.Data) {
        val now = System.currentTimeMillis()

        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3_600_000.0
                if (hours > 0) {
                    ratePerHour = (d.percent - lastLevel) / hours
                }
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        tvEta.text = when {
            d.isFull -> "Sudah Penuh ✅"
            !d.isCharging -> "Menunggu Charger"
            ratePerHour > 0.1 -> {
                val mins = (((100 - d.percent) / ratePerHour) * 60).roundToInt().coerceAtLeast(1)
                if (mins >= 60) "${mins / 60} jam ${mins % 60} menit" else "$mins menit"
            }
            else -> "Menghitung..."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(runnable)
    }
}