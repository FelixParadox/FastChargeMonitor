package id.fastcharge.monitor.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import id.fastcharge.monitor.R
import id.fastcharge.monitor.data.BatteryRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment(R.layout.fragment_home) {

    private lateinit var repo: BatteryRepository
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        repo = BatteryRepository.get(requireContext())

        val gauge = view.findViewById<BatteryGaugeView>(R.id.gauge)
        val tvEta = view.findViewById<TextView>(R.id.tvEta)
        val tvVoltage = view.findViewById<TextView>(R.id.tvVoltage)
        val tvCurrent = view.findViewById<TextView>(R.id.tvCurrent)
        val tvPower = view.findViewById<TextView>(R.id.tvPower)
        val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
        val tvHealth = view.findViewById<TextView>(R.id.tvHealth)
        val tvClock = view.findViewById<TextView>(R.id.tvClock)
        val tvFastBadge = view.findViewById<TextView>(R.id.tvFastBadge)

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.snapshot.collect { s ->
                    gauge.setLevel(s.level, s.isCharging, s.isFastCharging)
                    tvEta.text = if (s.isCharging && s.etaMinutes >= 0) {
                        val h = s.etaMinutes / 60; val m = s.etaMinutes % 60
                        if (h > 0) "${h}j ${m}m" else "${m} menit"
                    } else "--"

                    tvVoltage.text = "${s.voltageMv} mV"
                    tvCurrent.text = "${s.currentMa} mA"
                    tvPower.text = "${s.powerMw} mW"

                    tvStatus.text = when {
                        s.isFastCharging -> "⚡ FAST CHARGING • ${s.chargingProtocol}"
                        s.isCharging -> "🔌 Charging • ${s.chargerType}"
                        else -> "🔋 ${s.status}"
                    }
                    tvStatus.setTextColor(when {
                        s.isFastCharging -> Color.parseColor("#00FF88")
                        s.isCharging -> Color.parseColor("#00D4FF")
                        else -> Color.parseColor("#8B9BB4")
                    })

                    tvHealth.text = "Health: ${s.health} • Suhu ${"%.1f".format(s.temperatureC)}°C"
                    tvClock.text = "🕐 ${timeFmt.format(Date(s.timestamp))}"

                    tvFastBadge.text = when {
                        s.isFastCharging -> "⚡ FAST"
                        s.isCharging -> "🔌 NORMAL"
                        else -> "🔋 IDLE"
                    }
                    tvFastBadge.setTextColor(when {
                        s.isFastCharging -> Color.parseColor("#00FF88")
                        s.isCharging -> Color.parseColor("#00D4FF")
                        else -> Color.parseColor("#8B9BB4")
                    })
                }
            }
        }
    }
}