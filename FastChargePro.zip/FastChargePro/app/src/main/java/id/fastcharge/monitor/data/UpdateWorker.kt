package id.fastcharge.monitor.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        val info = UpdateChecker(applicationContext).checkForUpdate()
        applicationContext.getSharedPreferences("updater", Context.MODE_PRIVATE).edit()
            .putBoolean("has_update", info != null)
            .putInt("new_code", info?.versionCode ?: 0)
            .putString("new_name", info?.versionName)
            .putString("apk_url", info?.apkUrl)
            .putLong("last_check_ms", System.currentTimeMillis())
            .apply()
        Result.success()
    } catch (_: Exception) { Result.retry() }

    companion object {
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            // WorkManager membatasi interval periodik minimum menjadi 15 menit.
            // Pemeriksaan saat aplikasi dibuka tetap berjalan di MainActivity.
            val request = PeriodicWorkRequestBuilder<UpdateWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "auto_update_check",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
