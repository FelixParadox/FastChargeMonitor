// data/UpdateWorker.kt
package id.fastcharge.monitor.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val info = UpdateChecker(applicationContext).checkForUpdate()
        // Simpan ke SharedPreferences untuk ditampilkan nanti
        applicationContext.getSharedPreferences("updater", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("has_update", info != null)
            .putInt("new_code", info?.versionCode ?: 0)
            .apply()
        return Result.success()
    }

    companion object {
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<UpdateWorker>(12, TimeUnit.HOURS).build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(
                    "auto_update_check",
                    androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
        }
    }
}