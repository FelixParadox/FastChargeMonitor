package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.util.Locale
import kotlin.math.abs

class BatteryReader(context: Context) {
    private val appContext = context.applicationContext
    private val batteryManager =
        appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        /** Perkiraan daya pada sisi baterai, bukan daya adaptor USB. */
        val powerW: Double?,
        val inputVoltageV: Double?,
        val inputCurrentMa: Double?,
        /** Hanya tersedia bila supply input mengekspos power_now atau V dan I. */
        val inputPowerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float?,
        val health: Int,
        val isRealData: Boolean,
        val currentSource: String?,
        val chargeType: String?,
        val thermalSensors: List<Pair<String, Double>>,
        val supplyDiagnostics: List<String>,
        val errorInfo: String?
    )

    fun read(): Data {
        val diagnostics = mutableListOf<String>()
        val batteryIntent = try {
            appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) {
            diagnostics += "BATTERY_BROADCAST_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            null
        }

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) {
            (level * 100f / scale).toInt().coerceIn(0, 100)
        } else -1
        val broadcastVoltageMv = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(
            BatteryManager.EXTRA_STATUS,
            BatteryManager.BATTERY_STATUS_UNKNOWN
        ) ?: BatteryManager.BATTERY_STATUS_UNKNOWN
        val temperatureTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val health = batteryIntent?.getIntExtra(
            BatteryManager.EXTRA_HEALTH,
            BatteryManager.BATTERY_HEALTH_UNKNOWN
        ) ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full = status == BatteryManager.BATTERY_STATUS_FULL || percent == 100
        val apiTemperature = temperatureTenths.takeIf { it in 1..1500 }?.div(10f)

        val scan = SysfsReader.scan()
        diagnostics += scan.errors
        val battery = scan.supplies.firstOrNull { it.type == "battery" }
        val inputs = scan.supplies.filter { it.type != "battery" }
        val onlineInput = inputs.firstOrNull { it.online == true }
        val input = onlineInput ?: when (plugged) {
            BatteryManager.BATTERY_PLUGGED_USB -> inputs.firstOrNull { it.type == "usb" }
            BatteryManager.BATTERY_PLUGGED_AC -> inputs.firstOrNull { it.type == "ac" }
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> inputs.firstOrNull { it.type == "wireless" }
            else -> null
        }

        // CURRENT_NOW umumnya dalam microamp. Nilai 0 adalah nilai sah; MIN_VALUE berarti unsupported.
        val apiCurrentUa = try {
            batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (e: Exception) {
            diagnostics += "BATTERY_API_CURRENT_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            Long.MIN_VALUE
        }
        val sysfsCurrentUa = battery?.currentUa
        val currentUa: Long? = when {
            sysfsCurrentUa != null -> {
                diagnostics += "CURRENT_SOURCE: sysfs ${battery?.name ?: "battery"}/current_now"
                sysfsCurrentUa
            }
            apiCurrentUa != Long.MIN_VALUE && apiCurrentUa != Int.MIN_VALUE.toLong() -> {
                diagnostics += "CURRENT_SOURCE: BatteryManager.CURRENT_NOW"
                apiCurrentUa
            }
            else -> {
                diagnostics += "CURRENT_UNAVAILABLE: sysfs current_now dan BatteryManager CURRENT_NOW tidak memberikan nilai"
                null
            }
        }
        val currentMa = currentUa?.toDouble()?.let { abs(it) / 1000.0 }

        val batteryVoltageV = battery?.voltageUv?.takeIf { it > 0L }?.div(1_000_000.0)
            ?: broadcastVoltageMv.takeIf { it > 0 }?.div(1000.0)
        val batteryPowerW = if (currentMa != null && batteryVoltageV != null) {
            currentMa * batteryVoltageV / 1000.0
        } else null

        val inputVoltageV = input?.voltageUv?.takeIf { it > 0L }?.div(1_000_000.0)
        val inputCurrentMa = input?.currentUa?.let { abs(it.toDouble()) / 1000.0 }
        val inputPowerW = input?.powerUw?.takeIf { it > 0L }?.div(1_000_000.0)
            ?: if (inputVoltageV != null && inputCurrentMa != null) {
                inputVoltageV * inputCurrentMa / 1000.0
            } else null

        val sysfsTemperature = battery?.temperatureTenthsC
            ?.takeIf { it in 1L..1500L }
            ?.div(10.0)
            ?.toFloat()
        val temperature = sysfsTemperature ?: apiTemperature
        if (temperature == null) {
            diagnostics += "TEMPERATURE_UNAVAILABLE: EXTRA_TEMPERATURE dan battery/temp tidak valid/terbaca"
        }
        if (scan.supplies.isEmpty()) {
            diagnostics += "SYSFS_POWER_SUPPLY_EMPTY: tidak ada supply yang dapat dipindai"
        }
        if (currentMa == null) {
            diagnostics += "HINT: periksa izin akses sysfs dan dukungan kernel; nilai arus tidak direkayasa"
        }

        val sourceLabel = when {
            battery != null && sysfsCurrentUa != null -> "sysfs:${battery.name}/current_now"
            currentUa != null -> "Android BatteryManager"
            else -> null
        }
        val supplyDiagnostics = scan.supplies.map { supply ->
            val attributes = supply.readableAttributes.keys.joinToString(", ")
                .ifBlank { "tidak ada atribut terbaca" }
            val errors = supply.errors.take(2).joinToString("; ")
            "${supply.name} [type=${supply.type}, online=${supply.online ?: "N/A"}]: $attributes" +
                if (errors.isNotBlank()) " | $errors" else ""
        } + diagnostics

        return Data(
            percent = percent,
            voltageMv = batteryVoltageV?.let { (it * 1000.0).toInt() } ?: broadcastVoltageMv,
            currentMa = currentMa,
            powerW = batteryPowerW,
            inputVoltageV = inputVoltageV,
            inputCurrentMa = inputCurrentMa,
            inputPowerW = inputPowerW,
            isCharging = charging,
            isFull = full,
            temperatureC = temperature,
            health = health,
            isRealData = currentMa != null,
            currentSource = sourceLabel,
            chargeType = input?.chargeType ?: input?.usbType ?: battery?.chargeType,
            thermalSensors = scan.thermalSensors,
            supplyDiagnostics = supplyDiagnostics,
            errorInfo = if (currentMa == null || temperature == null) diagnostics.joinToString("\n") else null
        )
    }
}
