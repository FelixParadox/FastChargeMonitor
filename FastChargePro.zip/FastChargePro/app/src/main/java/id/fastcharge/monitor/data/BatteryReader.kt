package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class BatteryReader(context: Context) {
    private val appContext = context.applicationContext
    private val bm = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val inputVoltageV: Double?,
        val inputCurrentMa: Double?,
        val inputPowerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float?,
        val health: Int,
        val isRealData: Boolean,
        val currentSource: String?,
        val chargeType: String?,
        val thermalSensors: List<Pair<String, Double>>,
        val supplyDiagnostics: List<String>,
        val errorInfo: String?
    )

    fun read(): Data {
        val diagnostics = mutableListOf<String>()
        val intent = try {
            appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) {
            diagnostics += "BATTERY_BROADCAST_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            null
        }
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) (level * 100f / scale).toInt().coerceIn(0, 100) else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
            ?: BatteryManager.BATTERY_STATUS_UNKNOWN
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full = status == BatteryManager.BATTERY_STATUS_FULL || percent == 100
        val apiTemp = tempTenths.takeIf { it in 1..1500 }?.div(10f)

        val scan = SysfsReader.scan()
        diagnostics += scan.errors
        val battery = scan.supplies.firstOrNull { it.type == "battery" }
        val inputs = scan.supplies.filter { it.type != "battery" }
        val onlineInput = inputs.firstOrNull { it.online == true }
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val input = onlineInput
            ?: when (plugged) {
                BatteryManager.BATTERY_PLUGGED_USB -> inputs.firstOrNull { it.type == "usb" }
                BatteryManager.BATTERY_PLUGGED_AC -> inputs.firstOrNull { it.type == "ac" }
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> inputs.firstOrNull { it.type == "wireless" }
                else -> null
            }

        val apiCurrent = try {
            bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (e: Exception) {
            diagnostics += "BATTERY_API_CURRENT_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            Long.MIN_VALUE
        }
        val sysfsCurrent = battery?.currentUa
        val currentUa: Long? = when {
            sysfsCurrent != null && sysfsCurrent != Long.MIN_VALUE ->
                sysfsCurrent.also { diagnostics += "CURRENT_SOURCE: sysfs ${battery?.name}/current_now" }
            apiCurrent != Long.MIN_VALUE && apiCurrent != 0L ->
                apiCurrent.also { diagnostics += "CURRENT_SOURCE: BatteryManager.CURRENT_NOW" }
            apiCurrent == 0L ->
                0L.also { diagnostics += "CURRENT_SOURCE: BatteryManager.CURRENT_NOW (0, mungkin tidak tersedia)" }
            else -> {
                diagnostics += "CURRENT_UNAVAILABLE: sysfs battery/current_now dan BatteryManager CURRENT_NOW tidak memberikan nilai"
                null
            }
        }
        val currentMa = currentUa?.let { abs(it.toDouble()) / 1000.0 }
        val voltageV = battery?.voltageUv?.takeIf { it > 0L }?.div(1_000_000.0)
            ?: voltageMv.takeIf { it > 0 }?.div(1000.0)
        val batteryPowerW = if (currentMa != null && voltageV != null) currentMa * voltageV / 1000.0 else null

        val inputVoltageV = input?.voltageUv?.takeIf { it > 0L }?.div(1_000_000.0)
        val inputCurrentMa = input?.currentUa?.let { abs(it.toDouble()) / 1000.0 }
        val inputPowerW = input?.powerUw?.takeIf { it > 0L }?.div(1_000_000.0)
            ?: if (inputVoltageV != null && inputCurrentMa != null) inputVoltageV * inputCurrentMa / 1000.0 else null

        val rawBatteryTemp = battery?.temperatureTenthsC
        val sysfsTemp = rawBatteryTemp?.takeIf { it in 1L..1500L }?.div(10.0)?.toFloat()
        val temperature = sysfsTemp ?: apiTemp
        if (temperature == null) diagnostics += "TEMPERATURE_UNAVAILABLE: EXTRA_TEMPERATURE dan battery/temp tidak valid/terbaca"
        if (scan.supplies.isEmpty()) diagnostics += "SYSFS_POWER_SUPPLY_EMPTY: tidak ada direktori power_supply yang dapat dipindai"
        if (currentMa == null) diagnostics += "HINT: cek pembatasan akses sysfs; angka arus tidak boleh dibuat-buat"

        val sourceLabel = when {
            battery != null && sysfsCurrent != null -> "sysfs:${battery.name}/current_now"
            currentUa != null -> "Android BatteryManager"
            else -> null
        }
        val supplyDiagnostics = scan.supplies.map { s ->
            val attrs = s.readableAttributes.keys.joinToString(", ").ifBlank { "tidak ada atribut terbaca" }
            val errs = s.errors.take(2).joinToString("; ")
            "${s.name} [type=${s.type}, online=${s.online ?: "N/A"}]: $attrs" + if (errs.isNotBlank()) " | $errs" else ""
        } + diagnostics

        return Data(
            percent = percent,
            voltageMv = if (voltageV != null) (voltageV * 1000).toInt() else voltageMv,
            currentMa = currentMa,
            powerW = batteryPowerW,
            inputVoltageV = inputVoltageV,
            inputCurrentMa = inputCurrentMa,
            inputPowerW = inputPowerW,
            isCharging = charging,
            isFull = full,
            temperatureC = temperature,
            health = health,
            isRealData = currentMa != null && currentMa > 0.0,
            currentSource = sourceLabel,
            chargeType = input?.chargeType ?: battery?.chargeType,
            thermalSensors = scan.thermalSensors,
            supplyDiagnostics = supplyDiagnostics,
            errorInfo = if (currentMa == null || temperature == null) diagnostics.joinToString("\n") else null
        )
    }
}