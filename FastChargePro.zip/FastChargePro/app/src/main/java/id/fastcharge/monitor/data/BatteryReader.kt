package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class BatteryReader(private val context: Context) {
    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int, val voltageMv: Int, val currentMa: Double?,
        val powerW: Double?, val isCharging: Boolean, val isFull: Boolean
    )

    fun read(): Data {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0) level * 100 / scale else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

        var currentUa = try { bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (_: Exception) { Long.MIN_VALUE }
        
        // Fallback ke Sysfs jika BatteryManager gagal/nol
        if (currentUa == Long.MIN_VALUE || currentUa == 0L) {
            currentUa = SysfsReader.readCurrentUa() ?: Long.MIN_VALUE
        }

        val currentMa = if (currentUa != Long.MIN_VALUE && currentUa != Int.MIN_VALUE.toLong()) abs(currentUa) / 1000.0 else null
        val voltageV = if (voltageMv > 0) voltageMv / 1000.0 else null
        val powerW = if (currentMa != null && voltageV != null) (currentMa / 1000.0) * voltageV else null

        return Data(
            percent, voltageMv, currentMa, powerW,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING,
            isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100
        )
    }
}