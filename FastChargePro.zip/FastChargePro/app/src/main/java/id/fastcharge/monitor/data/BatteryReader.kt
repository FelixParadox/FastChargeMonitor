package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class BatteryReader(private val context: Context) {
    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float,
        val health: Int,
        val isRealData: Boolean
    )

    fun read(): Data {
        val intent = try {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) { null }

        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        var currentUa = try {
            bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: Long.MIN_VALUE
        } catch (_: Exception) { Long.MIN_VALUE }

        if (currentUa == Long.MIN_VALUE || currentUa == 0L) {
            currentUa = SysfsReader.readCurrentUa() ?: Long.MIN_VALUE
        }

        var currentMa: Double? = null
        var isRealData = false
        if (currentUa != Long.MIN_VALUE && currentUa != 0L) {
            currentMa = abs(currentUa) / 1000.0
            isRealData = true
        }

        var powerW: Double? = null
        if (currentMa != null && voltageMv > 0) {
            powerW = (currentMa / 1000.0) * (voltageMv / 1000.0)
        }

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = tempTenths / 10f,
            health = health,
            isRealData = isRealData
        )
    }
}