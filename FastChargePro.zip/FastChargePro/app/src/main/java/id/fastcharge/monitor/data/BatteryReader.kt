package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.util.Locale
import kotlin.math.abs

class BatteryReader(context: Context) {

    private val appContext = context.applicationContext

    private val batteryManager: BatteryManager =
        appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val inputVoltageV: Double?,
        val inputCurrentMa: Double?,
        val inputPowerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float?,
        val health: Int,
        val isRealData: Boolean,
        val currentSource: String?,
        val chargeType: String?,
        val thermalSensors: List<Pair<String, Double>>,
        val supplyDiagnostics: List<String>,
        val errorInfo: String?
    )

    private data class CurrentResult(
        val microAmps: Long?,
        val source: String?,
        val errors: List<String>
    )

    private fun readCurrent(): CurrentResult {
        val errors = mutableListOf<String>()

        val properties = listOf(
            BatteryManager.BATTERY_PROPERTY_CURRENT_NOW to "CURRENT_NOW",
            BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE to "CURRENT_AVERAGE"
        )

        for ((property, label) in properties) {
            try {
                val value = batteryManager.getLongProperty(property)

                if (value != Long.MIN_VALUE &&
                    value != Int.MIN_VALUE.toLong()
                ) {
                    return CurrentResult(
                        microAmps = value,
                        source = "BatteryManager.$label",
                        errors = errors
                    )
                }

                errors += "$label tidak didukung atau tidak tersedia"
            } catch (e: Exception) {
                errors += "$label gagal: ${e.javaClass.simpleName}: " +
                    (e.message ?: "tanpa detail")
            }
        }

        return CurrentResult(
            microAmps = null,
            source = null,
            errors = errors
        )
    }

    fun read(): Data {
        val diagnostics = mutableListOf<String>()

        val intent: Intent? = try {
            appContext.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
        } catch (e: Exception) {
            diagnostics += "BATTERY_BROADCAST_ERROR: " +
                "${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            null
        }

        val level = intent?.getIntExtra(
            BatteryManager.EXTRA_LEVEL, -1
        ) ?: -1

        val scale = intent?.getIntExtra(
            BatteryManager.EXTRA_SCALE, -1
        ) ?: -1

        val percent = if (level >= 0 && scale > 0) {
            (level * 100f / scale).toInt().coerceIn(0, 100)
        } else {
            -1
        }

        val voltageMv = intent?.getIntExtra(
            BatteryManager.EXTRA_VOLTAGE, -1
        ) ?: -1

        val status = intent?.getIntExtra(
            BatteryManager.EXTRA_STATUS,
            BatteryManager.BATTERY_STATUS_UNKNOWN
        ) ?: BatteryManager.BATTERY_STATUS_UNKNOWN

        val plugged = intent?.getIntExtra(
            BatteryManager.EXTRA_PLUGGED, 0
        ) ?: 0

        val tempTenths = intent?.getIntExtra(
            BatteryManager.EXTRA_TEMPERATURE, -1
        ) ?: -1

        val health = intent?.getIntExtra(
            BatteryManager.EXTRA_HEALTH,
            BatteryManager.BATTERY_HEALTH_UNKNOWN
        ) ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging =
            status == BatteryManager.BATTERY_STATUS_CHARGING

        val isFull =
            status == BatteryManager.BATTERY_STATUS_FULL ||
                percent == 100

        val temperatureC = tempTenths
            .takeIf { it in 1..1500 }
            ?.div(10f)

        if (intent == null) {
            diagnostics += "BATTERY_DATA_UNAVAILABLE: broadcast baterai tidak tersedia"
        }

        val current = readCurrent()
        diagnostics += current.errors

        val currentMa = current.microAmps?.let {
            abs(it.toDouble()) / 1000.0
        }

        if (currentMa == null) {
            diagnostics +=
                "CURRENT_UNAVAILABLE: Android tidak memberikan nilai arus yang valid"
        }

        if (temperatureC == null) {
            diagnostics +=
                "TEMPERATURE_UNAVAILABLE: suhu baterai tidak tersedia dari broadcast"
        }

        val voltageV = voltageMv
            .takeIf { it > 0 }
            ?.div(1000.0)

        val powerW = if (currentMa != null && voltageV != null) {
            currentMa * voltageV / 1000.0
        } else {
            null
        }

        if (powerW == null) {
            diagnostics +=
                "BATTERY_POWER_UNAVAILABLE: arus atau tegangan tidak tersedia"
        }

        val chargeType = when {
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "WIRELESS"
            else -> null
        }

        // Android API standar tidak menjamin arus dan watt masukan charger.
        val inputVoltageV: Double? = null
        val inputCurrentMa: Double? = null
        val inputPowerW: Double? = null

        if (plugged != 0 && inputPowerW == null) {
            diagnostics +=
                "INPUT_POWER_UNAVAILABLE: daya masukan charger tidak diekspos API standar"
        }

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            inputVoltageV = inputVoltageV,
            inputCurrentMa = inputCurrentMa,
            inputPowerW = inputPowerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = temperatureC,
            health = health,
            isRealData = currentMa != null,
            currentSource = current.source,
            chargeType = chargeType,
            thermalSensors = emptyList(),
            supplyDiagnostics = diagnostics.toList(),
            errorInfo = diagnostics.takeIf { it.isNotEmpty() }
                ?.joinToString("\n")
        )
    }

    companion object {
        fun healthLabel(health: Int): String {
            return when (health) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Baik"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Rusak"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan berlebih"
                BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gangguan tidak spesifik"
                else -> "Tidak diketahui"
            }
        }
    }
}