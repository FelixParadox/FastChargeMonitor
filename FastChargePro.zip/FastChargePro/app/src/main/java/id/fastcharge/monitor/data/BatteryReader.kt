package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import kotlin.math.abs

class BatteryReader(private val context: Context) {

    private val bm: BatteryManager? =
        context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,   // selalu positif (magnitude)
        val powerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float,
        val health: Int,
        val isRealData: Boolean,
        val source: String        // "api" / "sysfs" / "none" — buat debug
    )

    fun read(): Data {
        val intent = try {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) {
            Log.e(TAG, "registerReceiver failed", e); null
        }

        // ---------- Data dasar ----------
        val level   = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale   = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1

        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status    = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged   = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val health = intent?.getIntExtra(
            BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN
        ) ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                         status == BatteryManager.BATTERY_STATUS_FULL
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        // ---------- Baca arus: prioritas 1 = API resmi ----------
        var currentUa: Long? = null
        var source = "none"

        // 1. BatteryManager (microamps, bisa -/+, tergantung charging)
        try {
            val v = bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (v != null && v != Long.MIN_VALUE && v != 0L) {
                currentUa = v
                source = "api"
            }
        } catch (e: Exception) {
            Log.w(TAG, "BM current_now failed", e)
        }

        // 2. Fallback sysfs (microamps atau miliamps, tergantung vendor)
        if (currentUa == null) {
            val sys = SysfsReader.readCurrentUa()  // sudah dinormalisasi ke µA
            if (sys != null && sys != 0L) {
                currentUa = sys
                source = "sysfs"
            }
        }

        // 3. Fallback kedua: voltage_now + sysfs power_now (W µW)
        if (currentUa == null && voltageMv > 0) {
            val powerUw = SysfsReader.readPowerUw()
            if (powerUw != null && powerUw > 0L) {
                // I (µA) = P (µW) / V (V)  → konversi: V dalam mV, bagi 1000
                currentUa = powerUw * 1000L / voltageMv
                source = "sysfs-power"
            }
        }

        // ---------- Normalisasi tanda ----------
        var currentMa: Double? = null
        var isRealData = false
        if (currentUa != null && currentUa != Long.MIN_VALUE && currentUa != 0L) {
            // Beberapa vendor: positif saat discharge, negatif saat charge.
            // Ambil magnitude (absolute) untuk konsumsi display.
            currentMa = abs(currentUa) / 1000.0
            isRealData = true
        }

        // ---------- Daya (W) ----------
        var powerW: Double? = null
        if (currentMa != null && currentMa > 0.0 && voltageMv > 0) {
            powerW = (currentMa / 1000.0) * (voltageMv / 1000.0)
        }

        // Debug log (bisa dihapus saat produksi)
        Log.d(TAG, "src=$source curUa=$currentUa curMa=$currentMa " +
                "V=$voltageMv P=$powerW plugged=$plugged")

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = tempTenths / 10f,
            health = health,
            isRealData = isRealData,
            source = source
        )
    }

    companion object { private const val TAG = "BatteryReader" }
}