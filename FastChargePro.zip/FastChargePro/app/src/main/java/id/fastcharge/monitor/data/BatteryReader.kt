package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

/**
 * Reader gabungan: API Android seperti xxcc, scanner sysfs xxcc sebagai fallback,
 * serta field kompatibilitas yang dipakai UI fhas.
 */
class BatteryReader(context: Context) {
    private val appContext = context.applicationContext
    private val batteryManager = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val status: Int,
        val plugged: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val currentSignedMa: Double?,
        val powerW: Double?,
        val tempC: Double,
        val health: Int,
        val technology: String,
        val isCharging: Boolean,
        val isFull: Boolean,
        val source: String,
        val inputVoltageV: Double? = null,
        val inputCurrentMa: Double? = null,
        val inputPowerW: Double? = null,
        val currentSource: String? = null,
        val chargeType: String? = null,
        val thermalSensors: List<Pair<String, Double>> = emptyList(),
        val supplyDiagnostics: List<String> = emptyList(),
        val errorInfo: String? = null
    ) {
        val isRealData: Boolean
            get() = currentMa != null && currentMa.isFinite()
        val isPluggedIn: Boolean get() = plugged != 0
        val temperatureC: Float? get() = tempC.takeIf { it in 0.1..150.0 }?.toFloat()
    }

    private data class CurrentResult(val microAmps: Long?, val source: String?, val errors: List<String>)

    private fun readAndroidCurrent(): CurrentResult {
        val errors = mutableListOf<String>()
        var zeroCandidate: Long? = null
        val properties = listOf(
            BatteryManager.BATTERY_PROPERTY_CURRENT_NOW to "CURRENT_NOW",
            BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE to "CURRENT_AVERAGE"
        )
        for ((property, label) in properties) {
            try {
                val value = batteryManager.getLongProperty(property)
                val valid = value != Long.MIN_VALUE &&
                    value != Int.MIN_VALUE.toLong() &&
                    value != Int.MAX_VALUE.toLong() &&
                    abs(value) <= 20_000_000L
                if (valid) {
                    if (value != 0L) return CurrentResult(value, "BatteryManager.$label", errors)
                    // Nol bisa merupakan nilai valid, tetapi jangan hentikan fallback
                    // sebelum memeriksa CURRENT_AVERAGE dan atribut kernel.
                    if (zeroCandidate == null) zeroCandidate = value
                    errors += "$label bernilai 0; memeriksa sumber lain"
                } else {
                    errors += "$label tidak didukung atau nilainya tidak valid"
                }
            } catch (e: Exception) {
                errors += "$label gagal: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            }
        }
        return CurrentResult(zeroCandidate, if (zeroCandidate != null) "BatteryManager (nol)" else null, errors)
    }

    fun read(): Data {
        val diagnostics = mutableListOf<String>()
        val intent: Intent? = try {
            appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) {
            diagnostics += "BATTERY_BROADCAST_ERROR: ${e.javaClass.simpleName}: ${e.message ?: "tanpa detail"}"
            null
        }

        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100f / scale).toInt().coerceIn(0, 100) else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN) ?: BatteryManager.BATTERY_STATUS_UNKNOWN
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        var voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        var tempC = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10.0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN) ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val technology = intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"
        if (intent == null) diagnostics += "BATTERY_DATA_UNAVAILABLE: broadcast baterai tidak tersedia"

        val scan = SysfsReader.scan()
        diagnostics += scan.errors
        diagnostics += scan.supplies.flatMap { it.errors }

        val androidCurrent = readAndroidCurrent()
        diagnostics += androidCurrent.errors
        var currentUa = androidCurrent.microAmps
        var currentSource = androidCurrent.source

        val batterySupplies = scan.supplies.filter { it.type == "battery" }
        if (currentUa == null || currentUa == 0L) {
            var zeroSysfsCandidate: Pair<Long, String>? = null
            for (supply in batterySupplies) {
                val candidates = listOfNotNull(
                    supply.currentUa,
                    supply.readableAttributes["current_avg"]?.toLongOrNull(),
                    supply.readableAttributes["BatteryAverageCurrent"]?.toLongOrNull(),
                    supply.readableAttributes["BatteryCurrentNow"]?.toLongOrNull()
                )
                val raw = candidates.firstOrNull {
                    it != Long.MIN_VALUE && abs(it) <= 20_000_000L && it != 0L
                }
                if (raw != null) {
                    currentUa = raw
                    currentSource = "sysfs:${supply.name}"
                    break
                }
                if (zeroSysfsCandidate == null && candidates.any { it == 0L }) {
                    zeroSysfsCandidate = 0L to "sysfs:${supply.name}"
                }
            }
            if ((currentUa == null || currentUa == 0L) && zeroSysfsCandidate != null) {
                currentUa = zeroSysfsCandidate.first
                currentSource = zeroSysfsCandidate.second
            }
        }

        // Fallback tambahan: beberapa ROM Xiaomi tidak mengekspos CURRENT_NOW
        // melalui API, tetapi menyertakan current now pada dumpsys battery.
        if (currentUa == null || currentUa == 0L) {
            val dump = SysfsReader.readDumpsysBattery()
            val dumpValue = dump.first
            if (dumpValue != null && dumpValue != Long.MIN_VALUE && abs(dumpValue) <= 20_000_000L && dumpValue != 0L) {
                currentUa = dumpValue
                currentSource = "dumpsys battery"
            } else if (dump.second.startsWith("DUMPSYS_ERROR") || dump.second.startsWith("DUMPSYS_EXIT")) {
                diagnostics += dump.second
            }
        }

        if (voltageMv !in 2500..5000) {
            for (supply in batterySupplies) {
                val raw = supply.voltageUv ?: supply.readableAttributes["voltage_avg"]?.toLongOrNull()
                if (raw != null) {
                    val mv = when {
                        raw in 2_500_000L..5_000_000L -> raw / 1000L
                        raw in 2500L..5000L -> raw
                        else -> -1L
                    }
                    if (mv in 2500L..5000L) { voltageMv = mv.toInt(); break }
                }
            }
        }

        if (tempC !in 0.1..150.0) {
            val raw = batterySupplies.firstNotNullOfOrNull { it.temperatureTenthsC }
            if (raw != null) {
                val c = when {
                    abs(raw) >= 1000L -> raw / 1000.0 // millidegree Celsius
                    raw in 100L..1500L -> raw / 10.0 // tenth-degree Celsius
                    raw in 1L..150L -> raw.toDouble() // degree Celsius
                    else -> -1.0
                }
                if (c in 0.1..150.0) tempC = c
            }
        }

        val currentSignedMa = currentUa?.div(1000.0)
        val currentMa = currentSignedMa?.let { abs(it) }
        val voltageV = voltageMv.takeIf { it in 2500..5000 }?.div(1000.0)

        // Prefer kernel power_now when available; otherwise calculate I × V.
        val sysfsPowerW = batterySupplies.firstNotNullOfOrNull { s ->
            val raw = s.powerUw ?: s.readableAttributes["power_avg"]?.toLongOrNull()
            raw?.takeIf { it > 0L && it <= 300_000_000L }?.div(1_000_000.0)
        }
        val powerW = sysfsPowerW ?: if (currentMa != null && voltageV != null && currentMa.isFinite() && currentMa <= 20_000.0) {
            currentMa / 1000.0 * voltageV
        } else null

        val external = scan.supplies.filter { it.type == "usb" || it.type == "ac" || it.type == "wireless" }
        val inputVoltageV = external.firstNotNullOfOrNull { s ->
            val raw = s.voltageUv ?: s.readableAttributes["voltage_avg"]?.toLongOrNull()
            raw?.let { when { it in 1_000_000L..30_000_000L -> it / 1_000_000.0; it in 1000L..30000L -> it / 1000.0; else -> null } }
        }
        val inputCurrentMa = external.firstNotNullOfOrNull { s ->
            val raw = s.currentUa ?: s.readableAttributes["current_avg"]?.toLongOrNull()
            raw?.takeIf { abs(it) <= 20_000_000L }?.let { abs(it) / 1000.0 }
        }
        val inputPowerW = external.firstNotNullOfOrNull { s ->
            val raw = s.powerUw ?: s.readableAttributes["power_avg"]?.toLongOrNull()
            raw?.takeIf { it > 0L && it <= 300_000_000L }?.div(1_000_000.0)
        } ?: if (inputVoltageV != null && inputCurrentMa != null) inputVoltageV * inputCurrentMa / 1000.0 else null

        if (currentMa == null) diagnostics += "CURRENT_UNAVAILABLE: Android dan sysfs tidak memberikan nilai arus yang dapat dibaca"
        if (voltageMv !in 2500..5000) diagnostics += "VOLTAGE_UNAVAILABLE: tegangan baterai tidak tersedia"
        if (powerW == null) diagnostics += "BATTERY_POWER_UNAVAILABLE: arus, tegangan, atau power_now tidak tersedia"
        if (plugged != 0 && inputPowerW == null) diagnostics += "INPUT_POWER_UNAVAILABLE: kernel tidak mengekspos data daya masukan charger"

        val chargeType = when {
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "WIRELESS"
            else -> external.firstNotNullOfOrNull { it.chargeType ?: it.usbType }
        }
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            (status == BatteryManager.BATTERY_STATUS_FULL && plugged != 0)
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent == 100

        return Data(
            percent = percent, status = status, plugged = plugged,
            voltageMv = voltageMv, currentMa = currentMa,
            currentSignedMa = currentSignedMa, powerW = powerW,
            tempC = tempC, health = health, technology = technology,
            isCharging = isCharging, isFull = isFull,
            source = currentSource ?: "-", inputVoltageV = inputVoltageV,
            inputCurrentMa = inputCurrentMa, inputPowerW = inputPowerW,
            currentSource = currentSource, chargeType = chargeType,
            thermalSensors = scan.thermalSensors,
            supplyDiagnostics = diagnostics.toList(),
            errorInfo = diagnostics.takeIf { it.isNotEmpty() }?.joinToString("\n")
        )
    }

    companion object {
        fun healthLabel(health: Int): String = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Baik"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Rusak"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan berlebih"
            BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gangguan tidak spesifik"
            else -> "Tidak diketahui"
        }
    }
}
