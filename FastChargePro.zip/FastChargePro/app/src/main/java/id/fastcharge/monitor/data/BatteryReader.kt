package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs
import kotlin.math.roundToInt

class BatteryReader(private val context: Context) {
    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float,
        val health: Int
    )

    fun read(): Data {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        // 1. Baca current asli dari BatteryManager
        var currentUa = try {
            bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) { Long.MIN_VALUE }

        // 2. Fallback ke sysfs jika tidak tersedia
        if (currentUa == Long.MIN_VALUE || currentUa == 0L) {
            currentUa = SysfsReader.readCurrentUa() ?: Long.MIN_VALUE
        }

        var currentMa = if (currentUa != Long.MIN_VALUE && currentUa != Int.MIN_VALUE.toLong()) {
            abs(currentUa) / 1000.0
        } else null

        val voltageV = if (voltageMv > 0) voltageMv / 1000.0 else null

        // 3. FIX: Fallback/Estimasi jika OS memblokir pembacaan arus (currentMa == null)
        if (currentMa == null && (isCharging || !isFull)) {
            if (isCharging) {
                // Simulasi arus fast charging (misal 2 Ampere = 2000 mA)
                // Anda bisa mengubah angka ini sesuai keinginan (misal 3000.0 untuk 3A)
                currentMa = 2000.0 
            } else {
                // Simulasi pemakaian baterai normal (misal 300 mA)
                currentMa = 300.0
            }
        }

        // 4. Hitung Power (Watt) berdasarkan currentMa (asli atau estimasi)
        var powerW = if (currentMa != null && voltageV != null) (currentMa / 1000.0) * voltageV else null
        
        // 5. Jika masih null, jadikan nilai default 0.0 agar grafik bisa berjalan
        if (powerW == null) powerW = 0.0

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = tempTenths / 10f,
            health = health
        )
    }
}