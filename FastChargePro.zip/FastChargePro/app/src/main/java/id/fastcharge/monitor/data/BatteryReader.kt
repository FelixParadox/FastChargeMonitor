package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class BatteryReader(private val context: Context) {
    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float,
        val health: Int,
        val isRealData: Boolean,
        val errorInfo: String? // Menyimpan pesan error nyata
    )

    fun read(): Data {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        var currentMa: Double? = null
        var isRealData = false
        var errorLog = StringBuilder()

        // --- JALUR 1: API BatteryManager ---
        try {
            val currentUa = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (currentUa == Long.MIN_VALUE || currentUa == Int.MIN_VALUE.toLong() || currentUa == 0L) {
                errorLog.append("[API: Gagal/Nilai 0] ")
            } else {
                currentMa = abs(currentUa) / 1000.0
                isRealData = true
            }
        } catch (e: Exception) {
            errorLog.append("[API: ${e.message}] ")
        }

        // --- JALUR 2: SysfsReader (Jika Jalur 1 Gagal) ---
        if (!isRealData) {
            val sysfsResult = SysfsReader.readCurrentUaWithError()
            if (sysfsResult.first != null && sysfsResult.first != 0L) {
                currentMa = abs(sysfsResult.first) / 1000.0
                isRealData = true
                errorLog.clear() // Bersihkan error jika sysfs berhasil
            } else {
                errorLog.append("[Sysfs: ${sysfsResult.second}] ")
            }
        }

        // --- JALUR 3: Dumpsys (Opsional, coba baca dari sistem) ---
        if (!isRealData) {
            val dumpsysResult = SysfsReader.readDumpsysBattery()
            if (dumpsysResult.first != null && dumpsysResult.first != 0L) {
                currentMa = abs(dumpsysResult.first) / 1000.0
                isRealData = true
                errorLog.clear()
            } else {
                errorLog.append("[Dumpsys: ${dumpsysResult.second}] ")
            }
        }

        var powerW: Double? = null
        if (isRealData && currentMa != null && voltageMv > 0) {
            powerW = (currentMa / 1000.0) * (voltageMv / 1000.0)
        }

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = tempTenths / 10f,
            health = health,
            isRealData = isRealData,
            errorInfo = if (!isRealData) errorLog.toString().trim() else null
        )
    }
}