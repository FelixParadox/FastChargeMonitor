package id.fastcharge.monitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

class BatteryReader(private val context: Context) {
    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val isCharging: Boolean,
        val isFull: Boolean,
        val temperatureC: Float,
        val health: Int,
        val isRealData: Boolean // Tambahkan flag baru: apakah ini data nyata
    )

    fun read(): Data {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN

        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        // 1. Coba baca arus dari BatteryManager resmi
        var currentUa = try {
            bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) { Long.MIN_VALUE }

        // 2. Jika API resmi tidak mengembalikan nilai, coba baca dari jalur file sistem (kemungkinan besar akan gagal karena izin, tetapi patut dicoba)
        if (currentUa == Long.MIN_VALUE || currentUa == 0L) {
            currentUa = SysfsReader.readCurrentUa() ?: Long.MIN_VALUE
        }

        // 3. Nilai yang dikembalikan harus berupa nilai yang valid (bukan nilai error/0) agar dianggap sebagai data nyata
        var currentMa: Double? = null
        var isRealData = false
        if (currentUa != Long.MIN_VALUE && currentUa != 0L) {
            // Perhatikan: beberapa ponsel mengembalikan nilai positif saat pengisian, beberapa negatif, di sini diambil nilai absolut
            currentMa = abs(currentUa) / 1000.0
            isRealData = true
        }

        // 4. Hitung daya, hanya hitung jika ada data arus
        var powerW: Double? = null
        if (currentMa != null && voltageMv > 0) {
            powerW = (currentMa / 1000.0) * (voltageMv / 1000.0)
        }

        return Data(
            percent = percent,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            isCharging = isCharging,
            isFull = isFull,
            temperatureC = tempTenths / 10f,
            health = health,
            isRealData = isRealData // Kembalikan flag
        )
    }
}