package id.fastcharge.monitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Repository pembacaan baterai Android.
 *
 * Catatan akurasi:
 * - CURRENT_NOW/CURRENT_AVERAGE adalah arus sisi baterai, bukan pengukuran langsung
 *   arus yang keluar dari adaptor/charger.
 * - Nama protokol pengisian di bawah adalah perkiraan dari data yang tersedia.
 *   Android biasa tidak selalu membuka informasi negosiasi USB-PD/QC ke aplikasi.
 * - Akses sysfs berbeda-beda antarperangkat dan dapat dibatasi oleh Android.
 */
data class BatterySnapshot(
    val timestamp: Long,
    val level: Int,
    val voltageMv: Int,
    val currentMa: Int,
    val powerMw: Int,
    val temperatureC: Float,
    val health: String,
    val status: String,
    val plugged: String,
    val isCharging: Boolean,
    val isFastCharging: Boolean,
    val chargingProtocol: String,
    val connectorType: String,
    val chargerType: String,
    val etaMinutes: Int,
    val chargeSpeedPctPerMin: Float,
    val batteryCapacityMah: Int,
    val cycleCount: Int
)

data class DiagnosisItem(
    val category: String,
    val title: String,
    val status: Status,
    val detail: String,
    val recommendation: String
) {
    enum class Status { GOOD, INFO, WARNING, BAD }
}

class BatteryRepository private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    private val _snapshot = MutableStateFlow(emptySnapshot())
    val snapshot: StateFlow<BatterySnapshot> = _snapshot.asStateFlow()

    private val _history = MutableStateFlow<List<BatterySnapshot>>(emptyList())
    val history: StateFlow<List<BatterySnapshot>> = _history.asStateFlow()

    private val _diagnosis = MutableStateFlow<List<DiagnosisItem>>(emptyList())
    val diagnosis: StateFlow<List<DiagnosisItem>> = _diagnosis.asStateFlow()

    private val historyBuffer = ArrayDeque<BatterySnapshot>()
    private val historyLock = Any()
    private val maxHistory = 7_200 // Maksimal sekitar 1 jam pada interval 500 ms.
    private val pollIntervalMs = 500L

    @Volatile
    private var running = false

    private var receiverRegistered = false
    private var lastLevel = -1
    private var lastLevelElapsedMs = 0L
    private var chargeSpeedPctPerMin = 0f
    private var lastKnownCurrentMa = 0
    private var consecutiveZeroCurrentCount = 0

    private data class CurrentReading(
        val milliamps: Int,
        val source: String,
        val rawMicroamps: Long
    )

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Receiver hanya menjadi pemicu pembacaan lebih cepat saat ada perubahan.
            // Loop polling tetap menjadi sumber pembaruan berkala.
            if (running) pollSafely()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                pollSafely()
            } finally {
                // Cek kembali setelah poll: stop() tidak boleh membuat loop hidup lagi.
                if (running) handler.postDelayed(this, pollIntervalMs)
            }
        }
    }

    @Synchronized
    fun start() {
        if (running) return
        running = true

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(Intent.ACTION_BATTERY_LOW)
                addAction(Intent.ACTION_BATTERY_OKAY)
            }
            appContext.registerReceiver(batteryReceiver, filter)
            receiverRegistered = true
        } catch (e: Exception) {
            // ACTION_BATTERY_CHANGED bersifat sticky; poll() tetap mencoba membacanya.
            Log.w(TAG, "Tidak dapat mendaftarkan receiver baterai: ${e.message}")
            receiverRegistered = false
        }

        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    @Synchronized
    fun stop() {
        running = false
        handler.removeCallbacks(ticker)

        if (receiverRegistered) {
            try {
                appContext.unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "Receiver baterai sudah tidak terdaftar: ${e.message}")
            } finally {
                receiverRegistered = false
            }
        }
    }

    private fun pollSafely() {
        try {
            poll()
        } catch (e: Exception) {
            Log.e(TAG, "Gagal memperbarui data baterai", e)
        }
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        val intent = try {
            appContext.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Gagal membaca ACTION_BATTERY_CHANGED: ${e.message}")
            null
        } ?: return

        val levelRaw = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val level = if (levelRaw >= 0) {
            ((levelRaw * 100f) / scale).roundToInt().coerceIn(0, 100)
        } else {
            _snapshot.value.level
        }

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0).coerceAtLeast(0)
        val temperatureRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperatureC = if (temperatureRaw != Int.MIN_VALUE) {
            temperatureRaw / 10f
        } else {
            0f // Nilai 0 di sini berarti data tidak tersedia atau tidak dilaporkan.
        }

        val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pluggedInt = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val status = statusToString(statusInt)
        val plugged = pluggedToString(pluggedInt)
        val isActuallyCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING
        val isChargingOrFull = isActuallyCharging ||
            statusInt == BatteryManager.BATTERY_STATUS_FULL

        val currentReading = readCurrentMa()
        val currentMa = currentReading.milliamps
        updateCurrentMemory(currentMa, pluggedInt != 0 && isActuallyCharging)

        val powerMw = ((voltageMv.toLong() * currentMa.toLong()) / 1000L)
            .coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()

        val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val health = healthToString(healthInt)
        val batteryCapacityMah = readBatteryCapacityMah()
        val cycleCount = readCycleCount()

        updateChargeSpeed(level, isActuallyCharging, pluggedInt != 0)
        val etaMinutes = computeEta(level, isActuallyCharging)

        val isFastCharging = isActuallyCharging &&
            level < 100 &&
            isLikelyFastCharging(voltageMv, currentMa, powerMw)

        val protocol = detectChargingProtocol(
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerMw = powerMw,
            pluggedInt = pluggedInt,
            isCharging = isActuallyCharging,
            isFast = isFastCharging
        )

        val newSnapshot = BatterySnapshot(
            timestamp = System.currentTimeMillis(),
            level = level,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerMw = powerMw,
            temperatureC = temperatureC,
            health = health,
            status = status,
            plugged = plugged,
            isCharging = isChargingOrFull,
            isFastCharging = isFastCharging,
            chargingProtocol = protocol,
            connectorType = detectConnectorType(pluggedInt),
            chargerType = detectChargerType(pluggedInt, isFastCharging, protocol),
            etaMinutes = etaMinutes,
            chargeSpeedPctPerMin = chargeSpeedPctPerMin,
            batteryCapacityMah = batteryCapacityMah,
            cycleCount = cycleCount
        )

        _snapshot.value = newSnapshot
        synchronized(historyLock) {
            historyBuffer.addLast(newSnapshot)
            while (historyBuffer.size > maxHistory) historyBuffer.removeFirst()
            _history.value = historyBuffer.toList()
        }
        _diagnosis.value = diagnose(newSnapshot, currentReading.source)
    }

    /**
     * Android CURRENT_NOW / CURRENT_AVERAGE biasanya berunit mikroampere.
     * Sumber yang pertama memberi nilai masuk akal dipakai. Tanda arus diubah
     * menjadi magnitudo karena layar monitor umumnya ingin menampilkan besarnya arus.
     */
    private fun readCurrentMa(): CurrentReading {
        val batteryManager = appContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val candidates = mutableListOf<Pair<String, Long>>()

        if (batteryManager != null) {
            try {
                val now = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                if (now != Int.MIN_VALUE) candidates += "Android CURRENT_NOW" to now.toLong()
            } catch (e: Exception) {
                Log.d(TAG, "CURRENT_NOW tidak tersedia: ${e.message}")
            }

            try {
                val average = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
                if (average != Int.MIN_VALUE) candidates += "Android CURRENT_AVERAGE" to average.toLong()
            } catch (e: Exception) {
                Log.d(TAG, "CURRENT_AVERAGE tidak tersedia: ${e.message}")
            }
        }

        val sysfsPaths = listOf(
            "/sys/class/power_supply/battery/current_now",
            "/sys/class/power_supply/bms/current_now",
            "/sys/class/power_supply/Battery/current_now",
            "/sys/class/power_supply/battery/current_avg",
            "/sys/class/power_supply/bms/current_avg",
            "/sys/class/power_supply/Battery/current_avg"
        )

        for (path in sysfsPaths) {
            readLongFile(path)?.let { candidates += path to it }
        }

        // CURRENT_NOW/AVERAGE biasanya µA. Nilai di luar rentang masuk akal diabaikan.
        for ((source, raw) in candidates) {
            val absolute = abs(raw)
            if (absolute == 0L || absolute > MAX_CURRENT_UA) continue
            val ma = (absolute / 1000L).toInt()
            if (ma in 1..MAX_CURRENT_MA) {
                return CurrentReading(ma, source, raw)
            }
        }

        return CurrentReading(
            milliamps = 0,
            source = "Tidak tersedia",
            rawMicroamps = 0L
        )
    }

    private fun updateCurrentMemory(currentMa: Int, charging: Boolean) {
        if (!charging) {
            lastKnownCurrentMa = 0
            consecutiveZeroCurrentCount = 0
            return
        }

        if (currentMa > 0) {
            lastKnownCurrentMa = currentMa
            consecutiveZeroCurrentCount = 0
        } else {
            consecutiveZeroCurrentCount++
            // lastKnownCurrentMa sengaja disimpan sebagai konteks diagnostik saja;
            // tidak dipakai mengganti nilai sensor 0 agar data tidak dipalsukan.
        }
    }

    private fun updateChargeSpeed(level: Int, charging: Boolean, plugged: Boolean) {
        val now = SystemClock.elapsedRealtime()

        if (!charging || !plugged) {
            lastLevel = level
            lastLevelElapsedMs = now
            chargeSpeedPctPerMin = 0f
            return
        }

        if (lastLevel < 0 || lastLevelElapsedMs == 0L) {
            lastLevel = level
            lastLevelElapsedMs = now
            return
        }

        if (level != lastLevel) {
            val elapsedMs = now - lastLevelElapsedMs
            if (elapsedMs > 0L) {
                val delta = level - lastLevel
                val speed = delta * 60_000f / elapsedMs
                // Hanya simpan laju pengisian positif; penurunan level bukan kecepatan charge.
                chargeSpeedPctPerMin = if (speed > 0f) speed.coerceAtMost(100f) else 0f
            }
            lastLevel = level
            lastLevelElapsedMs = now
        }
    }

    private fun computeEta(level: Int, charging: Boolean): Int {
        if (!charging || level >= 100) return -1
        if (chargeSpeedPctPerMin < MIN_VALID_CHARGE_SPEED) return -1
        val remaining = 100 - level
        return (remaining / chargeSpeedPctPerMin).roundToInt().coerceAtLeast(1)
    }

    private fun isLikelyFastCharging(voltageMv: Int, currentMa: Int, powerMw: Int): Boolean {
        // Ini hanya estimasi. Perangkat bisa punya batas/profil yang berbeda.
        return powerMw >= 7_500 ||
            (voltageMv >= 8_000 && currentMa >= 700) ||
            (currentMa >= 1_800 && voltageMv >= 4_000)
    }

    private fun detectChargingProtocol(
        voltageMv: Int,
        currentMa: Int,
        powerMw: Int,
        pluggedInt: Int,
        isCharging: Boolean,
        isFast: Boolean
    ): String {
        if (!isCharging || pluggedInt == 0) return "Tidak mengisi"
        if (currentMa <= 0 || voltageMv <= 0) return "Data tidak cukup"

        return when {
            voltageMv >= 9_000 && powerMw >= 15_000 ->
                "Pengisian tegangan tinggi (perkiraan)"
            voltageMv >= 8_000 && isFast ->
                "Mode tegangan tinggi (perkiraan)"
            powerMw >= 15_000 ->
                "Pengisian daya tinggi (perkiraan)"
            isFast ->
                "Pengisian cepat (perkiraan)"
            pluggedInt == BatteryManager.BATTERY_PLUGGED_USB ->
                "USB (protokol tidak diketahui)"
            pluggedInt == BatteryManager.BATTERY_PLUGGED_AC ->
                "Adaptor AC (protokol tidak diketahui)"
            pluggedInt == BatteryManager.BATTERY_PLUGGED_WIRELESS ->
                "Nirkabel (protokol tidak diketahui)"
            else -> "Protokol tidak diketahui"
        }
    }

    private fun detectConnectorType(pluggedInt: Int): String = when (pluggedInt) {
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_AC -> "AC / adaptor"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Nirkabel"
        0 -> "Tidak terhubung"
        else -> "Lainnya"
    }

    private fun detectChargerType(
        pluggedInt: Int,
        isFast: Boolean,
        protocol: String
    ): String {
        if (pluggedInt == 0) return "Tidak terhubung"
        if (protocol == "Data tidak cukup") return "Terhubung (data terbatas)"
        if (isFast) return "Pengisian cepat (perkiraan)"
        return when (pluggedInt) {
            BatteryManager.BATTERY_PLUGGED_USB -> "USB standar / tidak teridentifikasi"
            BatteryManager.BATTERY_PLUGGED_AC -> "Adaptor / kecepatan tidak teridentifikasi"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Pengisian nirkabel"
            else -> "Charger tidak teridentifikasi"
        }
    }

    private fun diagnose(
        s: BatterySnapshot,
        currentSource: String
    ): List<DiagnosisItem> {
        val result = mutableListOf<DiagnosisItem>()

        result += when {
            s.level >= 80 -> DiagnosisItem(
                "Baterai", "Level baterai", DiagnosisItem.Status.GOOD,
                "Baterai ${s.level}%.",
                "Jika ingin menjaga umur baterai, hindari membiarkan perangkat terlalu panas."
            )
            s.level <= 15 -> DiagnosisItem(
                "Baterai", "Level baterai rendah", DiagnosisItem.Status.WARNING,
                "Baterai tersisa ${s.level}%.",
                "Sambungkan charger jika diperlukan dan kurangi beban berat."
            )
            else -> DiagnosisItem(
                "Baterai", "Level baterai", DiagnosisItem.Status.INFO,
                "Baterai ${s.level}%.",
                "Pantau perubahan level dan suhu selama digunakan."
            )
        }

        result += when {
            s.temperatureC <= 0f -> DiagnosisItem(
                "Suhu", "Data suhu tidak tersedia", DiagnosisItem.Status.INFO,
                "Android tidak melaporkan suhu baterai yang valid pada pembacaan ini.",
                "Periksa kembali data perangkat; nilai 0°C tidak dianggap bukti suhu normal."
            )
            s.temperatureC >= 45f -> DiagnosisItem(
                "Suhu", "Baterai panas", DiagnosisItem.Status.BAD,
                "Suhu baterai ${"%.1f".format(java.util.Locale.US, s.temperatureC)}°C.",
                "Hentikan game/aplikasi berat, jauhkan dari panas, dan cabut charger bila suhu terus meningkat."
            )
            s.temperatureC >= 40f -> DiagnosisItem(
                "Suhu", "Suhu cukup tinggi", DiagnosisItem.Status.WARNING,
                "Suhu baterai ${"%.1f".format(java.util.Locale.US, s.temperatureC)}°C.",
                "Kurangi beban dan pantau suhu. Jangan menutup ventilasi perangkat."
            )
            else -> DiagnosisItem(
                "Suhu", "Suhu baterai", DiagnosisItem.Status.GOOD,
                "Suhu terlapor ${"%.1f".format(java.util.Locale.US, s.temperatureC)}°C.",
                "Pertahankan perangkat di tempat sejuk."
            )
        }

        result += when (s.health) {
            "GOOD" -> DiagnosisItem(
                "Kesehatan", "Status kesehatan baterai", DiagnosisItem.Status.GOOD,
                "Android melaporkan status kesehatan GOOD.",
                "Status ini bukan persentase kapasitas baterai tersisa."
            )
            "OVERHEAT", "DEAD", "OVER_VOLTAGE", "FAILURE" -> DiagnosisItem(
                "Kesehatan", "Status kesehatan perlu diperiksa", DiagnosisItem.Status.BAD,
                "Android melaporkan: ${s.health}.",
                "Lepas charger jika aman dilakukan dan periksa perangkat/servis jika status menetap."
            )
            "UNKNOWN" -> DiagnosisItem(
                "Kesehatan", "Kesehatan tidak diketahui", DiagnosisItem.Status.INFO,
                "Android tidak memberikan status kesehatan yang dapat dipastikan.",
                "Periksa kembali nanti; tidak semua perangkat menyediakan data ini."
            )
            else -> DiagnosisItem(
                "Kesehatan", "Status kesehatan", DiagnosisItem.Status.INFO,
                "Status Android: ${s.health}.",
                "Gunakan pemantauan suhu, perilaku baterai, dan pemeriksaan perangkat sebagai tambahan."
            )
        }

        result += when {
            s.plugged == "Tidak terhubung" -> DiagnosisItem(
                "Pengisian", "Charger tidak terhubung", DiagnosisItem.Status.INFO,
                "Perangkat tidak melaporkan sumber daya eksternal.",
                "Sambungkan charger untuk memantau arus dan daya pengisian."
            )
            !s.isCharging && s.level < 100 -> DiagnosisItem(
                "Pengisian", "Belum mengisi", DiagnosisItem.Status.WARNING,
                "Sumber daya terdeteksi, tetapi status baterai bukan CHARGING.",
                "Periksa kabel, adaptor, port, suhu, dan apakah pengisian dijeda oleh sistem."
            )
            s.currentMa == 0 && s.isCharging -> DiagnosisItem(
                "Pengisian", "Arus belum terbaca", DiagnosisItem.Status.INFO,
                "Sensor arus tidak memberi nilai yang dapat dipakai. Sumber terakhir: $currentSource.",
                "Sebagian perangkat membatasi data arus; ini sendiri tidak membuktikan charger atau kabel rusak."
            )
            s.isFastCharging -> DiagnosisItem(
                "Pengisian", "Pengisian cepat terindikasi", DiagnosisItem.Status.INFO,
                "Estimasi daya sisi baterai ${s.powerMw / 1000f} W; ini bukan pengukuran daya input adaptor.",
                "Indikasi cepat dihitung dari sensor yang tersedia, bukan konfirmasi resmi protokol USB-PD/QC."
            )
            else -> DiagnosisItem(
                "Pengisian", "Pengisian terdeteksi", DiagnosisItem.Status.INFO,
                "Arus sisi baterai ${s.currentMa} mA dan estimasi daya ${s.powerMw / 1000f} W.",
                "Kecepatan dapat berubah karena level baterai, suhu, layar, dan kebijakan pengisian perangkat."
            )
        }

        if (s.batteryCapacityMah > 0) {
            result += DiagnosisItem(
                "Kapasitas", "Kapasitas baterai terlapor",
                DiagnosisItem.Status.INFO,
                "Nilai kapasitas yang terbaca: ${s.batteryCapacityMah} mAh.",
                "Nilai dari sysfs dapat berupa kapasitas desain atau nilai vendor, bukan selalu kapasitas aktual."
            )
        } else {
            result += DiagnosisItem(
                "Kapasitas", "Kapasitas tidak tersedia",
                DiagnosisItem.Status.INFO,
                "Perangkat tidak menyediakan kapasitas melalui lokasi sysfs yang dapat dibaca.",
                "Ini batas akses perangkat, bukan bukti baterai bermasalah."
            )
        }

        if (s.cycleCount >= 0) {
            result += DiagnosisItem(
                "Siklus", "Jumlah siklus terlapor",
                DiagnosisItem.Status.INFO,
                if (s.cycleCount == 0) "Siklus tidak dilaporkan atau bernilai 0." else "Siklus terlapor: ${s.cycleCount}.",
                "Tidak semua perangkat Android menyediakan penghitung siklus yang dapat diakses aplikasi."
            )
        }

        return result
    }

    private fun readBatteryCapacityMah(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/battery/charge_full",
            "/sys/class/power_supply/bms/charge_full_design",
            "/sys/class/power_supply/bms/charge_full"
        )

        for (path in paths) {
            val raw = readLongFile(path) ?: continue
            if (raw <= 0L) continue
            // Mayoritas kernel Android melaporkan µAh; validasi rentang untuk menghindari nilai liar.
            val mah = if (raw > 100_000L) raw / 1000L else raw
            if (mah in 500L..20_000L) return mah.toInt()
        }
        return 0 // 0 = tidak tersedia/tidak terbaca.
    }

    private fun readCycleCount(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/cycle_count",
            "/sys/class/power_supply/bms/cycle_count",
            "/sys/class/power_supply/Battery/cycle_count"
        )
        for (path in paths) {
            val raw = readLongFile(path) ?: continue
            if (raw in 0L..100_000L) return raw.toInt()
        }
        return -1 // -1 = tidak tersedia.
    }

    private fun readLongFile(path: String): Long? {
        return try {
            val file = File(path)
            if (!file.isFile || !file.canRead()) null
            else file.readText().trim().toLongOrNull()
        } catch (_: Exception) {
            null
        }
    }

    private fun statusToString(status: Int): String = when (status) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "CHARGING"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "DISCHARGING"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "NOT_CHARGING"
        BatteryManager.BATTERY_STATUS_FULL -> "FULL"
        else -> "UNKNOWN"
    }

    private fun pluggedToString(plugged: Int): String = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "WIRELESS"
        0 -> "Tidak terhubung"
        else -> "Lainnya"
    }

    private fun healthToString(health: Int): String = when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "GOOD"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "OVERHEAT"
        BatteryManager.BATTERY_HEALTH_DEAD -> "DEAD"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "OVER_VOLTAGE"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "FAILURE"
        BatteryManager.BATTERY_HEALTH_COLD -> "COLD"
        else -> "UNKNOWN"
    }

    private fun emptySnapshot() = BatterySnapshot(
        timestamp = System.currentTimeMillis(),
        level = 0,
        voltageMv = 0,
        currentMa = 0,
        powerMw = 0,
        temperatureC = 0f,
        health = "UNKNOWN",
        status = "UNKNOWN",
        plugged = "Tidak terhubung",
        isCharging = false,
        isFastCharging = false,
        chargingProtocol = "Tidak diketahui",
        connectorType = "Tidak terhubung",
        chargerType = "Tidak terhubung",
        etaMinutes = -1,
        chargeSpeedPctPerMin = 0f,
        batteryCapacityMah = 0,
        cycleCount = -1
    )

    companion object {
        private const val TAG = "BatteryRepository"
        private const val MAX_CURRENT_UA = 20_000_000L
        private const val MAX_CURRENT_MA = 20_000
        private const val MIN_VALID_CHARGE_SPEED = 0.05f

        @Volatile
        private var INSTANCE: BatteryRepository? = null

        fun getInstance(context: Context): BatteryRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BatteryRepository(context.applicationContext).also {
                    INSTANCE = it
                }
            }
        }
    }
}
