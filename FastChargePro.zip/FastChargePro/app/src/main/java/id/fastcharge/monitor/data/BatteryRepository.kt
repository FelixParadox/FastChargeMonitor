package id.fastcharge.monitor.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class BatterySnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val level: Int = 0,                    // %
    val voltageMv: Int = 0,                // mV
    val currentMa: Int = 0,                // mA (positive = charging)
    val powerMw: Int = 0,                  // mW
    val temperatureC: Float = 0f,
    val health: String = "Unknown",
    val status: String = "Unknown",
    val plugged: String = "Unplugged",
    val isCharging: Boolean = false,
    val isFastCharging: Boolean = false,
    val chargingProtocol: String = "None",
    val connectorType: String = "Unknown",
    val chargerType: String = "Unknown",
    val etaMinutes: Int = -1,
    val chargeSpeedPctPerMin: Float = 0f
)

data class DiagnosisItem(
    val category: String,
    val title: String,
    val status: Status,
    val detail: String,
    val recommendation: String = ""
) {
    enum class Status { NORMAL, INFO, WARNING, CRITICAL, UNKNOWN }
}

class BatteryRepository private constructor(private val context: Context) {

    private val _snapshot = MutableStateFlow(BatterySnapshot())
    val snapshot: StateFlow<BatterySnapshot> = _snapshot

    private val _history = MutableStateFlow<List<BatterySnapshot>>(emptyList())
    val history: StateFlow<List<BatterySnapshot>> = _history

    private val _diagnosis = MutableStateFlow<List<DiagnosisItem>>(emptyList())
    val diagnosis: StateFlow<List<DiagnosisItem>> = _diagnosis

    private val handler = Handler(Looper.getMainLooper())
    private val historyBuffer = ArrayDeque<BatterySnapshot>()
    private val maxHistoryAgeMs = 60 * 60 * 1000L  // 1 jam
    private val maxHistoryPoints = 7200            // 1 jam @ 2Hz safety cap

    // Untuk kalkulasi ETA & kecepatan
    private var lastLevel: Int = -1
    private var lastLevelTime: Long = 0
    private var smoothedSpeed = 0f

    private val batteryManager: BatteryManager? =
        context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    private val stickyIntent: Intent? = context.registerReceiver(
        null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
    )

    private val ticker = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 500L)  // 500ms = 2Hz real-time
        }
    }

    fun start() {
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    fun stop() {
        handler.removeCallbacks(ticker)
    }

    private fun poll() {
        val intent = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: stickyIntent ?: return

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (scale > 0) level * 100 / scale else level

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val tempTenth = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val tempC = tempTenth / 10f

        val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pluggedInt = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown"

        val isCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING ||
                statusInt == BatteryManager.BATTERY_STATUS_FULL

        // Current via BatteryManager (µA) → mA
        var currentMa = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && batteryManager != null) {
            val uA = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            currentMa = when {
                uA == Int.MIN_VALUE -> 0
                abs(uA) > 100_000 -> uA / 1000  // µA → mA
                else -> uA
            }
        }
        // Android convention: negative saat charging, positif saat discharge. Kita normalisasi:
        if (isCharging && currentMa < 0) currentMa = -currentMa
        if (!isCharging && currentMa < 0) currentMa = abs(currentMa)

        // Power mW
        val powerMw = if (voltageMv > 0 && currentMa != 0) {
            (voltageMv.toLong() * abs(currentMa) / 1000L).toInt()
        } else 0

        // Deteksi fast charging (heuristik dari power & voltase & teknologi)
        val isFast = isCharging && (
                powerMw >= 10_000 ||
                voltageMv >= 4_400 && abs(currentMa) >= 2_000 ||
                voltageMv >= 9_000
        )

        val protocol = detectProtocol(voltageMv, currentMa, isFast, pluggedInt)
        val connector = detectConnector(pluggedInt)
        val chargerType = detectChargerType(powerMw, voltageMv, isFast)

        // ETA & charge speed
        updateChargeSpeed(pct, isCharging)
        val eta = computeEta(pct, isCharging, 100)

        val snap = BatterySnapshot(
            timestamp = System.currentTimeMillis(),
            level = pct,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerMw = powerMw,
            temperatureC = tempC,
            health = healthToString(healthInt),
            status = statusToString(statusInt),
            plugged = pluggedToString(pluggedInt),
            isCharging = isCharging,
            isFastCharging = isFast,
            chargingProtocol = protocol,
            connectorType = connector,
            chargerType = chargerType,
            etaMinutes = eta,
            chargeSpeedPctPerMin = smoothedSpeed
        )

        _snapshot.value = snap
        appendHistory(snap)
        _diagnosis.value = diagnose(snap)
    }

    private fun updateChargeSpeed(level: Int, charging: Boolean) {
        val now = System.currentTimeMillis()
        if (lastLevelTime > 0 && charging && lastLevel >= 0 && level >= lastLevel) {
            val dtMin = (now - lastLevelTime) / 60_000f
            if (dtMin > 0.05f) {
                val raw = (level - lastLevel) / dtMin
                smoothedSpeed = smoothedSpeed * 0.6f + raw * 0.4f
            }
        }
        if (lastLevel != level) {
            lastLevel = level
            lastLevelTime = now
        }
    }

    private fun computeEta(level: Int, charging: Boolean, target: Int): Int {
        if (!charging) return -1
        val remaining = target - level
        if (remaining <= 0) return 0
        val speed = smoothedSpeed
        if (speed < 0.05f) {
            // Fallback: 1% per 2 menit default
            return remaining * 2
        }
        return (remaining / speed).toInt().coerceIn(1, 600)
    }

    private fun appendHistory(snap: BatterySnapshot) {
        historyBuffer.addLast(snap)
        val cutoff = System.currentTimeMillis() - maxHistoryAgeMs
        while (historyBuffer.isNotEmpty() && historyBuffer.first().timestamp < cutoff) {
            historyBuffer.removeFirst()
        }
        while (historyBuffer.size > maxHistoryPoints) historyBuffer.removeFirst()
        _history.value = historyBuffer.toList()
    }

    private fun detectProtocol(vMv: Int, iMa: Int, fast: Boolean, plugged: Int): String {
        if (plugged == 0) return "None"
        val p = vMv.toLong() * abs(iMa) / 1000L
        return when {
            vMv >= 9_000 && p >= 27_000 -> "USB-PD 27W+ (PD 3.0)"
            vMv >= 9_000 && p >= 18_000 -> "USB-PD 18W (PD 2.0)"
            vMv >= 9_000 -> "USB-PD"
            vMv in 6_500..7_500 && p >= 15_000 -> "QC 3.0 / VOOC"
            vMv in 4_400..5_500 && iMa >= 3_000 -> "QC 2.0 / Fast Charge"
            fast -> "Fast Charge (Vendor)"
            iMa >= 1_500 -> "Standard 5V/1.5A+"
            else -> "Standard Charging"
        }
    }

    private fun detectConnector(plugged: Int): String = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB Port (PC)"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Charger"
        else -> "Unknown"
    }

    private fun detectChargerType(pMw: Int, vMv: Int, fast: Boolean): String = when {
        !fast && pMw == 0 -> "Not Connected"
        pMw >= 40_000 -> "Super Fast Charger (40W+)"
        pMw >= 18_000 -> "Fast Charger (18W+)"
        pMw >= 10_000 -> "Quick Charger (10W+)"
        pMw > 0 -> "Standard Charger"
        else -> "Unknown"
    }

    private fun diagnose(s: BatterySnapshot): List<DiagnosisItem> {
        val list = mutableListOf<DiagnosisItem>()

        // 1. Baterai (sel)
        val battStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.health == "Overheat" || s.health == "Dead" -> DiagnosisItem.Status.CRITICAL
            s.health == "Cold" -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Baterai (Sel)",
            title = "Baterai ${s.level}%",
            status = battStatus,
            detail = buildString {
                append("Suhu ${"%.1f".format(s.temperatureC)}°C • ")
                append("Health: ${s.health} • ")
                append("Teknologi sel OK")
            },
            recommendation = when (battStatus) {
                DiagnosisItem.Status.CRITICAL -> "Baterai terlalu panas, cabut charger!"
                DiagnosisItem.Status.WARNING -> "Suhu tinggi, hindari penggunaan berat"
                else -> ""
            }
        )

        // 2. IC Pengisian
        val icStatus = when {
            s.isCharging && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.powerMw > 0 -> DiagnosisItem.Status.NORMAL
            !s.isCharging && s.powerMw > 0 -> DiagnosisItem.Status.INFO
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "IC Pengisian",
            title = if (s.isCharging) "Charging Aktif" else "Idle",
            status = icStatus,
            detail = "Daya masuk ${s.powerMw} mW • ${if (s.isCharging) "menerima arus" else "tidak mengisi"}"
        )

        // 3. Kabel & Port USB
        val cableStatus = when {
            s.isCharging && s.voltageMv < 4_000 -> DiagnosisItem.Status.CRITICAL
            s.isCharging && s.powerMw < 2_000 && s.chargerType.contains("Fast") -> DiagnosisItem.Status.WARNING
            s.isCharging && s.currentMa > 0 -> DiagnosisItem.Status.NORMAL
            !s.isCharging && s.plugged != "Unplugged" -> DiagnosisItem.Status.INFO
            else -> DiagnosisItem.Status.UNKNOWN
        }
        list += DiagnosisItem(
            category = "Kabel & Port USB",
            title = s.connectorType,
            status = cableStatus,
            detail = "Tegangan ${s.voltageMv} mV • Arus ${s.currentMa} mA"
        )

        // 4. Charger / Adaptor
        val chargerStatus = when {
            !s.isCharging && s.plugged == "Unplugged" -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.powerMw < 3_000 -> DiagnosisItem.Status.WARNING
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            s.isCharging -> DiagnosisItem.Status.INFO
            else -> DiagnosisItem.Status.UNKNOWN
        }
        list += DiagnosisItem(
            category = "Charger / Adaptor",
            title = s.chargerType,
            status = chargerStatus,
            detail = "Protokol: ${s.chargingProtocol} • Daya ${s.powerMw} mW"
        )

        // 5. Suhu Thermal
        val thermalStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.temperatureC <= 5f -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Suhu Thermal",
            title = "${"%.1f".format(s.temperatureC)}°C",
            status = thermalStatus,
            detail = when {
                thermalStatus == DiagnosisItem.Status.CRITICAL -> "Overheat! Risiko kerusakan baterai"
                thermalStatus == DiagnosisItem.Status.WARNING -> "Suhu tidak ideal"
                else -> "Suhu normal"
            }
        )

        // 6. Fast Charging
        val fastStatus = when {
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            s.isCharging && s.powerMw > 5_000 -> DiagnosisItem.Status.INFO
            s.isCharging -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.UNKNOWN
        }
        list += DiagnosisItem(
            category = "Fast Charging",
            title = if (s.isFastCharging) "AKTIF" else if (s.isCharging) "Tidak aktif" else "—",
            status = fastStatus,
            detail = if (s.isFastCharging)
                "${s.chargingProtocol} • ${s.powerMw} mW"
            else
                "Daya ${s.powerMw} mW, tidak memenuhi kriteria fast charge"
        )

        // 7. Tegangan & Arus
        val viStatus = when {
            s.isCharging && abs(s.currentMa) > 6_000 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.voltageMv in 4_000..10_000 && abs(s.currentMa) in 100..6_000 -> DiagnosisItem.Status.NORMAL
            !s.isCharging -> DiagnosisItem.Status.UNKNOWN
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Tegangan & Arus",
            title = "${s.voltageMv} mV / ${s.currentMa} mA",
            status = viStatus,
            detail = "Daya ${s.powerMw} mW • ${if (s.isCharging) "stabil" else "idle"}"
        )

        return list
    }

    private fun statusToString(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
        else -> "Unknown"
    }

    private fun pluggedToString(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Unplugged"
    }

    private fun healthToString(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }

    companion object {
        @Volatile private var INSTANCE: BatteryRepository? = null
        fun get(context: Context): BatteryRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: BatteryRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}