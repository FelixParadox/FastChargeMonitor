package id.fastcharge.monitor.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

data class BatterySnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val level: Int = 0,
    val voltageMv: Int = 0,
    val currentMa: Int = 0,
    val powerMw: Int = 0,
    val temperatureC: Float = 0f,
    val health: String = "Unknown",
    val status: String = "Unknown",
    val plugged: String = "Unplugged",
    val isCharging: Boolean = false,
    val isFastCharging: Boolean = false,
    val chargingProtocol: String = "None",
    val connectorType: String = "Unknown",
    val chargerType: String = "Unknown",
    val etaMinutes: Int = -1,
    val chargeSpeedPctPerMin: Float = 0f,
    val batteryCapacityMah: Int = 0,
    val cycleCount: Int = 0
)

data class DiagnosisItem(
    val category: String,
    val title: String,
    val status: Status,
    val detail: String,
    val recommendation: String = ""
) {
    enum class Status { NORMAL, INFO, WARNING, CRITICAL, UNKNOWN }
}

class BatteryRepository private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    private val _snapshot = MutableStateFlow(BatterySnapshot())
    val snapshot: StateFlow<BatterySnapshot> = _snapshot.asStateFlow()

    private val _history = MutableStateFlow<List<BatterySnapshot>>(emptyList())
    val history: StateFlow<List<BatterySnapshot>> = _history.asStateFlow()

    private val _diagnosis = MutableStateFlow<List<DiagnosisItem>>(emptyList())
    val diagnosis: StateFlow<List<DiagnosisItem>> = _diagnosis.asStateFlow()

    private val historyBuffer = ArrayDeque<BatterySnapshot>()
    private val historyLock = Any()
    private val maxHistoryAgeMs = 60 * 60 * 1000L
    private val maxHistoryPoints = 7_200
    private val pollIntervalMs = 500L

    private val batteryManager: BatteryManager? =
        appContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    @Volatile
    private var running = false
    private var receiverRegistered = false

    // Speed & ETA state (fix: monotonic clock)
    private var lastLevel = -1
    private var lastLevelElapsedMs = 0L
    private var smoothedSpeed = 0f

    // Anti-flicker arus
    private var lastKnownCurrentMa = 0
    private var consecutiveZeroCurrentCount = 0
    private var lastPluggedState = 0

    // Batas kewajaran sensor
    private val maxCurrentMa = 20_000
    private val maxCurrentUa = 20_000_000L
    private val maxPowerMw = 120_000

    // ============================================================
    // BROADCAST RECEIVER
    // ============================================================
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (running) pollSafely()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                pollSafely()
            } catch (e: Exception) {
                Log.e(TAG, "Ticker error", e)
            } finally {
                if (running) handler.postDelayed(this, pollIntervalMs)
            }
        }
    }

    @Synchronized
    fun start() {
        if (running) return
        running = true

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(Intent.ACTION_BATTERY_LOW)
                addAction(Intent.ACTION_BATTERY_OKAY)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                appContext.registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                appContext.registerReceiver(batteryReceiver, filter)
            }
            receiverRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "Gagal register receiver: ${e.message}")
            receiverRegistered = false
        }

        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    @Synchronized
    fun stop() {
        running = false
        handler.removeCallbacks(ticker)
        if (receiverRegistered) {
            try {
                appContext.unregisterReceiver(batteryReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "Unregister error: ${e.message}")
            } finally {
                receiverRegistered = false
            }
        }
    }

    private fun pollSafely() {
        try {
            poll()
        } catch (e: Exception) {
            Log.e(TAG, "Poll error", e)
        }
    }

@Suppress("DEPRECATION")
private fun poll() {
    val intent = try {
        appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    } catch (e: Exception) {
        Log.w(TAG, "Sticky broadcast error: ${e.message}")
        null
    } ?: return

    val levelRaw = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val pct = if (levelRaw >= 0) {
        ((levelRaw * 100f) / scale).roundToInt().coerceIn(0, 100)
    } else _snapshot.value.level

    val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0).coerceAtLeast(0)
    val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
    val tempC = if (tempRaw != Int.MIN_VALUE) tempRaw / 10f else 0f

    val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val pluggedInt = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
    val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)

    val isCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING
    val isChargingOrFull = isCharging || statusInt == BatteryManager.BATTERY_STATUS_FULL
    val isPlugged = pluggedInt != 0

    // === PERBAIKAN BUG: JIKA TIDAK DICOLOK, PAKSA ARUS & DAYA 0 ===
    val currentReading = if (isPlugged) {
        readCurrentMa(intent, true)
    } else {
        CurrentReading(0, "Disconnected", 0L)
    }
    val currentMa = currentReading.milliamps
    updateCurrentCache(currentMa, isPlugged)

    // === DAYA ===
    // Daya hanya dihitung jika terhubung ke charger
    val powerMw: Int = if (!isPlugged || voltageMv <= 0 || currentMa <= 0) 0
    else (voltageMv.toLong() * currentMa.toLong() / 1000L)
        .coerceIn(0L, maxPowerMw.toLong()).toInt()

    // Reset state saat cabut charger
    if (!isPlugged && lastPluggedState != 0) {
        lastLevel = -1
        lastLevelElapsedMs = 0L
        smoothedSpeed = 0f
        consecutiveZeroCurrentCount = 0
        lastKnownCurrentMa = 0
    }
    lastPluggedState = pluggedInt

    // === FAST CHARGING ===
    val isFast = isPlugged && isCharging && pct < 100 && (
        powerMw >= 10_000 ||
        voltageMv >= 9_000 ||
        (voltageMv >= 5_000 && currentMa >= 2_000) ||
        (voltageMv >= 4_400 && currentMa >= 3_000)
    )

    val protocol = if (isPlugged) detectProtocol(voltageMv, currentMa, isFast, pluggedInt) else "None"
    val connector = detectConnector(pluggedInt)
    val chargerType = if (isPlugged) detectChargerType(powerMw, isFast, true, protocol) else "Not Connected"

    updateChargeSpeed(pct, isCharging, isPlugged)
    val eta = computeEta(pct, isCharging)

    val capacity = readBatteryCapacity()
    val cycles = readCycleCount()

    val snap = BatterySnapshot(
        timestamp = System.currentTimeMillis(),
        level = pct,
        voltageMv = voltageMv, // Tegangan baterai internal tetap ditampilkan (normal)
        currentMa = currentMa,
        powerMw = powerMw,
        temperatureC = tempC,
        health = healthToString(healthInt),
        status = if (isPlugged && !isCharging) "Connected (Not Charging)" else statusToString(statusInt),
        plugged = pluggedToString(pluggedInt),
        isCharging = isChargingOrFull,
        isFastCharging = isFast,
        chargingProtocol = protocol,
        connectorType = connector,
        chargerType = chargerType,
        etaMinutes = eta,
        chargeSpeedPctPerMin = smoothedSpeed,
        batteryCapacityMah = capacity,
        cycleCount = cycles
    )

    _snapshot.value = snap
    appendHistory(snap)
    _diagnosis.value = diagnose(snap, isPlugged, currentReading.source)
}

    // ============================================================
    // ARUS: Multi-strategi + Anti-Flicker
    // Prioritas:
    // 1. BatteryManager CURRENT_NOW
    // 2. Sysfs current_now
    // 3. BatteryManager CURRENT_AVERAGE
    // 4. Sysfs current_avg
    // ============================================================
    private data class CurrentReading(
        val milliamps: Int,
        val source: String,
        val rawMicroamps: Long
    )
private fun readCurrentMa(intent: Intent, chargingOrPlugged: Boolean): CurrentReading {
    // Jika tidak dicharge, langsung kembalikan 0
    if (!chargingOrPlugged) {
        return CurrentReading(0, "Disconnected", 0L)
    }

    data class Candidate(val microAmps: Long, val source: String)

    val candidates = mutableListOf<Candidate>()
    val zeroCandidates = mutableListOf<Candidate>()

    fun addCandidate(raw: Long, source: String) {
        if (raw == Long.MIN_VALUE || raw == Int.MIN_VALUE.toLong()) return
        if (abs(raw) > maxCurrentUa) return
        val c = Candidate(raw, source)
        if (raw == 0L) zeroCandidates.add(c) else candidates.add(c)
    }

    // 1. BatteryManager CURRENT_NOW
    try {
        batteryManager?.let {
            val raw = it.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            addCandidate(raw, "BatteryManager.CURRENT_NOW")
        }
    } catch (_: Exception) {}

    // 2. Sysfs current_now
    val nowPaths = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/bms/current_now",
        "/sys/class/power_supply/Battery/current_now"
    )
    for (path in nowPaths) {
        readLongFile(path)?.let { addCandidate(it, path) }
    }

    // 3. BatteryManager CURRENT_AVERAGE
    try {
        batteryManager?.let {
            val raw = it.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE)
            addCandidate(raw, "BatteryManager.CURRENT_AVERAGE")
        }
    } catch (_: Exception) {}

    // 4. Sysfs current_avg
    val avgPaths = listOf(
        "/sys/class/power_supply/battery/current_avg",
        "/sys/class/power_supply/bms/current_avg",
        "/sys/class/power_supply/Battery/current_avg"
    )
    for (path in avgPaths) {
        readLongFile(path)?.let { addCandidate(it, path) }
    }

    val selected = candidates.firstOrNull()
    if (selected != null) {
        val ma = (abs(selected.microAmps) / 1000L).coerceAtMost(maxCurrentMa.toLong()).toInt()
        return CurrentReading(ma, selected.source, selected.microAmps)
    }

    if (zeroCandidates.isNotEmpty()) {
        return CurrentReading(0, zeroCandidates.first().source, 0L)
    }

    return CurrentReading(0, "Tidak tersedia", 0L)
}

    private fun updateCurrentCache(currentMa: Int, plugged: Boolean) {
        if (!plugged) {
            lastKnownCurrentMa = 0
            consecutiveZeroCurrentCount = 0
            return
        }
        if (currentMa > 0) {
            lastKnownCurrentMa = currentMa
            consecutiveZeroCurrentCount = 0
        } else {
            consecutiveZeroCurrentCount++
        }
    }

    // ============================================================
    // KAPASITAS & CYCLE
    // ============================================================
    private fun readBatteryCapacity(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/battery/charge_full",
            "/sys/class/power_supply/bms/charge_full_design",
            "/sys/class/power_supply/bms/charge_full"
        )
        for (p in paths) {
            val raw = readLongFile(p) ?: continue
            if (raw <= 0L) continue
            val mah = if (raw > 100_000L) raw / 1000L else raw
            if (mah in 500L..20_000L) return mah.toInt()
        }
        return 0
    }

    private fun readCycleCount(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/cycle_count",
            "/sys/class/power_supply/bms/cycle_count",
            "/sys/class/power_supply/Battery/cycle_count"
        )
        for (p in paths) {
            val raw = readLongFile(p) ?: continue
            if (raw in 0L..100_000L) return raw.toInt()
        }
        return 0
    }

    private fun readLongFile(path: String): Long? = try {
        val f = File(path)
        if (!f.isFile || !f.canRead()) null
        else f.readText().trim().toLongOrNull()
    } catch (_: Exception) {
        null
    }

    // ============================================================
    // SPEED & ETA (Fix: monotonic clock)
    // ============================================================
    private fun updateChargeSpeed(level: Int, charging: Boolean, plugged: Boolean) {
        val now = SystemClock.elapsedRealtime()

        if (!charging || !plugged) {
            lastLevel = level
            lastLevelElapsedMs = now
            smoothedSpeed = 0f
            return
        }

        if (lastLevelElapsedMs == 0L || lastLevel < 0) {
            lastLevel = level
            lastLevelElapsedMs = now
            return
        }

        if (level > lastLevel) {
            val dtMs = now - lastLevelElapsedMs
            if (dtMs > 3_000L) { // minimal 3 detik agar stabil
                val dtMin = dtMs / 60_000f
                val raw = (level - lastLevel) / dtMin
                smoothedSpeed = smoothedSpeed * 0.6f + raw * 0.4f
                lastLevel = level
                lastLevelElapsedMs = now
            }
        } else if (level != lastLevel) {
            lastLevel = level
            lastLevelElapsedMs = now
        }
    }

    private fun computeEta(level: Int, charging: Boolean): Int {
        if (!charging || level >= 100) return -1
        val remaining = 100 - level
        val speed = smoothedSpeed
        if (speed < 0.05f) return remaining * 2 // fallback: 2 menit/1%
        return (remaining / speed).roundToInt().coerceIn(1, 600)
    }

    // ============================================================
    // HISTORY
    // ============================================================
    private fun appendHistory(snap: BatterySnapshot) {
        synchronized(historyLock) {
            historyBuffer.addLast(snap)
            val cutoff = System.currentTimeMillis() - maxHistoryAgeMs
            while (historyBuffer.isNotEmpty() && historyBuffer.first().timestamp < cutoff) {
                historyBuffer.removeFirst()
            }
            while (historyBuffer.size > maxHistoryPoints) historyBuffer.removeFirst()
            _history.value = historyBuffer.toList()
        }
    }

    // ============================================================
    // DETEKSI PROTOKOL / CONNECTOR / CHARGER
    // ============================================================
    private fun detectProtocol(vMv: Int, iMa: Int, fast: Boolean, plugged: Int): String {
        if (plugged == 0) return "None"
        val p = vMv.toLong() * iMa / 1000L
        return when {
            vMv >= 9_000 && p >= 27_000 -> "USB-PD 27W+"
            vMv >= 9_000 && p >= 18_000 -> "USB-PD 18W"
            vMv >= 9_000 -> "USB-PD"
            vMv in 6_500..7_500 && p >= 15_000 -> "QC 3.0 / VOOC"
            vMv in 4_400..5_500 && iMa >= 3_000 -> "QC 2.0 / Fast"
            fast -> "Fast Charge (Vendor)"
            iMa >= 1_500 -> "Standard 5V/1.5A+"
            iMa >= 500 -> "Standard Charging"
            else -> "Trickle Charging"
        }
    }

    private fun detectConnector(plugged: Int): String = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB Port (PC)"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Charger"
        else -> "Disconnected"
    }

    private fun detectChargerType(pMw: Int, fast: Boolean, plugged: Boolean, protocol: String): String = when {
        !plugged -> "Not Connected"
        protocol == "Data tidak cukup" -> "Connected (data terbatas)"
        pMw >= 65_000 -> "Super Fast (65W+)"
        pMw >= 40_000 -> "Super Fast (40W+)"
        pMw >= 25_000 -> "Fast Charger (25W+)"
        pMw >= 18_000 -> "Fast Charger (18W+)"
        pMw >= 10_000 -> "Quick Charger (10W+)"
        pMw >= 5_000 -> "Standard Charger"
        pMw > 0 -> "Charger (weak)"
        plugged -> "Charger (detecting…)"
        else -> "Unknown"
    }

    // ============================================================
    // DIAGNOSA (7 Kategori)
    // ============================================================
    private fun diagnose(s: BatterySnapshot, isPlugged: Boolean, currentSource: String): List<DiagnosisItem> {
        val list = mutableListOf<DiagnosisItem>()

        // 1. Baterai (Sel)
        val battStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.health.equals("Overheat", true) || s.health.equals("Dead", true) -> DiagnosisItem.Status.CRITICAL
            s.health.equals("Cold", true) -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Baterai (Sel)",
            title = "Level ${s.level}% • ${s.health}",
            status = battStatus,
            detail = buildString {
                append("Suhu ${"%.1f".format(s.temperatureC)}°C")
                if (s.batteryCapacityMah > 0) append(" • Kapasitas ${s.batteryCapacityMah} mAh")
                if (s.cycleCount > 0) append(" • ${s.cycleCount} siklus")
            },
            recommendation = when (battStatus) {
                DiagnosisItem.Status.CRITICAL -> "Baterai terlalu panas, cabut charger!"
                DiagnosisItem.Status.WARNING -> "Suhu tinggi, hindari penggunaan berat"
                else -> ""
            }
        )

        // 2. IC Pengisian
        val icStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.powerMw > 0 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "IC Pengisian",
            title = when {
                !isPlugged -> "Idle"
                s.isCharging && s.currentMa == 0 -> "Terdeteksi anomali"
                s.isCharging -> "Charging Aktif"
                else -> "Connected"
            },
            status = icStatus,
            detail = "Daya masuk ${s.powerMw} mW • ${if (s.isCharging) "menerima arus" else "menunggu"} • Source: $currentSource",
            recommendation = if (icStatus == DiagnosisItem.Status.WARNING)
                "Coba cabut-pasang charger, cek kabel" else ""
        )

        // 3. Kabel & Port
        val cableStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.voltageMv < 4_000 -> DiagnosisItem.Status.CRITICAL
            s.isCharging && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.currentMa > 0 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Kabel & Port USB",
            title = s.connectorType,
            status = cableStatus,
            detail = "Tegangan ${s.voltageMv} mV • Arus ${s.currentMa} mA"
        )

        // 4. Charger / Adaptor
        val chargerStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.powerMw < 3_000 && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            s.isCharging -> DiagnosisItem.Status.INFO
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Charger / Adaptor",
            title = s.chargerType,
            status = chargerStatus,
            detail = "Protokol: ${s.chargingProtocol} • ${s.powerMw} mW"
        )

        // 5. Suhu Thermal
        val thermalStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.temperatureC in 0.1f..5f -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Suhu Thermal",
            title = if (s.temperatureC <= 0f) "Tidak tersedia" else "${"%.1f".format(s.temperatureC)}°C",
            status = thermalStatus,
            detail = when {
                thermalStatus == DiagnosisItem.Status.CRITICAL -> "Overheat! Risiko kerusakan"
                thermalStatus == DiagnosisItem.Status.WARNING -> "Suhu tidak ideal"
                s.temperatureC <= 0f -> "Sensor suhu tidak melaporkan data"
                else -> "Suhu normal"
            }
        )

        // 6. Fast Charging
        val fastStatus = when {
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Fast Charging",
            title = when {
                s.isFastCharging -> "AKTIF ⚡"
                !isPlugged -> "—"
                s.isCharging -> "Tidak aktif"
                else -> "Menunggu"
            },
            status = fastStatus,
            detail = if (s.isFastCharging) {
                "${s.chargingProtocol} • ${s.powerMw} mW"
            } else if (isPlugged) {
                "Daya ${s.powerMw} mW, kriteria fast charge belum terpenuhi"
            } else {
                "Charger tidak terhubung"
            }
        )

        // 7. Tegangan & Arus
        val viStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && abs(s.currentMa) > 6_000 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.voltageMv in 4_000..10_000 && abs(s.currentMa) in 100..6_000 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Tegangan & Arus",
            title = "${s.voltageMv} mV / ${s.currentMa} mA",
            status = viStatus,
            detail = "Daya ${s.powerMw} mW • ${if (s.isCharging) "stabil" else "idle"}"
        )

        return list
    }

    // ============================================================
    // HELPERS
    // ============================================================
    private fun statusToString(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
        else -> "Unknown"
    }

    private fun pluggedToString(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Unplugged"
    }

    private fun healthToString(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }

    companion object {
        private const val TAG = "BatteryRepository"

        @Volatile
        private var INSTANCE: BatteryRepository? = null

        fun get(context: Context): BatteryRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: BatteryRepository(context.applicationContext).also { INSTANCE = it }
            }

        fun getInstance(context: Context): BatteryRepository = get(context)
    }
}