package id.fastcharge.monitor.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import kotlin.math.abs
import kotlin.math.max

data class BatterySnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val level: Int = 0,
    val voltageMv: Int = 0,
    val currentMa: Int = 0,
    val powerMw: Int = 0,
    val temperatureC: Float = 0f,
    val health: String = "Unknown",
    val status: String = "Unknown",
    val plugged: String = "Unplugged",
    val isCharging: Boolean = false,
    val isFastCharging: Boolean = false,
    val chargingProtocol: String = "None",
    val connectorType: String = "Unknown",
    val chargerType: String = "Unknown",
    val etaMinutes: Int = -1,
    val chargeSpeedPctPerMin: Float = 0f,
    val batteryCapacityMah: Int = 0,
    val cycleCount: Int = 0
)

data class DiagnosisItem(
    val category: String,
    val title: String,
    val status: Status,
    val detail: String,
    val recommendation: String = ""
) {
    enum class Status { NORMAL, INFO, WARNING, CRITICAL, UNKNOWN }
}

class BatteryRepository private constructor(private val context: Context) {

    private val _snapshot = MutableStateFlow(BatterySnapshot())
    val snapshot: StateFlow<BatterySnapshot> = _snapshot

    private val _history = MutableStateFlow<List<BatterySnapshot>>(emptyList())
    val history: StateFlow<List<BatterySnapshot>> = _history

    private val _diagnosis = MutableStateFlow<List<DiagnosisItem>>(emptyList())
    val diagnosis: StateFlow<List<DiagnosisItem>> = _diagnosis

    private val handler = Handler(Looper.getMainLooper())
    private val historyBuffer = ArrayDeque<BatterySnapshot>()
    private val maxHistoryAgeMs = 60 * 60 * 1000L
    private val maxHistoryPoints = 7200

    private var lastLevel: Int = -1
    private var lastLevelTime: Long = 0L
    private var smoothedSpeed = 0f

    // Fallback: estimasi arus dari perubahan level
    private var lastKnownCurrentMa = 0
    private var lastPluggedState = 0
    private var consecutiveZeroCurrentCount = 0

    private val batteryManager: BatteryManager? =
        context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    private var running = false

    // Broadcast receiver untuk update segera saat cabut/pasang charger
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED ||
                intent?.action == Intent.ACTION_POWER_CONNECTED ||
                intent?.action == Intent.ACTION_POWER_DISCONNECTED) {
                poll()
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 500L)
        }
    }

    fun start() {
        if (running) return
        running = true
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(ticker)
        try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
    }

    private fun poll() {
        val intent = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (scale > 0 && level >= 0) level * 100 / scale else 0

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val tempTenth = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val tempC = tempTenth / 10f

        val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pluggedInt = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)

        val isCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING ||
                statusInt == BatteryManager.BATTERY_STATUS_FULL

        // === FIX: Deteksi koneksi charger yang lebih akurat ===
        val isPlugged = pluggedInt != 0
        val actuallyCharging = isCharging || isPlugged

        // === FIX: Baca arus dengan multi-strategi ===
        val currentMa = readCurrentMa(intent, isCharging || isPlugged)
        val powerMw = if (voltageMv > 0 && currentMa != 0) {
            (voltageMv.toLong() * abs(currentMa) / 1000L).toInt()
        } else 0

        // Reset smoothing kalau cabut charger
        if (!isPlugged && lastPluggedState != 0) {
            lastLevel = -1
            lastLevelTime = 0
            smoothedSpeed = 0f
            consecutiveZeroCurrentCount = 0
            lastKnownCurrentMa = 0
        }
        lastPluggedState = pluggedInt

        val isFast = isPlugged && powerMw >= 10_000 ||
                (isPlugged && voltageMv >= 4_400 && abs(currentMa) >= 2_000) ||
                (isPlugged && voltageMv >= 9_000)

        val protocol = detectProtocol(voltageMv, currentMa, isFast, pluggedInt)
        val connector = detectConnector(pluggedInt)
        val chargerType = detectChargerType(powerMw, voltageMv, isFast, isPlugged)

        updateChargeSpeed(pct, isCharging)
        val eta = computeEta(pct, isCharging, 100)

        val capacity = readBatteryCapacity()
        val cycles = readCycleCount()

        val snap = BatterySnapshot(
            timestamp = System.currentTimeMillis(),
            level = pct,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerMw = powerMw,
            temperatureC = tempC,
            health = healthToString(healthInt),
            status = if (isPlugged && !isCharging) "Connected (Not Charging)" else statusToString(statusInt),
            plugged = pluggedToString(pluggedInt),
            isCharging = isCharging,
            isFastCharging = isFast,
            chargingProtocol = protocol,
            connectorType = connector,
            chargerType = chargerType,
            etaMinutes = eta,
            chargeSpeedPctPerMin = smoothedSpeed,
            batteryCapacityMah = capacity,
            cycleCount = cycles
        )

        _snapshot.value = snap
        appendHistory(snap)
        _diagnosis.value = diagnose(snap, isPlugged)
    }

    /**
     * FIX: Baca arus dari berbagai sumber dengan fallback.
     * 1. BatteryManager (mayoritas device modern)
     * 2. /sys/class/power_supply/battery/current_now
     * 3. /sys/class/power_supply/battery/Battery_Current
     * 4. Estimasi: kalau plugged & charging tapi 0 → dummy estimate
     */
    private fun readCurrentMa(intent: Intent, chargingOrPlugged: Boolean): Int {
        // Strategi 1: BatteryManager
        if (batteryManager != null) {
            try {
                val uA = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                if (uA != Int.MIN_VALUE && uA != 0) {
                    val mA = if (abs(uA) > 100_000) uA / 1000 else uA
                    val normalized = normalizeCurrent(mA, chargingOrPlugged)
                    if (normalized != 0) {
                        lastKnownCurrentMa = normalized
                        consecutiveZeroCurrentCount = 0
                        return normalized
                    }
                }
            } catch (_: Exception) {}
        }

        // Strategi 2: sysfs
        val paths = listOf(
            "/sys/class/power_supply/battery/current_now",
            "/sys/class/power_supply/battery/Battery_Current",
            "/sys/class/power_supply/battery/current_avg"
        )
        for (p in paths) {
            try {
                val f = File(p)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toLongOrNull() ?: continue
                    // Beberapa device simpan dalam µA, ada yang mA
                    val mA = if (abs(raw) > 100_000) (raw / 1000).toInt() else raw.toInt()
                    val normalized = normalizeCurrent(mA, chargingOrPlugged)
                    if (normalized != 0) {
                        lastKnownCurrentMa = normalized
                        consecutiveZeroCurrentCount = 0
                        return normalized
                    }
                }
            } catch (_: Exception) {}
        }

        // Strategi 3: Kalau plugged tapi 0 terus → estimasi berbasis level
        if (chargingOrPlugged) {
            consecutiveZeroCurrentCount++
            if (lastKnownCurrentMa != 0 && consecutiveZeroCurrentCount < 10) {
                return lastKnownCurrentMa
            }
        }
        return 0
    }

    /** Normalisasi: convention positif = charging, negatif = discharging */
    private fun normalizeCurrent(mA: Int, charging: Boolean): Int {
        // Android: negatif saat charging (dari perspektif baterai), kita flip.
        // Kalau user charge: kita mau positif. Kalau discharge: kita mau positif juga untuk display.
        return if (charging) {
            if (mA < 0) -mA else mA   // charging → positif
        } else {
            if (mA < 0) -mA else mA   // discharge → positif juga (magnitude)
        }
    }

    private fun readBatteryCapacity(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/charge_full_design",
            "/sys/class/power_supply/battery/charge_full"
        )
        for (p in paths) {
            try {
                val f = File(p)
                if (f.exists() && f.canRead()) {
                    val raw = f.readText().trim().toLongOrNull() ?: continue
                    return (raw / 1000).toInt()
                }
            } catch (_: Exception) {}
        }
        return 0
    }

    private fun readCycleCount(): Int {
        val paths = listOf(
            "/sys/class/power_supply/battery/cycle_count",
            "/sys/class/power_supply/bms/cycle_count"
        )
        for (p in paths) {
            try {
                val f = File(p)
                if (f.exists() && f.canRead()) {
                    return f.readText().trim().toIntOrNull() ?: 0
                }
            } catch (_: Exception) {}
        }
        return 0
    }

    private fun updateChargeSpeed(level: Int, charging: Boolean) {
        val now = System.currentTimeMillis()
        if (lastLevelTime > 0 && charging && lastLevel >= 0 && level > lastLevel) {
            val dtMin = (now - lastLevelTime) / 60_000f
            if (dtMin > 0.05f) {
                val raw = (level - lastLevel) / dtMin
                smoothedSpeed = smoothedSpeed * 0.6f + raw * 0.4f
            }
        } else if (!charging) {
            smoothedSpeed = 0f
        }
        if (lastLevel != level) {
            lastLevel = level
            lastLevelTime = now
        }
    }

    private fun computeEta(level: Int, charging: Boolean, target: Int): Int {
        if (!charging) return -1
        val remaining = target - level
        if (remaining <= 0) return 0
        val speed = smoothedSpeed
        if (speed < 0.05f) return remaining * 2
        return (remaining / speed).toInt().coerceIn(1, 600)
    }

    private fun appendHistory(snap: BatterySnapshot) {
        historyBuffer.addLast(snap)
        val cutoff = System.currentTimeMillis() - maxHistoryAgeMs
        while (historyBuffer.isNotEmpty() && historyBuffer.first().timestamp < cutoff) {
            historyBuffer.removeFirst()
        }
        while (historyBuffer.size > maxHistoryPoints) historyBuffer.removeFirst()
        _history.value = historyBuffer.toList()
    }

    private fun detectProtocol(vMv: Int, iMa: Int, fast: Boolean, plugged: Int): String {
        if (plugged == 0) return "None"
        val p = vMv.toLong() * abs(iMa) / 1000L
        return when {
            vMv >= 9_000 && p >= 27_000 -> "USB-PD 27W+"
            vMv >= 9_000 && p >= 18_000 -> "USB-PD 18W"
            vMv >= 9_000 -> "USB-PD"
            vMv in 6_500..7_500 && p >= 15_000 -> "QC 3.0 / VOOC"
            vMv in 4_400..5_500 && iMa >= 3_000 -> "QC 2.0 / Fast"
            fast -> "Fast Charge (Vendor)"
            iMa >= 1_500 -> "Standard 5V/1.5A+"
            else -> "Standard Charging"
        }
    }

    private fun detectConnector(plugged: Int): String = when (plugged) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB Port (PC)"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Charger"
        else -> "Disconnected"
    }

    private fun detectChargerType(pMw: Int, vMv: Int, fast: Boolean, plugged: Boolean): String = when {
        !plugged -> "Not Connected"
        pMw >= 40_000 -> "Super Fast Charger (40W+)"
        pMw >= 18_000 -> "Fast Charger (18W+)"
        pMw >= 10_000 -> "Quick Charger (10W+)"
        pMw > 0 -> "Standard Charger"
        plugged -> "Charger (reading…)"
        else -> "Unknown"
    }

    private fun diagnose(s: BatterySnapshot, isPlugged: Boolean): List<DiagnosisItem> {
        val list = mutableListOf<DiagnosisItem>()

        // 1. Baterai
        val battStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.health == "Overheat" || s.health == "Dead" -> DiagnosisItem.Status.CRITICAL
            s.health == "Cold" -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Baterai (Sel)",
            title = "Level ${s.level}% • ${s.health}",
            status = battStatus,
            detail = buildString {
                append("Suhu ${"%.1f".format(s.temperatureC)}°C")
                if (s.batteryCapacityMah > 0) append(" • Kapasitas ${s.batteryCapacityMah} mAh")
                if (s.cycleCount > 0) append(" • ${s.cycleCount} siklus")
            },
            recommendation = when (battStatus) {
                DiagnosisItem.Status.CRITICAL -> "Baterai terlalu panas, cabut charger!"
                DiagnosisItem.Status.WARNING -> "Suhu tinggi, hindari penggunaan berat"
                else -> ""
            }
        )

        // 2. IC Pengisian
        val icStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            isPlugged && s.currentMa == 0 && s.isCharging -> DiagnosisItem.Status.WARNING
            isPlugged && s.isCharging && s.powerMw > 0 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "IC Pengisian",
            title = when {
                !isPlugged -> "Idle"
                s.isCharging && s.currentMa == 0 -> "Terdeteksi anomali"
                s.isCharging -> "Charging Aktif"
                else -> "Connected"
            },
            status = icStatus,
            detail = "Daya masuk ${s.powerMw} mW • ${if (s.isCharging) "menerima arus" else "menunggu"}",
            recommendation = if (icStatus == DiagnosisItem.Status.WARNING)
                "Coba cabut-pasang charger, cek kabel" else ""
        )

        // 3. Kabel & Port
        val cableStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.voltageMv < 4_000 -> DiagnosisItem.Status.CRITICAL
            s.isCharging && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.currentMa > 0 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Kabel & Port USB",
            title = s.connectorType,
            status = cableStatus,
            detail = "Tegangan ${s.voltageMv} mV • Arus ${s.currentMa} mA"
        )

        // 4. Charger / Adaptor
        val chargerStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && s.powerMw < 3_000 && s.currentMa == 0 -> DiagnosisItem.Status.WARNING
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            s.isCharging -> DiagnosisItem.Status.INFO
            isPlugged -> DiagnosisItem.Status.INFO
            else -> DiagnosisItem.Status.UNKNOWN
        }
        list += DiagnosisItem(
            category = "Charger / Adaptor",
            title = s.chargerType,
            status = chargerStatus,
            detail = "Protokol: ${s.chargingProtocol} • ${s.powerMw} mW"
        )

        // 5. Suhu Thermal
        val thermalStatus = when {
            s.temperatureC >= 45f -> DiagnosisItem.Status.CRITICAL
            s.temperatureC >= 40f -> DiagnosisItem.Status.WARNING
            s.temperatureC <= 5f && s.temperatureC > 0f -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.NORMAL
        }
        list += DiagnosisItem(
            category = "Suhu Thermal",
            title = "${"%.1f".format(s.temperatureC)}°C",
            status = thermalStatus,
            detail = when {
                thermalStatus == DiagnosisItem.Status.CRITICAL -> "Overheat! Risiko kerusakan"
                thermalStatus == DiagnosisItem.Status.WARNING -> "Suhu tidak ideal"
                else -> "Suhu normal"
            }
        )

        // 6. Fast Charging
        val fastStatus = when {
            s.isFastCharging -> DiagnosisItem.Status.NORMAL
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging -> DiagnosisItem.Status.WARNING
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Fast Charging",
            title = when {
                s.isFastCharging -> "AKTIF ⚡"
                !isPlugged -> "—"
                s.isCharging -> "Tidak aktif"
                else -> "Menunggu"
            },
            status = fastStatus,
            detail = if (s.isFastCharging)
                "${s.chargingProtocol} • ${s.powerMw} mW"
            else if (isPlugged) "Daya ${s.powerMw} mW, kriteria fast charge belum terpenuhi"
            else "Charger tidak terhubung"
        )

        // 7. Tegangan & Arus
        val viStatus = when {
            !isPlugged -> DiagnosisItem.Status.UNKNOWN
            s.isCharging && abs(s.currentMa) > 6_000 -> DiagnosisItem.Status.WARNING
            s.isCharging && s.voltageMv in 4_000..10_000 && abs(s.currentMa) in 100..6_000 -> DiagnosisItem.Status.NORMAL
            else -> DiagnosisItem.Status.INFO
        }
        list += DiagnosisItem(
            category = "Tegangan & Arus",
            title = "${s.voltageMv} mV / ${s.currentMa} mA",
            status = viStatus,
            detail = "Daya ${s.powerMw} mW • ${if (s.isCharging) "stabil" else "idle"}"
        )

        return list
    }

    private fun statusToString(s: Int) = when (s) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
        BatteryManager.BATTERY_STATUS_FULL -> "Full"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
        else -> "Unknown"
    }

    private fun pluggedToString(p: Int) = when (p) {
        BatteryManager.BATTERY_PLUGGED_AC -> "AC"
        BatteryManager.BATTERY_PLUGGED_USB -> "USB"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
        else -> "Unplugged"
    }

    private fun healthToString(h: Int) = when (h) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }

    companion object {
        @Volatile private var INSTANCE: BatteryRepository? = null
        fun get(context: Context): BatteryRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: BatteryRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}