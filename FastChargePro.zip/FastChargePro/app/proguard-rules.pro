# Keep default Android/AndroidX rules. Minification is disabled for the first stable rebuild.
