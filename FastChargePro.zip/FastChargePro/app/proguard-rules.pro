-keep class com.pterodactyl.installer.data.** { *; }
-keep class com.pterodactyl.installer.service.** { *; }
-keep class com.pterodactyl.installer.ui.** { *; }

# JSch
-keep class com.jcraft.jsch.** { *; }
-dontwarn com.jcraft.jsch.**
-dontwarn org.slf4j.**

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# WorkManager
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker