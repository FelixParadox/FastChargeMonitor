# FastCharge Monitor — Xiaomi Redmi 9A

Disesuaikan untuk **Xiaomi Redmi 9A** (sering keliru disebut “Redmi Note 9A”) dengan charger yang belum diketahui.

## Spesifikasi resmi
Xiaomi Indonesia mencantumkan baterai 5000 mAh, dukungan pengisian 10 W, adaptor bawaan 10 W (5V/2A), dan port micro-USB. Redmi 9A tidak boleh diasumsikan mendukung QC 3.0 atau pengisian 18 W. Adaptor yang memiliki label watt lebih tinggi tidak otomatis membuat ponsel menarik daya lebih tinggi.

Sumber:
- https://www.mi.co.id/id/redmi-9a/specs/
- https://www.mi.co.id/id/support/faq/details/KA-15703/

## Apa yang dipantau
- Persentase/status baterai, suhu, tegangan, status kesehatan, dan jenis sumber daya jika Android menyediakan.
- Arus baterai melalui `BatteryManager.BATTERY_PROPERTY_CURRENT_NOW` jika perangkat/firmware mengeksposnya.
- Daya perkiraan dari arus baterai × tegangan baterai. Ini **bukan** pengukuran langsung daya USB dari charger.
- Estimasi waktu penuh dari perubahan persentase.
- Gejala awal seperti suhu tinggi, arus rendah, atau arus berubah-ubah.

## Tentang fast charging
Profil Redmi 9A ditetapkan pada maksimum resmi 10 W. Aplikasi tidak menyatakan “fast charging aktif” hanya karena HP menunjukkan status mengisi atau karena nilai arus/watt sensor terlihat tinggi. Android tidak menyediakan API universal untuk membuktikan protokol charger atau mengukur daya input secara akurat pada semua perangkat.

## Batas diagnosis
Aplikasi tidak bisa memastikan kabel, adaptor, port micro-USB, IC pengisian, atau baterai rusak hanya dari sensor Android. Arus rendah/tidak stabil dapat dipengaruhi level baterai, beban HP, suhu, kontrol pengisian, kualitas kabel/adaptor, atau sensor yang tidak didukung. Untuk mengukur daya dari adaptor, gunakan USB power meter yang sesuai; pemeriksaan kerusakan hardware memerlukan inspeksi/diagnostik servis.

## Build
1. Ekstrak ZIP dan buka folder `FastChargeMonitor` di Android Studio.
2. Sinkronkan Gradle dan pastikan Android SDK Platform 35 tersedia.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Source project belum dikompilasi atau diuji pada perangkat fisik. Data sensor yang tersedia bergantung pada versi Android/MIUI dan kernel perangkat.
