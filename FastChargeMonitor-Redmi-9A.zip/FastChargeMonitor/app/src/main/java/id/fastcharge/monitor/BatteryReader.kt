package id.fastcharge.monitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File
import kotlin.math.abs

class BatteryReader(private val context: Context) {

    private val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    data class Data(
        val percent: Int,
        val status: Int,
        val plugged: Int,
        val voltageMv: Int,
        val currentMa: Double?,
        val powerW: Double?,
        val tempC: Double,
        val health: Int,
        val technology: String,
        val isCharging: Boolean,
        val isFull: Boolean
    )

    fun read(): Data {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0) level * 100 / scale else -1

        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val tempC = (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10.0
        val health = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val technology = intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

        // Prioritas 1: BatteryManager
        var currentUa = try {
            bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) { Long.MIN_VALUE }

        // Prioritas 2: sysfs (untuk Redmi 9A & lainnya)
        if (currentUa == Long.MIN_VALUE || currentUa == 0L) {
            currentUa = SysfsReader.readCurrentUa() ?: Long.MIN_VALUE
        }

        val currentMa = if (currentUa != Long.MIN_VALUE && currentUa != Int.MIN_VALUE.toLong()) {
            abs(currentUa) / 1000.0
        } else null

        val voltageV = if (voltageMv > 0) voltageMv / 1000.0 else null
        val powerW = if (currentMa != null && voltageV != null) currentMa * voltageV else null

        return Data(
            percent = percent,
            status = status,
            plugged = plugged,
            voltageMv = voltageMv,
            currentMa = currentMa,
            powerW = powerW,
            tempC = tempC,
            health = health,
            technology = technology,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING,
            isFull = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100
        )
    }
}