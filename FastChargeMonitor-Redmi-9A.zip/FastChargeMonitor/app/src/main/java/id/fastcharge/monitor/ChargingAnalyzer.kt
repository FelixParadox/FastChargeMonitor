package id.fastcharge.monitor

import android.os.BatteryManager

object ChargingAnalyzer {

    fun protocolLabel(data: BatteryReader.Data): String = when {
        !data.isCharging -> "Tidak mengisi"
        data.powerW == null -> "Tidak terdeteksi"
        data.powerW >= 18.0 -> "SuperVOOC / VOOC / PD / QC"
        data.powerW >= 10.0 -> "Fast Charging 10W+"
        data.powerW >= 5.0 -> "Charging standar"
        else -> "Arus rendah"
    }

    fun fastStatus(data: BatteryReader.Data): Pair<String, String> = when {
        !data.isCharging && !data.isFull ->
            "Tidak Mengisi" to "Sambungkan charger untuk memantau"
        data.isFull ->
            "Pengisian Selesai" to "Baterai sudah penuh"
        data.powerW == null ->
            "Fast Charging Tidak Terdeteksi" to "Sensor daya tidak tersedia"
        data.powerW >= 15.0 ->
            "Fast Charging Aktif" to "Menggunakan pengisian cepat"
        else ->
            "Pengisian Standar" to "Daya terukur rendah/sedang"
    }

    fun healthLabel(health: Int): String = when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Baik"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Rusak"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan berlebih"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gangguan sistem"
        BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
        else -> "Tidak tersedia"
    }

    fun diagnosis(data: BatteryReader.Data): String {
        val warn = mutableListOf<String>()
        if (data.tempC >= 45) warn.add("Suhu tinggi (≥45°C), hentikan pengisian.")
        else if (data.tempC >= 40) warn.add("Suhu hangat, kurangi pemakaian.")
        if (data.isCharging && data.currentMa != null && data.currentMa < 100)
            warn.add("Arus rendah, cek kabel/adaptor/port.")
        return if (warn.isEmpty()) "Belum ada gejala jelas. Ini bukan tes kerusakan fisik."
        else "Indikasi awal:\n• " + warn.joinToString("\n• ")
    }
}