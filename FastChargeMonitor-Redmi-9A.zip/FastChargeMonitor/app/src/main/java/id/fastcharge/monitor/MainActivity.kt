package id.fastcharge.monitor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var reader: BatteryReader
    private val handler = Handler(Looper.getMainLooper())
    private val chartEntries = mutableListOf<Entry>()
    private var entryIndex = 0f
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePerHour = 0.0

    private lateinit var percentText: TextView
    private lateinit var statusText: TextView
    private lateinit var fastBadge: TextView
    private lateinit var etaText: TextView
    private lateinit var clockText: TextView
    private lateinit var voltageText: TextView
    private lateinit var currentText: TextView
    private lateinit var powerText: TextView
    private lateinit var tempText: TextView
    private lateinit var fastStatusText: TextView
    private lateinit var fastDetailText: TextView
    private lateinit var protocolText: TextView
    private lateinit var healthText: TextView
    private lateinit var technologyText: TextView
    private lateinit var diagnosisText: TextView
    private lateinit var updatedText: TextView
    private lateinit var lineChart: LineChart

    private val runnable = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        reader = BatteryReader(this)
        bind()
        setupChart()
        handler.post(runnable)
    }

    private fun bind() {
        percentText = findViewById(R.id.percentText)
        statusText = findViewById(R.id.statusText)
        fastBadge = findViewById(R.id.fastBadge)
        etaText = findViewById(R.id.etaText)
        clockText = findViewById(R.id.clockText)
        voltageText = findViewById(R.id.voltageText)
        currentText = findViewById(R.id.currentText)
        powerText = findViewById(R.id.powerText)
        tempText = findViewById(R.id.tempText)
        fastStatusText = findViewById(R.id.fastStatusText)
        fastDetailText = findViewById(R.id.fastDetailText)
        protocolText = findViewById(R.id.protocolText)
        healthText = findViewById(R.id.healthText)
        technologyText = findViewById(R.id.technologyText)
        diagnosisText = findViewById(R.id.diagnosisText)
        updatedText = findViewById(R.id.updatedText)
        lineChart = findViewById(R.id.lineChart)
    }

    private fun setupChart() {
        lineChart.description.isEnabled = false
        lineChart.legend.isEnabled = false
        lineChart.setTouchEnabled(false)
        lineChart.axisRight.isEnabled = false
        lineChart.axisLeft.textColor = Color.WHITE
        lineChart.xAxis.textColor = Color.WHITE
        lineChart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        lineChart.setNoDataText("Menunggu data...")
    }

    private fun refresh() {
        val d = reader.read()

        // UI utama
        percentText.text = if (d.percent >= 0) "${d.percent}%" else "--%"
        statusText.text = when {
            d.isFull -> "Baterai Penuh"
            d.isCharging -> "Mengisi Daya"
            else -> "Menggunakan Baterai"
        }

        // ETA
        val now = System.currentTimeMillis()
        if (d.percent >= 0) {
            if (lastLevel >= 0 && d.percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3600000.0
                if (hours > 0) ratePerHour = (d.percent - lastLevel) / hours
            }
            if (d.percent != lastLevel) {
                lastLevel = d.percent
                lastLevelTime = now
            }
        }

        etaText.text = when {
            d.isFull -> "Sudah penuh"
            !d.isCharging -> "Menunggu pengisian"
            ratePerHour > 0.1 -> {
                val mins = (((100 - d.percent).coerceAtLeast(0) / ratePerHour) * 60).roundToInt()
                "${mins / 60} jam ${mins % 60} menit"
            }
            else -> "Menghitung..."
        }

        clockText.text = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())

        // Metrik
        voltageText.text = "Tegangan\n" + if (d.voltageMv > 0) "${d.voltageMv} mV" else "--"
        currentText.text = "Arus\n" + (d.currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "--")
        powerText.text = "Daya\n" + (d.powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "--")
        tempText.text = "Suhu\n" + if (d.tempC > 0) String.format(Locale.US, "%.1f °C", d.tempC) else "--"

        // Fast charging
        val (title, detail) = ChargingAnalyzer.fastStatus(d)
        fastStatusText.text = title
        fastDetailText.text = detail
        fastBadge.text = if (d.isCharging) "⚡ $title" else ""
        protocolText.text = "Protokol: ${ChargingAnalyzer.protocolLabel(d)}"

        healthText.text = "Kesehatan Baterai: ${ChargingAnalyzer.healthLabel(d.health)}"
        technologyText.text = "Teknologi: ${d.technology}"
        diagnosisText.text = ChargingAnalyzer.diagnosis(d)
        updatedText.text = "Pembaruan tiap 2 detik • Sensor: ${if (d.currentMa != null) "OK" else "Terbatas"}"

        // Grafik
        if (d.powerW != null) {
            chartEntries.add(Entry(entryIndex++, d.powerW.toFloat()))
            if (chartEntries.size > 30) chartEntries.removeAt(0)
            val set = LineDataSet(chartEntries, "Watt")
            set.color = Color.parseColor("#7C4DFF")
            set.setDrawCircles(false)
            set.setDrawValues(false)
            set.mode = LineDataSet.Mode.CUBIC_BEZIER
            lineChart.data = LineData(set)
            lineChart.invalidate()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(runnable)
        super.onDestroy()
    }
}