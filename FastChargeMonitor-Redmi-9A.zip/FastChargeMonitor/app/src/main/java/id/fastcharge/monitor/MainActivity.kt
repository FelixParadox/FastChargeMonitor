package id.fastcharge.monitor

import android.app.Activity
import android.os.BatteryManager
import android.os.Bundle
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var batteryManager: BatteryManager
    private val handler = Handler(Looper.getMainLooper())
    private var latestLevel = -1
    private var latestStatus = BatteryManager.BATTERY_STATUS_UNKNOWN
    private var lastLevel = -1
    private var lastLevelTime = 0L
    private var ratePercentPerHour = 0.0
    private var currentSamples = mutableListOf<Long>()
    private var receiverRegistered = false

    private lateinit var timeText: TextView
    private lateinit var percentText: TextView
    private lateinit var batteryProgress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var etaText: TextView
    private lateinit var currentText: TextView
    private lateinit var voltageText: TextView
    private lateinit var powerText: TextView
    private lateinit var tempText: TextView
    private lateinit var healthText: TextView
    private lateinit var sourceText: TextView
    private lateinit var technologyText: TextView
    private lateinit var fastText: TextView
    private lateinit var diagnosisText: TextView
    private lateinit var updatedText: TextView

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshBattery()
            handler.postDelayed(this, 2000)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            latestLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            latestStatus = intent.getIntExtra(
                BatteryManager.EXTRA_STATUS,
                BatteryManager.BATTERY_STATUS_UNKNOWN
            )
            refreshBattery(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        bindViews()

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = registerReceiver(batteryReceiver, filter)
        receiverRegistered = true
        if (sticky != null) {
            latestLevel = sticky.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            latestStatus = sticky.getIntExtra(
                BatteryManager.EXTRA_STATUS,
                BatteryManager.BATTERY_STATUS_UNKNOWN
            )
            refreshBattery(sticky)
        }
        handler.post(refreshRunnable)
    }

    private fun bindViews() {
        timeText = findViewById(R.id.timeText)
        percentText = findViewById(R.id.percentText)
        batteryProgress = findViewById(R.id.batteryProgress)
        statusText = findViewById(R.id.statusText)
        etaText = findViewById(R.id.etaText)
        currentText = findViewById(R.id.currentText)
        voltageText = findViewById(R.id.voltageText)
        powerText = findViewById(R.id.powerText)
        tempText = findViewById(R.id.tempText)
        healthText = findViewById(R.id.healthText)
        sourceText = findViewById(R.id.sourceText)
        technologyText = findViewById(R.id.technologyText)
        fastText = findViewById(R.id.fastText)
        diagnosisText = findViewById(R.id.diagnosisText)
        updatedText = findViewById(R.id.updatedText)
    }

    private fun refreshBattery(intent: Intent? = null) {
        val batteryIntent = intent ?: registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return

        val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, latestLevel)
        val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val percent = if (level >= 0) (level * 100f / scale).roundToInt() else latestLevel
        val status = batteryIntent.getIntExtra(
            BatteryManager.EXTRA_STATUS, latestStatus
        )
        val plugged = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val tempC = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.0
        val voltageMv = batteryIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val health = batteryIntent.getIntExtra(
            BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN
        )
        val technology = batteryIntent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Tidak diketahui"

        // BATTERY_PROPERTY_CURRENT_NOW is in microamps; sign/direction varies by device.
        val currentUa = try {
            batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) { Long.MIN_VALUE }

        val currentMa = if (currentUa == Long.MIN_VALUE || currentUa == Int.MIN_VALUE.toLong()) {
            null
        } else {
            abs(currentUa) / 1000.0
        }
        val voltageV = if (voltageMv > 0) voltageMv / 1000.0 else null
        val powerW = if (currentMa != null && voltageV != null) {
            currentMa * voltageV / 1000.0
        } else null

        val now = System.currentTimeMillis()
        if (percent >= 0) {
            if (lastLevel >= 0 && percent != lastLevel && now > lastLevelTime) {
                val hours = (now - lastLevelTime) / 3600000.0
                if (hours > 0) ratePercentPerHour = (percent - lastLevel) / hours
            }
            if (percent != lastLevel) {
                lastLevel = percent
                lastLevelTime = now
            }
        }

        if (currentMa != null) {
            currentSamples.add(currentMa.toLong())
            if (currentSamples.size > 12) currentSamples.removeAt(0)
        }

        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING
        val full = status == BatteryManager.BATTERY_STATUS_FULL || percent >= 100

        timeText.text = "Waktu: ${SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())}"
        percentText.text = if (percent >= 0) "$percent%" else "--%"
        batteryProgress.progress = percent.coerceIn(0, 100)
        statusText.text = "Status: " + when {
            full -> "PENUH"
            charging -> "MENGISI DAYA"
            status == BatteryManager.BATTERY_STATUS_DISCHARGING -> "MENGGUNAKAN BATERAI"
            status == BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "TIDAK MENGISI"
            else -> "TIDAK DIKETAHUI"
        }

        etaText.text = when {
            full -> "Estimasi penuh: baterai sudah penuh"
            !charging -> "Estimasi penuh: menunggu pengisian aktif"
            ratePercentPerHour > 0.1 -> {
                val mins = (((100 - percent).coerceAtLeast(0) / ratePercentPerHour) * 60).roundToInt()
                "Estimasi penuh: ${mins / 60} jam ${mins % 60} menit (perkiraan)"
            }
            else -> "Estimasi penuh: mengumpulkan data perubahan baterai"
        }

        currentText.text = "Arus baterai: " + (currentMa?.let { String.format(Locale.US, "%.0f mA", it) } ?: "Tidak tersedia")
        voltageText.text = "Tegangan baterai: " + (voltageV?.let { String.format(Locale.US, "%.3f V", it) } ?: "Tidak tersedia")
        powerText.text = "Daya perkiraan: " + (powerW?.let { String.format(Locale.US, "%.2f W", it) } ?: "Tidak tersedia")
        tempText.text = "Suhu baterai: " + if (tempC >= 0) String.format(Locale.US, "%.1f °C", tempC) else "Tidak tersedia"
        healthText.text = "Kesehatan baterai: " + healthLabel(health)
        sourceText.text = "Sumber daya: " + when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Adaptor AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Nirkabel"
            else -> "Tidak tersambung / tidak diketahui"
        }
        technologyText.text = "Teknologi baterai: $technology"

        // This is an estimate, NOT proof of proprietary fast-charge protocol.
        fastText.text = when {
            !charging && !full -> "Fast charging: tidak sedang mengisi"
            full -> "Fast charging: pengisian selesai"
            powerW == null -> "Fast charging: data daya tidak tersedia"
            powerW >= 15.0 -> "Indikasi daya tinggi: ${String.format(Locale.US, "%.1f W", powerW)}"
            else -> "Fast charging: protokol tidak dapat dipastikan; daya terukur rendah/sedang"
        }

        val warnings = mutableListOf<String>()
        if (tempC >= 45) warnings.add("Suhu tinggi (≥45 °C); hentikan pengisian bila tetap panas.")
        else if (tempC >= 40) warnings.add("Suhu hangat; kurangi penggunaan saat mengisi.")
        if (charging && currentMa != null && currentMa < 100) warnings.add("Arus terukur rendah; cek kabel, adaptor, port, dan suhu.")
        if (currentSamples.size >= 6) {
            val avg = currentSamples.average()
            val variance = currentSamples.map { (it - avg) * (it - avg) }.average()
            val cv = if (avg > 0) kotlin.math.sqrt(variance) / avg else 0.0
            if (cv > 0.55 && charging) warnings.add("Arus berubah-ubah; bisa dipengaruhi beban HP atau kontrol suhu.")
        }
        if (warnings.isEmpty()) {
            diagnosisText.text = "Diagnosis: belum ada gejala jelas dari sensor yang tersedia. Ini bukan tes kerusakan fisik."
        } else {
            diagnosisText.text = "Diagnosis awal:\n• " + warnings.joinToString("\n• ") +
                "\nHasil ini indikasi, bukan konfirmasi kerusakan."
        }
        updatedText.text = "Pembaruan tiap 2 detik • sensor tersedia bergantung perangkat"
    }

    private fun healthLabel(health: Int): String = when (health) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Baik (dilaporkan Android)"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Baterai dilaporkan rusak"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan berlebih"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gangguan dilaporkan sistem"
        BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
        else -> "Tidak tersedia"
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshRunnable)
        if (receiverRegistered) {
            try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
