package id.fastcharge.monitor

import java.io.File

object SysfsReader {

    // Path umum untuk MediaTek (Redmi 9A) + Qualcomm + Exynos
    private val currentPaths = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/mtk-battery/current_now",
        "/sys/class/power_supply/qcom-battery/current_now",
        "/sys/class/power_supply/bms/current_now",
        "/sys/class/power_supply/rt-battery/current_now"
    )

    fun readCurrentUa(): Long? {
        for (path in currentPaths) {
            val f = File(path)
            if (f.exists() && f.canRead()) {
                return try {
                    f.readText().trim().toLongOrNull()
                } catch (_: Exception) { null }
            }
        }
        return null
    }
}