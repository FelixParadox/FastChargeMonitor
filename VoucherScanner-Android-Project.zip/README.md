# Voucher Scanner Android

Aplikasi Android native Kotlin + XML untuk:
- Memilih operator dari satu aplikasi.
- Scan QR voucher memakai kamera dan ML Kit.
- Memasukkan kode voucher secara manual.
- Mengubah format USSD dengan placeholder `{KODE}`.
- Membuka aplikasi Telepon dengan kode USSD sudah terisi (`ACTION_DIAL`).

## Membuka dan build
Buka folder proyek ini di Android Studio versi yang mendukung Android Gradle Plugin 8.7.3, lalu tunggu Gradle Sync dan pilih **Build > Build APK(s)**.

Alternatif GitHub Actions:
1. Upload seluruh isi proyek ke repository GitHub.
2. Buka tab **Actions**.
3. Jalankan workflow **Build Voucher Scanner APK**.
4. Unduh artifact `VoucherScanner-debug-apk`.

## Penting tentang format operator
Format preset di aplikasi hanya contoh awal dan tidak dijamin benar untuk semua jenis voucher/operator. Verifikasi dengan petunjuk resmi voucher. Edit kolom **Format USSD** dan gunakan `{KODE}` sebagai placeholder, misalnya `*999*{KODE}#`.

Aplikasi sengaja memakai `Intent.ACTION_DIAL`, sehingga pengguna dapat memeriksa kode dan menekan tombol panggil sendiri. Aplikasi tidak melakukan panggilan diam-diam.

## Catatan QR
Pemindai mengambil rangkaian angka terpanjang (minimal 6 digit) dari teks QR. Jika QR berisi format khusus yang tidak hanya angka, tinjau hasilnya sebelum Submit.
