package id.voucherscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import id.voucherscanner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val operators = listOf(
        "Telkomsel", "Smartfren", "Indosat", "Tri (3)", "XL", "AXIS", "Operator lain / kustom"
    )

    // Ini hanya preset contoh, bukan jaminan format resmi untuk setiap paket.
    private val formats = mapOf(
        "Telkomsel" to "*133*{KODE}#",
        "Smartfren" to "*999*{KODE}#",
        "Indosat" to "*556*{KODE}#",
        "Tri (3)" to "*111*{KODE}#",
        "XL" to "*817*{KODE}#",
        "AXIS" to "*838*{KODE}#",
        "Operator lain / kustom" to "{KODE}"
    )

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val scanned = result.data?.getStringExtra(ScannerActivity.EXTRA_SCANNED_CODE).orEmpty()
                if (scanned.isNotBlank()) {
                    binding.voucherInput.setText(scanned)
                    updatePreview()
                    Toast.makeText(this, "Kode QR berhasil dibaca", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.operatorSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, operators
        )

        binding.operatorSpinner.setSelection(0)
        binding.formatInput.setText(formats["Telkomsel"])
        binding.operatorSpinner.setOnItemSelectedListener(
            SimpleItemSelectedListener { selected ->
                val current = binding.formatInput.text?.toString().orEmpty()
                val previousPreset = formats.values.toSet()
                // Isi preset saat operator berubah; pengguna tetap bisa mengedit format.
                if (current in previousPreset || current.isBlank()) {
                    binding.formatInput.setText(formats[selected].orEmpty())
                }
                updatePreview()
            }
        )

        binding.voucherInput.addTextChangedListener(SimpleTextWatcher { updatePreview() })
        binding.formatInput.addTextChangedListener(SimpleTextWatcher { updatePreview() })

        binding.scanButton.setOnClickListener {
            scanLauncher.launch(Intent(this, ScannerActivity::class.java))
        }

        binding.submitButton.setOnClickListener { submitUssd() }
        updatePreview()
    }

    private fun normalizedCode(): String =
        binding.voucherInput.text?.toString()?.trim()?.replace("\\s".toRegex(), "").orEmpty()

    private fun makeUssd(): String {
        val format = binding.formatInput.text?.toString()?.trim().orEmpty()
        return format.replace("{KODE}", normalizedCode(), ignoreCase = true)
    }

    private fun updatePreview() {
        if (!::binding.isInitialized) return
        binding.previewText.text = makeUssd().ifBlank { "Format belum diisi" }
    }

    private fun submitUssd() {
        val code = normalizedCode()
        val format = binding.formatInput.text?.toString()?.trim().orEmpty()

        if (code.isEmpty()) {
            binding.voucherInput.error = "Masukkan kode voucher terlebih dahulu"
            return
        }
        if (!code.matches(Regex("[A-Za-z0-9]+"))) {
            binding.voucherInput.error = "Kode hanya boleh berisi huruf dan angka"
            return
        }
        if (format.isEmpty() || !format.contains("{KODE}", ignoreCase = true)) {
            binding.formatInput.error = "Format harus berisi placeholder {KODE}"
            return
        }

        val ussd = makeUssd()
        if (ussd.any { it.isWhitespace() } || ussd.length > 100) {
            binding.formatInput.error = "Format USSD tidak valid"
            return
        }

        // ACTION_DIAL menampilkan kode pada aplikasi telepon untuk konfirmasi pengguna.
        // Encoding memastikan karakter # tidak diperlakukan sebagai fragment URI.
        val dialUri = Uri.parse("tel:" + Uri.encode(ussd, "*"))
        try {
            startActivity(Intent(Intent.ACTION_DIAL, dialUri))
        } catch (_: Exception) {
            Toast.makeText(this, "Aplikasi telepon tidak tersedia di perangkat ini", Toast.LENGTH_LONG).show()
        }
    }
}
